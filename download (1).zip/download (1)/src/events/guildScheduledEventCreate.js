const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");

module.exports = {
  name: "guildScheduledEventCreate",
  async execute(event) {
    if (!event.guild) return;
    let actor;
    try {
      const logs = await event.guild.fetchAuditLogs({
        type: AuditLogEvent.GuildScheduledEventCreate,
        limit: 5
      });
      const entry = logs.entries.find(
        (e) => e.target?.id === event.id && Date.now() - e.createdTimestamp < 10000
      );
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }

    await logManager
      .log(event.guild, {
        type: "create",
        title: "📅 Scheduled Event Created",
        actor,
        fields: [
          { name: "Event", value: `${event.name} (${event.id})` },
          {
            name: "Starts",
            value: event.scheduledStartTimestamp
              ? `<t:${Math.floor(event.scheduledStartTimestamp / 1000)}:F>`
              : "Unknown",
            inline: true
          }
        ]
      })
      .catch(() => {});
  }
};
