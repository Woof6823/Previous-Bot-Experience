const logManager = require("../handlers/logManager");

module.exports = {
  name: "autoModerationRuleDelete",
  async execute(rule) {
    if (!rule.guild) return;
    await logManager
      .log(rule.guild, {
        type: "delete",
        title: "🛡️ AutoMod Rule Deleted",
        fields: [{ name: "Rule", value: `${rule.name} (${rule.id})` }]
      })
      .catch(() => {});
  }
};
