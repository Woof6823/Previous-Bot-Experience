const statusRoleManager = require("../handlers/statusRoleManager");

module.exports = {
  name: "presenceUpdate",
  async execute(oldPresence, newPresence) {
    const member = newPresence?.member;
    if (!member) return;

    statusRoleManager.checkMember(member).catch((err) => {
      console.error("Error handling status-role presence update:", err.message);
    });
  }
};
