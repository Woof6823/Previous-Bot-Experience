const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");
const securityManager = require("../handlers/securityManager");

module.exports = {
  name: "channelUpdate",
  async execute(oldChannel, newChannel) {
    if (!newChannel.guild) return;





    try {
      await securityManager.checkChannelOverwriteAbuse(oldChannel, newChannel);
    } catch (error) {
      console.error("Anti-channel-overwrite-abuse check failed:", error.message);
    }

    const changes = [];
    if (oldChannel.name !== newChannel.name)
      changes.push(`Name: \`${oldChannel.name}\` → \`${newChannel.name}\``);
    if (oldChannel.topic !== newChannel.topic) {
      changes.push(`Topic changed.`);
    }
    if (oldChannel.parentId !== newChannel.parentId) changes.push(`Category changed.`);
    if (oldChannel.nsfw !== newChannel.nsfw)
      changes.push(`NSFW: \`${oldChannel.nsfw}\` → \`${newChannel.nsfw}\``);
    if (oldChannel.rateLimitPerUser !== newChannel.rateLimitPerUser) {
      changes.push(
        `Slowmode: \`${oldChannel.rateLimitPerUser}s\` → \`${newChannel.rateLimitPerUser}s\``
      );
    }
    if (oldChannel.bitrate !== newChannel.bitrate) changes.push(`Bitrate changed.`);
    if (oldChannel.userLimit !== newChannel.userLimit) {
      changes.push(`User limit: \`${oldChannel.userLimit}\` → \`${newChannel.userLimit}\``);
    }
    if (oldChannel.position !== newChannel.position) changes.push(`Position changed.`);

    if (changes.length === 0) return;

    let actor;
    try {
      const logs = await newChannel.guild.fetchAuditLogs({
        type: AuditLogEvent.ChannelUpdate,
        limit: 5
      });
      const entry = logs.entries.find(
        (e) => e.target?.id === newChannel.id && Date.now() - e.createdTimestamp < 10000
      );
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }

    await logManager
      .log(newChannel.guild, {
        type: "update",
        title: "📁 Channel Updated",
        actor,
        fields: [
          { name: "Channel", value: `${newChannel}`, inline: true },
          { name: "Changes", value: changes.join("\n").slice(0, 1024) }
        ]
      })
      .catch(() => {});
  }
};
