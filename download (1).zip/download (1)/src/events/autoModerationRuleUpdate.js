const logManager = require("../handlers/logManager");

module.exports = {
  name: "autoModerationRuleUpdate",
  async execute(oldRule, newRule) {
    if (!newRule.guild) return;

    const changes = [];
    if (oldRule.name !== newRule.name) changes.push(`Name: \`${oldRule.name}\` → \`${newRule.name}\``);
    if (oldRule.enabled !== newRule.enabled) {
      changes.push(`Enabled: \`${oldRule.enabled}\` → \`${newRule.enabled}\``);
    }
    if (changes.length === 0) return;

    await logManager
      .log(newRule.guild, {
        type: "update",
        title: "🛡️ AutoMod Rule Updated",
        fields: [
          { name: "Rule", value: `${newRule.name} (${newRule.id})` },
          { name: "Changes", value: changes.join("\n").slice(0, 1024) }
        ]
      })
      .catch(() => {});
  }
};
