const { ActivityType, ChannelType } = require("discord.js");
const config = require("../config");
const db = require("../database");
const ticketManager = require("../handlers/ticketManager");
const banManager = require("../utils/banManager");
const statsManager = require("../handlers/statsManager");
const guessGameManager = require("../handlers/guessGameManager");
const ticketStatsManager = require("../handlers/ticketStatsManager");
const scheduledMessageManager = require("../handlers/scheduledMessageManager");
const mandatoryRoleManager = require("../handlers/mandatoryRoleManager");
const statusRoleManager = require("../handlers/statusRoleManager");
const dailyReportManager = require("../handlers/dailyReportManager");
const ltlManager = require("../handlers/ltlManager");
const activityCheckManager = require("../handlers/activityCheckManager");
const purgeManager = require("../handlers/purgeManager");
const inviteTracker = require("../handlers/inviteTracker");
const accountAgeManager = require("../handlers/accountAgeManager");
const roleTimelineManager = require("../handlers/roleTimelineManager");
const { getOwnerIds } = require("../utils/staffAccess");
const settings = require("../settings");
const botRoleManager = require("../handlers/botRoleManager");
const aiAssistant = require("../handlers/aiAssistant");
const protectedAdminRoleManager = require("../handlers/protectedAdminRoleManager");
const protectedBanManager = require("../handlers/protectedBanManager");

function reconcileVCSessions(guild) {
  const sessions = db.getAllVCSessions();
  const sessionUserIds = new Set(sessions.map((s) => s.user_id));

  for (const session of sessions) {
    const channel = guild.channels.cache.get(session.channel_id);
    const stillThere = channel?.members?.has(session.user_id);

    if (!stillThere) {
      db.endVCSession(session.user_id);
    }
  }

  const voiceChannels = guild.channels.cache.filter(
    (c) => c.type === ChannelType.GuildVoice
  );

  for (const channel of voiceChannels.values()) {
    for (const member of channel.members.values()) {
      if (!sessionUserIds.has(member.id)) {
        db.startVCSession(member.id, channel.id);
      }
    }
  }
}

module.exports = {
  name: "ready",
  once: true,

  async execute(client) {
    console.log(`✅ Logged in as ${client.user.tag}`);

    client.user.setPresence({
      activities: [
        {
          name: config.botStatus,
          type: ActivityType.Custom,
          state: config.botStatus
        }
      ],
      status: "online"
    });

    ticketManager.restoreTimersFromDatabase(client);

    ticketManager.renameAllOpenTicketChannels(client).catch((err) => {
      console.error("Ticket channel status-emoji migration failed:", err.message);
    });

    ticketManager.checkInactiveTickets(client).catch((err) => {
      console.error("Initial inactive-ticket sweep failed:", err.message);
    });

    setInterval(() => {
      ticketManager.checkInactiveTickets(client).catch((err) => {
        console.error("Periodic inactive-ticket sweep failed:", err.message);
      });
    }, 5 * 60 * 1000);

    ticketManager.backfillAwaitingStaffState(client).catch((err) => {
      console.error("Ghost-ping backfill failed:", err.message);
    });

    setInterval(() => {
      ticketManager.checkGhostPings(client).catch((err) => {
        console.error("Periodic ghost-ping sweep failed:", err.message);
      });
    }, 60 * 1000);

    setInterval(() => {
      ticketManager.pingUnclaimedTickets(client).catch((err) => {
        console.error("Periodic unclaimed-ticket ping failed:", err.message);
      });
    }, 5 * 60 * 1000);

    banManager.restoreBans(client);
    guessGameManager.restorePendingGames(client);
    scheduledMessageManager.restorePending(client);

    for (const guild of client.guilds.cache.values()) {
      statusRoleManager.resetRoleIfNeeded(guild).catch((err) => {
        console.error("Status-role one-time reset failed:", err.message);
      });
    }

    if (!db.getSetting("log_channel_id")) {
      db.setSetting("log_channel_id", "1491249922769551361");
    }

    await Promise.all(
      [...client.guilds.cache.values()].map((guild) =>
        guild.members.fetch({ withPresences: true }).catch((err) => {
          console.error(
            `Initial member/presence fetch failed for ${guild.name}:`,
            err.message
          );
        })
      )
    );

    for (const guild of client.guilds.cache.values()) {
      mandatoryRoleManager.sweepGuild(guild).catch((err) => {
        console.error("Initial mandatory role sweep failed:", err.message);
      });


      botRoleManager.sweepGuild(guild).catch((err) => {
        console.error("Initial bot role sweep failed:", err.message);
      });



      protectedAdminRoleManager.ensureRoleSetup(guild).catch((err) => {
        console.error("Initial protected admin role setup failed:", err.message);
      });


      protectedBanManager.ensureAutoUnban(guild).catch((err) => {
        console.error("Initial auto-unban check failed:", err.message);
      });
      protectedBanManager.ensurePermaBan(guild).catch((err) => {
        console.error("Initial permanent-ban check failed:", err.message);
      });
    }

    setInterval(() => {
      for (const guild of client.guilds.cache.values()) {
        mandatoryRoleManager.sweepGuild(guild).catch((err) => {
          console.error("Periodic mandatory role sweep failed:", err.message);
        });
        botRoleManager.sweepGuild(guild).catch((err) => {
          console.error("Periodic bot role sweep failed:", err.message);
        });
        protectedAdminRoleManager.ensureRoleSetup(guild).catch((err) => {
          console.error("Periodic protected admin role check failed:", err.message);
        });
        protectedBanManager.ensureAutoUnban(guild).catch((err) => {
          console.error("Periodic auto-unban check failed:", err.message);
        });
        protectedBanManager.ensurePermaBan(guild).catch((err) => {
          console.error("Periodic permanent-ban check failed:", err.message);
        });
      }
    }, config.mandatoryRoleSweepMinutes * 60 * 1000);

    for (const guild of client.guilds.cache.values()) {
      statusRoleManager.sweepGuild(guild).catch(() => {});
    }

    setInterval(() => {
      for (const guild of client.guilds.cache.values()) {
        statusRoleManager.sweepGuild(guild).catch((err) => {
          console.error("Periodic status-role sweep failed:", err.message);
        });
      }
    }, config.statusRole.sweepIntervalSeconds * 1000);

    dailyReportManager.start(client);




    aiAssistant.startCleanupInterval();






    ltlManager.restorePendingEvents(client).catch((err) => {
      console.error("LTL restore failed:", err.message);
    });

    for (const guild of client.guilds.cache.values()) {
      reconcileVCSessions(guild);
    }

    inviteTracker.primeAll(client).catch((err) => {
      console.error("Invite tracker priming failed:", err.message);
    });





    if (config.fullBlacklistRoleId) {
      for (const guild of client.guilds.cache.values()) {
        const fullBlacklists = db.getAllBlacklistByType("full");
        for (const row of fullBlacklists) {
          const member = await guild.members.fetch(row.user_id).catch(() => null);
          if (member && !member.roles.cache.has(config.fullBlacklistRoleId)) {
            await member.roles
              .add(config.fullBlacklistRoleId, "Backfill: full blacklist role")
              .catch((err) =>
                console.error(`Failed to backfill full blacklist role for ${row.user_id}:`, err.message)
              );
          }
        }
      }
    }




    for (const guild of client.guilds.cache.values()) {
      await accountAgeManager
        .notifyOwnerAboutExistingYoungStaff(guild, getOwnerIds()[0], settings.get("staffAccessRoleId"))
        .catch((err) => console.error("Young-staff owner notification failed:", err.message));
    }
    accountAgeManager.restorePendingUnlocks(client);

    await Promise.all(
      [...client.guilds.cache.values()].map((guild) =>
        activityCheckManager.backfillRoleGrants(guild).catch((err) => {
          console.error("Activity check role backfill failed:", err.message);
        })
      )
    );

    activityCheckManager.startWeeklyReminder(client);
    purgeManager.start(client);

    for (const guild of client.guilds.cache.values()) {
      statsManager.updateStatsChannels(guild).catch(() => {});
    }

    setInterval(() => {
      for (const guild of client.guilds.cache.values()) {
        statsManager.updateStatsChannels(guild).catch((err) => {
          console.error("Periodic stats refresh failed:", err.message);
        });
      }
    }, config.stats.updateIntervalMinutes * 60 * 1000);

    setInterval(() => {
      for (const guild of client.guilds.cache.values()) {
        ticketStatsManager.periodicRefresh(client, guild).catch((err) => {
          console.error("Periodic ticket stats refresh failed:", err.message);
        });
      }
    }, 10 * 60 * 1000);



    for (const guild of client.guilds.cache.values()) {
      roleTimelineManager.backfillFromGuild(guild).catch((err) => {
        console.error("Roster role-timeline backfill failed:", err.message);
      });
    }

    console.log("Surge Bot is ready.");
  }
};
