const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");
const securityManager = require("../handlers/securityManager");

module.exports = {
  name: "roleCreate",
  async execute(role) {
    let actor;
    try {
      const logs = await role.guild.fetchAuditLogs({ type: AuditLogEvent.RoleCreate, limit: 5 });
      const entry = logs.entries.find(
        (e) => e.target?.id === role.id && Date.now() - e.createdTimestamp < 10000
      );
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }







    if (actor && actor.id !== role.guild.client.user.id && !securityManager.isHardcodedTrustedUser(actor.id)) {
      await role.delete("Security: unauthorized role creation").catch((error) => {
        console.error("[SECURITY] Failed to delete unauthorized role:", error.message);
      });

      try {
        await securityManager.emergencyLockdown(
          role.guild,
          actor.id,
          `Created an unauthorized role ("${role.name}") while not on the trusted whitelist.`
        );
      } catch (error) {
        console.error("Anti-nuke (unauthorized role create) lockdown failed:", error.message);
      }
    }

    logManager
      .log(role.guild, {
        type: "create",
        title: "🎭 Role Created",
        actor,
        fields: [{ name: "Role", value: `${role.name} (${role.id})`, inline: true }]
      })
      .catch(() => {});
  }
};
