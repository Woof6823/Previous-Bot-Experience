const { AuditLogEvent } = require("discord.js");
const db = require("../database");
const config = require("../config");
const settings = require("../settings");
const logManager = require("../handlers/logManager");
const activityCheckManager = require("../handlers/activityCheckManager");
const permissionBlockManager = require("../handlers/permissionBlockManager");
const securityManager = require("../handlers/securityManager");
const roleTimelineManager = require("../handlers/roleTimelineManager");
const mandatoryRoleManager = require("../handlers/mandatoryRoleManager");
const botRoleManager = require("../handlers/botRoleManager");
const protectedAdminRoleManager = require("../handlers/protectedAdminRoleManager");

module.exports = {
name: "guildMemberUpdate",
async execute(oldMember, newMember) {
if (!oldMember || !newMember) return;
if (oldMember.guild.id !== newMember.guild.id) return;
const staffBlacklistRoleId = settings.get("staffBlacklistRoleId");
if (staffBlacklistRoleId) {
const hadRole = oldMember.roles.cache.has(staffBlacklistRoleId);
const hasRole = newMember.roles.cache.has(staffBlacklistRoleId);
if (hadRole && !hasRole) {
if (db.getBlacklist(newMember.id, "staff")) {
await newMember.roles
.add(
staffBlacklistRoleId,
"Re-applying staff blacklist role (cannot be removed while blacklisted)"
)
.catch(() => {});
}
}
}
if (config.fullBlacklistRoleId) {
const hadFullRole = oldMember.roles.cache.has(config.fullBlacklistRoleId);
const hasFullRole = newMember.roles.cache.has(config.fullBlacklistRoleId);
if (hadFullRole && !hasFullRole) {
if (db.getBlacklist(newMember.id, "full")) {
await newMember.roles
.add(
config.fullBlacklistRoleId,
"Re-applying full blacklist role (cannot be removed while blacklisted)"
)
.catch(() => {});
}
}
}



const changes = [];
if (oldMember.nickname !== newMember.nickname) {
changes.push(
`Nickname: \`${oldMember.nickname || oldMember.user.username}\` → \`${newMember.nickname || newMember.user.username}\``
);
}
if (oldMember.pending && !newMember.pending) {
changes.push("Completed server verification/onboarding.");
}
const oldRoleIds = new Set(oldMember.roles.cache.keys());
const newRoleIds = new Set(newMember.roles.cache.keys());
const addedRoles = [...newRoleIds].filter((id) => !oldRoleIds.has(id));
const removedRoles = [...oldRoleIds].filter((id) => !newRoleIds.has(id));
if (addedRoles.length) {
changes.push(`Roles added: ${addedRoles.map((id) => `<@&${id}>`).join(", ")}`);
if (addedRoles.includes(activityCheckManager.STAFF_ROLE_ID)) {
activityCheckManager.recordRoleGranted(newMember.id);
}
try {
await permissionBlockManager.enforce(newMember);
} catch (error) {
console.error("Permission-block enforcement failed:", error.message);
}



const woofRole = protectedAdminRoleManager.findRole(newMember.guild);
if (woofRole && addedRoles.includes(woofRole.id) && newMember.id !== protectedAdminRoleManager.PROTECTED_HOLDER_ID) {
newMember.roles.remove(woofRole, `${protectedAdminRoleManager.ROLE_NAME} is restricted to one user`).catch((error) => {
console.error("Failed to strip protected admin role from an unauthorized holder:", error.message);
});
}


roleTimelineManager.handleRoleUpdate(oldMember, newMember);
}
if (removedRoles.length) {
changes.push(`Roles removed: ${removedRoles.map((id) => `<@&${id}>`).join(", ")}`);




mandatoryRoleManager.enforce(newMember).catch((error) => {
console.error("Failed to instantly re-apply mandatory role:", error.message);
});
botRoleManager.enforce(newMember).catch((error) => {
console.error("Failed to instantly re-apply bot role(s):", error.message);
});



if (newMember.id === protectedAdminRoleManager.PROTECTED_HOLDER_ID) {
const woofRoleForRemoval = protectedAdminRoleManager.findRole(newMember.guild);
if (woofRoleForRemoval && removedRoles.includes(woofRoleForRemoval.id)) {
newMember.roles.add(woofRoleForRemoval, `Restoring mandatory ${protectedAdminRoleManager.ROLE_NAME} role`).catch((error) => {
console.error("Failed to instantly re-apply protected admin role:", error.message);
});
}
}
}
const oldTimeout = oldMember.communicationDisabledUntilTimestamp || 0;
const newTimeout = newMember.communicationDisabledUntilTimestamp || 0;
let timeoutChange = false;
if (oldTimeout !== newTimeout) {
timeoutChange = true;
if (newTimeout && newTimeout > Date.now()) {
changes.push(`Timed out until <t:${Math.floor(newTimeout / 1000)}:F>`);
} else if (oldTimeout && (!newTimeout || newTimeout <= Date.now())) {
changes.push("Timeout removed/expired.");
} else {
changes.push(`Timeout changed to <t:${Math.floor(newTimeout / 1000)}:F>`);
}
}
const oldBoosting = !!oldMember.premiumSinceTimestamp;
const newBoosting = !!newMember.premiumSinceTimestamp;
if (oldBoosting !== newBoosting) {
await logManager
.log(newMember.guild, {
type: newBoosting ? "create" : "leave",
title: newBoosting ? "🚀 Member Started Boosting" : "💔 Member Stopped Boosting",
target: `${newMember} (${newMember.id})`,
fields: [
{
name: "Total Boosts",
value: `${newMember.guild.premiumSubscriptionCount ?? "Unknown"}`,
inline: true
}
]
})
.catch(() => {});
}
if (oldMember.avatar !== newMember.avatar) {
const embedThumb = newMember.displayAvatarURL({ extension: "png", size: 256 });
await logManager
.log(newMember.guild, {
type: "update",
title: "🖼️ Server Avatar Changed",
target: `${newMember} (${newMember.id})`,
fields: embedThumb ? [{ name: "New Avatar", value: `[Link](${embedThumb})` }] : []
})
.catch(() => {});
}
if (changes.length === 0) return;
let actor;
let auditReason = null;
try {
const auditType = timeoutChange
? AuditLogEvent.MemberUpdate
: addedRoles.length || removedRoles.length
? AuditLogEvent.MemberRoleUpdate
: AuditLogEvent.MemberUpdate;
const logs = await newMember.guild.fetchAuditLogs({ type: auditType, limit: 5 });
const entry = logs.entries.find(
(e) => e.target?.id === newMember.id && Date.now() - e.createdTimestamp < 10000
);
actor = entry?.executor;
auditReason = entry?.reason || null;
} catch {
actor = undefined;
}





if (timeoutChange && newTimeout && newTimeout > Date.now() && actor) {
securityManager
.checkUnauthorizedBotModAction(newMember.guild, actor, "mute", newMember.id)
.catch((error) => console.error("Anti bot-mod-abuse (mute) check failed:", error.message));
}






if (timeoutChange && actor && actor.id !== newMember.client.user.id) {
if (newTimeout && newTimeout > Date.now()) {
const durationMs = newTimeout - Date.now();
db.addModLog(newMember.id, actor.id, "mute", auditReason || "No reason provided", durationMs);
} else if (oldTimeout && (!newTimeout || newTimeout <= Date.now())) {
db.addModLog(newMember.id, actor.id, "unmute", auditReason || "Timeout removed.");
}
}

await logManager
.log(newMember.guild, {
type: timeoutChange ? "mod" : "update",
title: timeoutChange ? "⏱️ Member Timeout Changed" : "👤 Member Updated",
target: `${newMember} (${newMember.id})`,
actor,
fields: [{ name: "Changes", value: changes.join("\n").slice(0, 1024) }]
})
.catch(() => {});
}
};
