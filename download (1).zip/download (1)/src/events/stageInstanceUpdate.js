const logManager = require("../handlers/logManager");

module.exports = {
  name: "stageInstanceUpdate",
  async execute(oldInstance, newInstance) {
    if (!newInstance.guild) return;
    if (oldInstance.topic === newInstance.topic) return;

    await logManager
      .log(newInstance.guild, {
        type: "update",
        title: "🎙️ Stage Topic Changed",
        fields: [
          { name: "Channel", value: `${newInstance.channel || newInstance.channelId}`, inline: true },
          { name: "Topic", value: `\`${oldInstance.topic}\` → \`${newInstance.topic}\`` }
        ]
      })
      .catch(() => {});
  }
};
