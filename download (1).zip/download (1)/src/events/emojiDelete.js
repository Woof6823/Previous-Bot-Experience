const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");
const securityManager = require("../handlers/securityManager");

module.exports = {
  name: "emojiDelete",
  async execute(emoji) {
    try {
      await securityManager.checkEmojiDeleteNuke(emoji.guild, emoji.name);
    } catch (error) {
      console.error("Anti-emoji-delete check failed:", error.message);
    }

    let actor;
    try {
      const logs = await emoji.guild.fetchAuditLogs({ type: AuditLogEvent.EmojiDelete, limit: 5 });
      const entry = logs.entries.find((e) => Date.now() - e.createdTimestamp < 10000);
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }

    await logManager
      .log(emoji.guild, {
        type: "delete",
        title: "🗑️ Emoji Deleted",
        actor,
        fields: [{ name: "Emoji", value: `\`:${emoji.name}:\``, inline: true }]
      })
      .catch(() => {});
  }
};
