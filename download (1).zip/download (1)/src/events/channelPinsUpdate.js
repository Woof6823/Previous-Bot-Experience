const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");

const lastPinnedCount = new Map();

module.exports = {
  name: "channelPinsUpdate",
  async execute(channel) {
    if (!channel.guild) return;

    const pinned = await channel.messages.fetchPinned().catch(() => null);
    if (!pinned) return;

    const previousCount = lastPinnedCount.get(channel.id) ?? pinned.size;
    lastPinnedCount.set(channel.id, pinned.size);

    const wasPin = pinned.size > previousCount;
    const wasUnpin = pinned.size < previousCount;
    if (!wasPin && !wasUnpin) return;

    let actor;
    try {
      const logs = await channel.guild.fetchAuditLogs({
        type: wasPin ? AuditLogEvent.MessagePin : AuditLogEvent.MessageUnpin,
        limit: 5
      });
      const entry = logs.entries.find((e) => Date.now() - e.createdTimestamp < 10000);
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }

    const latestPinned = pinned.first();

    await logManager
      .log(channel.guild, {
        type: wasPin ? "create" : "delete",
        title: wasPin ? "📌 Message Pinned" : "📌 Message Unpinned",
        actor,
        fields: [
          { name: "Channel", value: `${channel}`, inline: true },
          ...(latestPinned
            ? [
                {
                  name: wasPin ? "Message" : "Still-Pinned Message (most recent)",
                  value: `[Jump to message](${latestPinned.url})`,
                  inline: true
                },
                { name: "Message ID", value: latestPinned.id, inline: true }
              ]
            : [])
        ]
      })
      .catch(() => {});
  }
};
