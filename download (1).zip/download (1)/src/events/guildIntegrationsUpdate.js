const logManager = require("../handlers/logManager");

module.exports = {
  name: "guildIntegrationsUpdate",
  async execute(guild) {
    await logManager
      .log(guild, {
        type: "update",
        title: "🔗 Server Integrations Updated",
        description: "One or more integrations (bots, Twitch/YouTube subscriptions, etc.) changed."
      })
      .catch(() => {});
  }
};
