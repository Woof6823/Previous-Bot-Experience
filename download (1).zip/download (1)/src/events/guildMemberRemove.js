const { AuditLogEvent } = require("discord.js");
const db = require("../database");
const logManager = require("../handlers/logManager");
const securityManager = require("../handlers/securityManager");
const ticketManager = require("../handlers/ticketManager");

const EVENT_GOAL = 7000;

async function update7000EventCounter(guild, client) {
	const messageId = db.getSetting("7000event_message_id");
	const channelId = db.getSetting("7000event_channel_id");
	if (!messageId || !channelId) return;
	const channel = await client.channels.fetch(channelId).catch(() => null);
	if (!channel) return;
	const msg = await channel.messages.fetch(messageId).catch(() => null);
	if (!msg) return;
	const remaining = Math.max(0, EVENT_GOAL - guild.memberCount);
	const newContent = msg.content.replace(
		/Members Remaining To 7000 - \*\*\d+\*\*/,
		`Members Remaining To 7000 - **${remaining}**`
	);
	await msg.edit({ content: newContent }).catch(() => {});
}

async function findKickEntry(guild, userId) {
	try {
		const auditLogs = await guild.fetchAuditLogs({
			type: AuditLogEvent.MemberKick,
			limit: 10
		});
		const entry = auditLogs.entries.find((log) => {
			if (!log.executor) return false;
			if (log.target?.id !== userId) return false;
			return Date.now() - log.createdTimestamp < 10_000;
		});
		return entry || null;
	} catch (error) {
		console.error("Failed to fetch kick audit log:", error.message);
		return null;
	}
}

module.exports = {
	name: "guildMemberRemove",
	async execute(member) {
		if (!member?.guild || !member?.user) return;
		const guild = member.guild;

		db.addMemberEvent("leave", member.id);

		if (!member.user.bot) {
			const userTickets = db.getAllOpenTickets().filter((t) => t.user_id === member.id);
			for (const ticket of userTickets) {
				await ticketManager
					.closeTicket(
						guild,
						ticket.channel_id,
						"Ticket owner left the server (auto-closed)",
						guild.client.user.id
					)
					.catch((err) =>
						console.error(
							`Failed to auto-close ticket ${ticket.channel_id} on member leave:`,
							err.message
						)
					);
			}
		}

		const kickEntry = await findKickEntry(guild, member.id);
		const actor = kickEntry?.executor || null;

		if (actor && actor.id !== guild.client.user.id) {
			try {
				await securityManager.checkKickSpam(guild, actor.id);
			} catch (error) {
				console.error("Anti-nuke (kick) check failed:", error.message);
			}
		}

		if (actor) {
			try {
				await securityManager.checkUnauthorizedBotModAction(guild, actor, "kick", member.id);
			} catch (error) {
				console.error("Anti bot-mod-abuse (kick) check failed:", error.message);
			}
		}

		if (actor && actor.id !== guild.client.user.id) {
			db.addModLog(member.id, actor.id, "kick", kickEntry.reason || "No reason provided");
		}

		const fields = [];
		if (kickEntry) {
			fields.push({
				name: "Member",
				value: `${member.user}`,
				inline: true
			});
			fields.push({
				name: "Executor",
				value: actor ? `${actor.tag || actor.username || "Unknown"} (${actor.id})` : "Unknown",
				inline: true
			});
			if (kickEntry.reason) {
				fields.push({
					name: "Reason",
					value: kickEntry.reason
				});
			}
		} else {
			fields.push({
				name: "Member",
				value: `${member.user}`,
				inline: true
			});
		}
		fields.push({
			name: "Member Count",
			value: `${guild.memberCount}`,
			inline: true
		});

		await logManager
			.log(guild, {
				type: "leave",
				title: kickEntry ? "👢 Member Kicked" : "📤 Member Left",
				actor: kickEntry ? actor : member.user,
				actorLabel: kickEntry ? "👤 Kicked by" : "👤 Member",
				fields
			})
			.catch((error) => {
				console.error("Failed to log member removal:", error.message);
			});

		update7000EventCounter(guild, member.guild.client);
	}
};
