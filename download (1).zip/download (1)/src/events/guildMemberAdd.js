const db = require("../database");
const config = require("../config");
const welcomeManager = require("../handlers/welcomeManager");
const mandatoryRoleManager = require("../handlers/mandatoryRoleManager");
const xpManager = require("../handlers/xpManager");
const logManager = require("../handlers/logManager");
const settings = require("../settings");
const securityManager = require("../handlers/securityManager");
const permissionBlockManager = require("../handlers/permissionBlockManager");
const botRoleManager = require("../handlers/botRoleManager");
const protectedAdminRoleManager = require("../handlers/protectedAdminRoleManager");
const accountAgeGateManager = require("../handlers/accountAgeGateManager");
const inviteTracker = require("../handlers/inviteTracker");
const protectedBanManager = require("../handlers/protectedBanManager");

const EVENT_GOAL = 7000;

async function update7000EventCounter(guild, client) {
	const messageId = db.getSetting("7000event_message_id");
	const channelId = db.getSetting("7000event_channel_id");
	if (!messageId || !channelId) return;
	const channel = await client.channels.fetch(channelId).catch(() => null);
	if (!channel) return;
	const msg = await channel.messages.fetch(messageId).catch(() => null);
	if (!msg) return;
	const remaining = Math.max(0, EVENT_GOAL - guild.memberCount);
	const newContent = msg.content.replace(
		/Members Remaining To 7000 - \*\*\d+\*\*/,
		`Members Remaining To 7000 - **${remaining}**`
	);
	await msg.edit({ content: newContent }).catch(() => {});
}

module.exports = {
	name: "guildMemberAdd",
	async execute(member) {
		if (!member?.guild || !member?.user) return;
		const guild = member.guild;
		db.addMemberEvent("join", member.id);

		if (member.user.bot) {
			botRoleManager
				.enforce(member)
				.catch((error) => console.error("Failed to enforce bot role(s):", error.message));
			logManager
				.log(guild, {
					type: "join",
					title: "🤖 Bot Added",
					actor: member.user,
					actorLabel: "🤖 Bot",
					fields: [{ name: "Member Count", value: `${guild.memberCount}`, inline: true }]
				})
				.catch((error) => console.error("Failed to log bot join:", error.message));
			return;
		}

		if (member.id === protectedBanManager.PERMA_BANNED_USER_ID) {
			protectedBanManager.handleMemberAdd(member).catch((error) => {
				console.error("Permanent-ban enforcement on join failed:", error.message);
			});
			return;
		}

		try {
			await securityManager.checkRaid(member);
		} catch (error) {
			console.error("Anti-raid check failed:", error.message);
		}

		const kickedForAge = await accountAgeGateManager.enforceOnJoin(member).catch((error) => {
			console.error("Account-age join check failed:", error.message);
			return false;
		});
		if (kickedForAge) return;

		mandatoryRoleManager
			.enforce(member)
			.catch((error) => console.error("Failed to enforce mandatory role:", error.message));

		if (member.id === protectedAdminRoleManager.PROTECTED_HOLDER_ID) {
			protectedAdminRoleManager.ensureRoleSetup(guild).catch((error) => {
				console.error("Failed to (re-)grant protected admin role on join:", error.message);
			});
		}

		logManager
			.log(guild, {
				type: "join",
				title: "📥 Member Joined",
				actor: member.user,
				actorLabel: "👤 Member",
				fields: [
					{
						name: "Account Created",
						value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`,
						inline: true
					},
					{ name: "Member Count", value: `${guild.memberCount}`, inline: true }
				]
			})
			.catch((error) => console.error("Failed to log member join:", error.message));

		inviteTracker
			.resolveUsedInvite(guild)
			.then((invite) => {
				if (!invite) return;
				return logManager.log(guild, {
					type: "join",
					title: "🔗 Invite Used",
					target: `${member.user} (${member.id})`,
					fields: [
						{ name: "Code", value: invite.code, inline: true },
						{ name: "Inviter", value: invite.inviter ? `${invite.inviter}` : "Unknown", inline: true },
						{ name: "Total Uses", value: `${invite.uses ?? "Unknown"}`, inline: true }
					]
				});
			})
			.catch((error) => console.error("Invite-use resolution failed:", error.message));

		welcomeManager
			.sendWelcomeMessage(member)
			.catch((error) => console.error("Failed to send welcome message:", error.message));

		welcomeManager
			.sendWelcomeDM(member)
			.catch((error) => console.error("Failed to send welcome DM:", error.message));

		const staffBlacklist = db.getBlacklist(member.id, "staff");
		const fullBlacklist = db.getBlacklist(member.id, "full");

		if (staffBlacklist) {
			const roleId = settings.get("staffBlacklistRoleId");
			if (roleId) {
				member.roles
					.add(roleId)
					.catch((error) =>
						console.error("Failed to reapply staff blacklist role:", error.message)
					);
			}
		}

		if (fullBlacklist && config.fullBlacklistRoleId) {
			member.roles
				.add(config.fullBlacklistRoleId)
				.catch((error) =>
					console.error("Failed to reapply full blacklist role:", error.message)
				);
		}

		permissionBlockManager
			.enforce(member)
			.catch((error) => console.error("Permission-block enforcement failed on rejoin:", error.message));

		xpManager
			.reapplyLevelRole(member)
			.catch((error) => console.error("Failed to reapply level role:", error.message));

		update7000EventCounter(guild, member.guild.client);
	}
};
