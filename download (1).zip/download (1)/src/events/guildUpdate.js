const logManager = require("../handlers/logManager");
const securityManager = require("../handlers/securityManager");

module.exports = {
  name: "guildUpdate",
  async execute(oldGuild, newGuild) {
    try {
      await securityManager.checkOwnershipTransfer(oldGuild, newGuild);
    } catch (error) {
      console.error("Anti-ownership-transfer check failed:", error.message);
    }

    const changes = [];
    if (oldGuild.name !== newGuild.name)
      changes.push(`Name: \`${oldGuild.name}\` → \`${newGuild.name}\``);
    if (oldGuild.iconURL() !== newGuild.iconURL()) changes.push("Icon changed.");
    if (oldGuild.bannerURL() !== newGuild.bannerURL()) changes.push("Banner changed.");
    if (oldGuild.ownerId !== newGuild.ownerId)
      changes.push(`Owner changed: <@${oldGuild.ownerId}> → <@${newGuild.ownerId}>`);
    if (oldGuild.verificationLevel !== newGuild.verificationLevel)
      changes.push("Verification level changed.");
    if (oldGuild.premiumTier !== newGuild.premiumTier)
      changes.push(`Boost tier: \`${oldGuild.premiumTier}\` → \`${newGuild.premiumTier}\``);
    if (oldGuild.systemChannelId !== newGuild.systemChannelId)
      changes.push("System channel changed.");
    if (oldGuild.rulesChannelId !== newGuild.rulesChannelId) changes.push("Rules channel changed.");
    if (oldGuild.afkChannelId !== newGuild.afkChannelId) changes.push("AFK channel changed.");
    if (oldGuild.afkTimeout !== newGuild.afkTimeout) changes.push("AFK timeout changed.");

    if (changes.length === 0) return;

    await logManager
      .log(newGuild, {
        type: "update",
        title: "🏠 Server Settings Updated",
        fields: [{ name: "Changes", value: changes.join("\n").slice(0, 1024) }]
      })
      .catch(() => {});
  }
};
