const farmingDetector = require("../handlers/farmingDetector");
const logManager = require("../handlers/logManager");
const trainingManager = require("../handlers/trainingManager");
const { AuditLogEvent } = require("discord.js");

async function findDeleter(guild, message) {





  try {
    const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.MessageDelete, limit: 5 });
    const entry = logs.entries.find(
      (e) =>
        e.target?.id === message.author?.id &&
        e.extra?.channel?.id === message.channel.id &&
        Date.now() - e.createdTimestamp < 10000
    );
    return entry ? entry.executor : null;
  } catch {
    return null;
  }
}

module.exports = {
  name: "messageDelete",
  async execute(message, client) {
    if (!message.guild) return;
    farmingDetector.handlePossibleAlertDeletion(client, message).catch((err) => {
      console.error("Error handling possible farming-alert deletion:", err);
    });



    trainingManager.handleMessageDeleted(client, message.channel.id, message.id).catch(() => {});

    if (message.author?.bot) return;
    const deleter = await findDeleter(message.guild, message);
    const fields = [
      { name: "Channel", value: `${message.channel}`, inline: true },
      { name: "Author", value: `${message.author || "Unknown"}`, inline: true },
      {
        name: "Content",
        value: message.content
          ? message.content.slice(0, 1000)
          : "*(no text content — embed/attachment only)*"
      }
    ];
    logManager
      .log(message.guild, {
        type: "delete",
        title: "🗑️ Message Deleted",



        actor: deleter || undefined,
        fields
      })
      .catch(() => {});
  }
};
