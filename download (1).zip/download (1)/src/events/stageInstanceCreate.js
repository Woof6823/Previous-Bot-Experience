const logManager = require("../handlers/logManager");

module.exports = {
  name: "stageInstanceCreate",
  async execute(stageInstance) {
    if (!stageInstance.guild) return;
    await logManager
      .log(stageInstance.guild, {
        type: "create",
        title: "🎙️ Stage Started",
        fields: [
          { name: "Channel", value: `${stageInstance.channel || stageInstance.channelId}`, inline: true },
          { name: "Topic", value: stageInstance.topic || "None" }
        ]
      })
      .catch(() => {});
  }
};
