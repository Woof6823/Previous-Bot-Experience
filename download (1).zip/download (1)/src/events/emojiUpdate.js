const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");

module.exports = {
  name: "emojiUpdate",
  async execute(oldEmoji, newEmoji) {
    if (!newEmoji.guild) return;
    if (oldEmoji.name === newEmoji.name) return;

    let actor;
    try {
      const logs = await newEmoji.guild.fetchAuditLogs({ type: AuditLogEvent.EmojiUpdate, limit: 5 });
      const entry = logs.entries.find(
        (e) => e.target?.id === newEmoji.id && Date.now() - e.createdTimestamp < 10000
      );
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }

    await logManager
      .log(newEmoji.guild, {
        type: "update",
        title: "😀 Emoji Renamed",
        actor,
        fields: [{ name: "Change", value: `\`:${oldEmoji.name}:\` → \`:${newEmoji.name}:\`` }]
      })
      .catch(() => {});
  }
};
