const logManager = require("../handlers/logManager");
const creatorCodeManager = require("../handlers/creatorCodeManager");

module.exports = {
  name: "threadCreate",
  async execute(thread) {
    if (!thread.guild) return;

    creatorCodeManager
      .handleThreadCreate(thread)
      .catch((err) => console.error("Creator-code thread handling failed:", err.message));

    await logManager
      .log(thread.guild, {
        type: "create",
        title: "🧵 Thread Created",
        fields: [
          { name: "Thread", value: `${thread}`, inline: true },
          { name: "Parent", value: thread.parent ? `${thread.parent}` : "Unknown", inline: true }
        ]
      })
      .catch(() => {});
  }
};
