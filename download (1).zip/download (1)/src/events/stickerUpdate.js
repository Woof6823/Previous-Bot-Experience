const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");

module.exports = {
  name: "stickerUpdate",
  async execute(oldSticker, newSticker) {
    if (!newSticker.guild) return;

    const changes = [];
    if (oldSticker.name !== newSticker.name) {
      changes.push(`Name: \`${oldSticker.name}\` → \`${newSticker.name}\``);
    }
    if (oldSticker.description !== newSticker.description) {
      changes.push("Description changed.");
    }
    if (oldSticker.tags !== newSticker.tags) {
      changes.push(`Tags: \`${oldSticker.tags}\` → \`${newSticker.tags}\``);
    }
    if (changes.length === 0) return;

    let actor;
    try {
      const logs = await newSticker.guild.fetchAuditLogs({ type: AuditLogEvent.StickerUpdate, limit: 5 });
      const entry = logs.entries.find(
        (e) => e.target?.id === newSticker.id && Date.now() - e.createdTimestamp < 10000
      );
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }

    await logManager
      .log(newSticker.guild, {
        type: "update",
        title: "🏷️ Sticker Updated",
        actor,
        fields: [
          { name: "Sticker", value: `${newSticker.name} (${newSticker.id})`, inline: true },
          { name: "Changes", value: changes.join("\n").slice(0, 1024) }
        ]
      })
      .catch(() => {});
  }
};
