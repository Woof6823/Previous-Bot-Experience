const config = require("../config");
const db = require("../database");
const xpManager = require("../handlers/xpManager");

module.exports = {
  name: "messageReactionAdd",
  async execute(reaction, user) {
    try {
      if (reaction.partial) await reaction.fetch();
      if (user.partial) await user.fetch();
      if (reaction.message.partial) await reaction.message.fetch();
    } catch {
      return;
    }

    if (user.bot) return;
    if (!reaction.message.guild) return;

    if (!db.canEarnReactionXp(user.id, config.levels.reactionXpCooldownSeconds)) return;

    await xpManager
      .awardXp(reaction.message.guild, user.id, config.levels.reactionXp)
      .catch((err) => {
        console.error("Failed to award reaction XP:", err.message);
      });
  }
};
