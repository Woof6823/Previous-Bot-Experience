const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");

module.exports = {
  name: "stickerDelete",
  async execute(sticker) {
    if (!sticker.guild) return;
    let actor;
    try {
      const logs = await sticker.guild.fetchAuditLogs({ type: AuditLogEvent.StickerDelete, limit: 5 });
      const entry = logs.entries.find((e) => Date.now() - e.createdTimestamp < 10000);
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }

    await logManager
      .log(sticker.guild, {
        type: "delete",
        title: "🗑️ Sticker Deleted",
        actor,
        fields: [{ name: "Sticker", value: `${sticker.name} (${sticker.id})`, inline: true }]
      })
      .catch(() => {});
  }
};
