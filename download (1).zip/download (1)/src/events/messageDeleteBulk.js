const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");
const trainingManager = require("../handlers/trainingManager");

module.exports = {
  name: "messageDeleteBulk",
  async execute(messages, channel) {
    const guild = channel.guild;
    if (!guild) return;



    for (const message of messages.values()) {
      trainingManager.handleMessageDeleted(channel.client, channel.id, message.id).catch(() => {});
    }

    let actor;
    try {
      const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.MessageBulkDelete, limit: 5 });
      const entry = logs.entries.find(
        (e) => e.extra?.channel?.id === channel.id && Date.now() - e.createdTimestamp < 15000
      );
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }

    await logManager
      .log(guild, {
        type: "mod",
        title: "🧹 Bulk Message Delete",
        actor,
        fields: [
          { name: "Channel", value: `${channel}`, inline: true },
          { name: "Count", value: `${messages.size}`, inline: true }
        ]
      })
      .catch(() => {});
  }
};
