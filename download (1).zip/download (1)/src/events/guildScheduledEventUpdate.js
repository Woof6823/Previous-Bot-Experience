const { AuditLogEvent, GuildScheduledEventStatus } = require("discord.js");
const logManager = require("../handlers/logManager");

module.exports = {
  name: "guildScheduledEventUpdate",
  async execute(oldEvent, newEvent) {
    if (!newEvent.guild) return;

    const changes = [];
    if (oldEvent.name !== newEvent.name) {
      changes.push(`Name: \`${oldEvent.name}\` → \`${newEvent.name}\``);
    }
    if (oldEvent.description !== newEvent.description) changes.push("Description changed.");
    if (oldEvent.scheduledStartTimestamp !== newEvent.scheduledStartTimestamp) {
      changes.push("Start time changed.");
    }
    if (oldEvent.entityMetadata?.location !== newEvent.entityMetadata?.location) {
      changes.push("Location changed.");
    }

    let statusChangeTitle = null;
    if (oldEvent.status !== newEvent.status) {
      if (newEvent.status === GuildScheduledEventStatus.Active) statusChangeTitle = "📅 Scheduled Event Started";
      else if (newEvent.status === GuildScheduledEventStatus.Completed) statusChangeTitle = "📅 Scheduled Event Ended";
      else if (newEvent.status === GuildScheduledEventStatus.Canceled) statusChangeTitle = "📅 Scheduled Event Cancelled";
    }

    if (changes.length === 0 && !statusChangeTitle) return;

    let actor;
    try {
      const logs = await newEvent.guild.fetchAuditLogs({
        type: AuditLogEvent.GuildScheduledEventUpdate,
        limit: 5
      });
      const entry = logs.entries.find(
        (e) => e.target?.id === newEvent.id && Date.now() - e.createdTimestamp < 10000
      );
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }

    await logManager
      .log(newEvent.guild, {
        type: "update",
        title: statusChangeTitle || "📅 Scheduled Event Updated",
        actor,
        fields: [
          { name: "Event", value: `${newEvent.name} (${newEvent.id})` },
          ...(changes.length ? [{ name: "Changes", value: changes.join("\n").slice(0, 1024) }] : [])
        ]
      })
      .catch(() => {});
  }
};
