const logManager = require("../handlers/logManager");
const inviteTracker = require("../handlers/inviteTracker");

module.exports = {
  name: "inviteDelete",
  async execute(invite) {
    if (!invite.guild) return;
    inviteTracker.removeInvite(invite.code, invite.guild.id);
    await logManager
      .log(invite.guild, {
        type: "delete",
        title: "🗑️ Invite Deleted",
        fields: [
          { name: "Code", value: invite.code, inline: true },
          { name: "Channel", value: invite.channel ? `${invite.channel}` : "Unknown", inline: true }
        ]
      })
      .catch(() => {});
  }
};
