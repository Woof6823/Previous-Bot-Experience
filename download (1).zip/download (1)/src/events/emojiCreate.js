const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");

module.exports = {
  name: "emojiCreate",
  async execute(emoji) {
    let actor;
    try {
      const logs = await emoji.guild.fetchAuditLogs({ type: AuditLogEvent.EmojiCreate, limit: 5 });
      const entry = logs.entries.find(
        (e) => e.target?.id === emoji.id && Date.now() - e.createdTimestamp < 10000
      );
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }

    await logManager
      .log(emoji.guild, {
        type: "create",
        title: "😀 Emoji Created",
        actor,
        fields: [{ name: "Emoji", value: `${emoji} \`:${emoji.name}:\``, inline: true }]
      })
      .catch(() => {});
  }
};
