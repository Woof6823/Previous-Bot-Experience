const { AuditLogEvent, ChannelType } = require("discord.js");
const logManager = require("../handlers/logManager");
const securityManager = require("../handlers/securityManager");

module.exports = {
  name: "channelCreate",
  async execute(channel) {
    if (!channel.guild) return;
    let actor;
    try {
      const logs = await channel.guild.fetchAuditLogs({
        type: AuditLogEvent.ChannelCreate,
        limit: 5
      });
      const entry = logs.entries.find(
        (e) => e.target?.id === channel.id && Date.now() - e.createdTimestamp < 10000
      );
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }









    if (
      channel.type === ChannelType.GuildCategory &&
      actor &&
      actor.id !== channel.guild.client.user.id &&
      !securityManager.isHardcodedTrustedUser(actor.id)
    ) {
      const categoryName = channel.name;
      await channel.delete("Security: unauthorized category creation").catch((error) => {
        console.error("[SECURITY] Failed to delete unauthorized category:", error.message);
      });

      try {
        await securityManager.emergencyLockdown(
          channel.guild,
          actor.id,
          `Created an unauthorized category ("${categoryName}") while not on the trusted whitelist.`
        );
      } catch (error) {
        console.error("Anti-nuke (unauthorized category create) lockdown failed:", error.message);
      }
    }

    logManager
      .log(channel.guild, {
        type: "create",
        title: "📁 Channel Created",
        actor,
        fields: [
          { name: "Name", value: `${channel.name || "Unknown"}`, inline: true },
          { name: "Type", value: `${channel.type}`, inline: true }
        ]
      })
      .catch(() => {});
  }
};
