const modalHandler = require("../handlers/modalHandler");
const buttonHandler = require("../handlers/buttonHandler");
const config = require("../config");
const db = require("../database");
const blockedWords = require("../handlers/blockedWordsManager");
const afkManager = require("../handlers/afkManager");
const {
  hasStaffAccess,
  isOwner
} = require("../utils/staffAccess");
const leaderboardManager = require("../handlers/leaderboardManager");
const {
  buildStaffStatsEmbed,
  buildStaffStatsRow
} = require("../handlers/staffStatsManager");
const suggestionsManager = require("../handlers/suggestionsManager");
const raceManager = require("../handlers/raceManager");
const guessGameManager = require("../handlers/guessGameManager");
const {
  buildCategoryEmbed
} = require("../handlers/commandsGuideBuilder");
const commandsGuideBuilder = require("../handlers/commandsGuideBuilder");
const statusRoleManager = require("../handlers/statusRoleManager");
const trainingManager = require("../handlers/trainingManager");
const securityManager = require("../handlers/securityManager");
const accountAgeGateManager = require("../handlers/accountAgeGateManager");

module.exports = {
  name: "interactionCreate",

  async execute(interaction, client) {
    try {


      if (
        interaction.isChatInputCommand() &&
        interaction.commandName === "afk"
      ) {
        const reason =
          interaction.options.getString("reason") || "";

        if (afkManager.containsDisallowedPing(reason)) {
          await interaction.reply({
            content:
              "🚫 AFK reasons can't include @everyone, @here, or a user ping — this AFK is not allowed.",
            flags: 64,
            allowedMentions: {
              parse: []
            }
          });

          return;
        }

        await afkManager.setAfk(
          interaction.user.id,
          reason
        );

        await interaction.reply({
          content:
            `💤 <@${interaction.user.id}> is now AFK: **${reason || "AFK"}**`,
          flags: 64,
          allowedMentions: {
            parse: []
          }
        });

        return;
      }



      if (
        interaction.isStringSelectMenu() &&
        interaction.customId === "ticket_select"
      ) {
        const type = interaction.values[0];

        await modalHandler.handleTicketButtonClick(
          interaction,
          type
        );

        return;
      }

      if (
        interaction.isStringSelectMenu() &&
        interaction.customId === "staffcommands_category"
      ) {
        if (!hasStaffAccess(interaction.member)) {
          await interaction.reply({
            content:
              "🚫 You don't have permission to use this.",
            flags: 64
          });

          return;
        }

        const embed = buildCategoryEmbed(
          client,
          interaction.values[0],
          commandsGuideBuilder.ALL_STAFF_CATEGORIES
        );

        await interaction.reply({
          embeds: [embed],
          flags: 64
        });

        return;
      }

      if (
        interaction.isStringSelectMenu() &&
        interaction.customId === "help_category"
      ) {
        if (!isOwner(interaction.user.id)) {
          await interaction.reply({
            content:
              "🚫 Only the bot owner can use this.",
            flags: 64
          });

          return;
        }

        try {
          const helpManager =
            require("../handlers/helpManager");

          const embed =
            helpManager.buildCategoryEmbed(
              client,
              interaction.values[0]
            );

          await interaction.reply({
            embeds: [embed],
            flags: 64
          });
        } catch {
          await interaction.reply({
            content:
              "Help dropdown isn't set up on this bot.",
            flags: 64
          });
        }

        return;
      }



      if (
        interaction.isRoleSelectMenu() &&
        interaction.customId.startsWith("perm_select_")
      ) {
        if (!isOwner(interaction.user.id)) {
          await interaction.reply({
            content:
              "🚫 Only the bot owner can do this.",
            flags: 64
          });

          return;
        }

        const action =
          interaction.customId.replace(
            "perm_select_",
            ""
          );

        db.setModRoles(
          action,
          interaction.values
        );

        const roleList = interaction.values.length
          ? interaction.values
              .map((id) => `<@&${id}>`)
              .join(", ")
          : "*(nobody)*";

        await interaction.reply({
          content:
            `✅ **${action}** permission set to: ${roleList}`,
          flags: 64,
          allowedMentions: {
            parse: []
          }
        });

        return;
      }



      if (interaction.isButton()) {


        if (interaction.customId === "perm_done") {
          if (!isOwner(interaction.user.id)) {
            await interaction.reply({
              content:
                "🚫 Only the bot owner can do this.",
              flags: 64
            });

            return;
          }

          await interaction.reply({
            content:
              "✅ Permissions saved.",
            flags: 64
          });

          return;
        }

        if (interaction.customId === "perm_reset") {
          if (!isOwner(interaction.user.id)) {
            await interaction.reply({
              content:
                "🚫 Only the bot owner can do this.",
              flags: 64
            });

            return;
          }

          db.resetModPermissions();

          await interaction.reply({
            content:
              "🗑️ All moderation permissions cleared. Run `*setupperms` again to reassign.",
            flags: 64
          });

          return;
        }



        if (
          interaction.customId.startsWith(
            "security_restore_"
          )
        ) {
          if (!isOwner(interaction.user.id)) {
            await interaction.reply({
              content:
                "🚫 Only an owner can restore roles from a security lockdown.",
              flags: 64
            });

            return;
          }

          await interaction
            .deferReply({ flags: 64 })
            .catch(() => {});

          const lockdownId =
            interaction.customId.replace(
              "security_restore_",
              ""
            );

          const result =
            await securityManager.restoreLockdownRoles(
              interaction.guild,
              lockdownId
            );

          await interaction
            .editReply({ content: result.message })
            .catch(() => {});

          return;
        }



        if (interaction.customId.startsWith("accountagekick_confirm_")) {
          if (!isOwner(interaction.user.id)) {
            await interaction.reply({
              content: "🚫 Only an owner can confirm an account-age kick.",
              flags: 64
            });
            return;
          }

          const scanId = interaction.customId.replace("accountagekick_confirm_", "");
          const scan = accountAgeGateManager.getScan(scanId);
          if (!scan) {
            await interaction.reply({
              content: "❌ This scan has expired or was already used. Run `*accountagekick` again.",
              flags: 64
            });
            return;
          }


          accountAgeGateManager.deleteScan(scanId);

          await interaction.update({
            content: `⏳ Kicking ${scan.userIds.length} member(s)...`,
            embeds: [],
            components: []
          }).catch(() => {});

          let kicked = 0;
          let dmed = 0;
          let failed = 0;
          for (const userId of scan.userIds) {
            const member = await interaction.guild.members.fetch(userId).catch(() => null);
            if (!member) continue;
            const dmOk = await accountAgeGateManager.dmIfAllowed(member.user);
            if (dmOk) dmed++;
            const kickOk = await member
              .kick("Account under 3 days old (bulk account-age kick)")
              .then(() => true)
              .catch(() => false);
            if (kickOk) kicked++;
            else failed++;


            await new Promise((resolve) => setTimeout(resolve, 1200));
          }

          await interaction
            .editReply({
              content: `✅ Done. Kicked **${kicked}**, DMed **${dmed}**, failed **${failed}** (of ${scan.userIds.length} scanned).`
            })
            .catch(() => {});

          return;
        }

        if (interaction.customId.startsWith("accountagekick_list_")) {
          if (!isOwner(interaction.user.id)) {
            await interaction.reply({
              content: "🚫 Only an owner can do this.",
              flags: 64
            });
            return;
          }

          const scanId = interaction.customId.replace("accountagekick_list_", "");
          const scan = accountAgeGateManager.getScan(scanId);
          if (!scan) {
            await interaction.reply({
              content: "❌ This scan has expired or was already used. Run `*accountagekick` again.",
              flags: 64
            });
            return;
          }

          await interaction.reply({
            content: scan.userIds.map((id) => `<@${id}>`).join(" "),
            allowedMentions: { users: scan.userIds }
          });

          return;
        }

        if (interaction.customId.startsWith("accountagekick_cancel_")) {
          if (!isOwner(interaction.user.id)) {
            await interaction.reply({
              content: "🚫 Only an owner can do this.",
              flags: 64
            });
            return;
          }

          const scanId = interaction.customId.replace("accountagekick_cancel_", "");
          accountAgeGateManager.deleteScan(scanId);

          await interaction
            .update({
              content: "❌ Cancelled — no members were kicked.",
              embeds: [],
              components: []
            })
            .catch(() => {});

          return;
        }



        if (
          interaction.customId === "statusrole_help"
        ) {
          await statusRoleManager.handleHelpButtonClick(
            interaction
          );

          return;
        }



        if (
          interaction.customId.startsWith(
            "giverole_sel_"
          )
        ) {
          if (
            !hasStaffAccess(
              interaction.member
            )
          ) {
            await interaction.reply({
              content:
                "🚫 Only staff can use this.",
              flags: 64
            });

            return;
          }

          const parts =
            interaction.customId.split("_");

          const targetId = parts[2];
          const roleId = parts[3];

          await interaction
            .deferUpdate()
            .catch(() => {});

          const targetMember =
            await interaction.guild.members
              .fetch(targetId)
              .catch(() => null);

          const role =
            await interaction.guild.roles
              .fetch(roleId)
              .catch(() => null);

          if (!targetMember || !role) {
            await interaction.message
              .delete()
              .catch(() => {});

            const msg =
              await interaction.channel.send(
                "❌ Member or role not found."
              );

            setTimeout(
              () =>
                msg.delete().catch(() => {}),
              5000
            );

            return;
          }



          if (!isOwner(interaction.user.id)) {
            const staffHighestRole =
              interaction.member.roles.highest;

            if (
              role.position >=
                staffHighestRole.position ||
              targetMember.roles.highest.position >=
                staffHighestRole.position
            ) {
              await interaction.message
                .delete()
                .catch(() => {});

              const msg =
                await interaction.channel.send(
                  `🚫 <@${interaction.user.id}>, you don't have permission to assign **${role.name}**.`
                );

              setTimeout(
                () =>
                  msg.delete().catch(() => {}),
                5000
              );

              return;
            }
          }

          if (
            targetMember.roles.cache.has(
              role.id
            )
          ) {
            await interaction.message
              .delete()
              .catch(() => {});

            const msg =
              await interaction.channel.send(
                `⚠️ <@${targetMember.id}> already has the **${role.name}** role.`
              );

            setTimeout(
              () =>
                msg.delete().catch(() => {}),
              5000
            );

            return;
          }

          try {
            await targetMember.roles.add(role);

            await interaction.message
              .delete()
              .catch(() => {});

            const successMsg =
              await interaction.channel.send(
                `✅ Gave **${role.name}** to <@${targetMember.id}>.`
              );

            setTimeout(
              () =>
                successMsg.delete().catch(() => {}),
              5000
            );
          } catch (err) {
            await interaction.message
              .delete()
              .catch(() => {});

            const errMsg =
              await interaction.channel.send(
                `❌ Failed to add **${role.name}**: ${err.message}`
              );

            setTimeout(
              () =>
                errMsg.delete().catch(() => {}),
              5000
            );
          }

          return;
        }



        if (
          interaction.customId.startsWith(
            "topstaff_page_"
          ) ||
          interaction.customId.startsWith(
            "topstaff_nav_"
          ) ||
          interaction.customId.startsWith(
            "topstaff_mode_"
          )
        ) {
          if (
            !hasStaffAccess(
              interaction.member
            )
          ) {
            await interaction.reply({
              content:
                "🚫 You don't have permission to use this.",
              flags: 64
            });

            return;
          }

          await interaction
            .deferUpdate()
            .catch(() => {});

          let page = "claimed";
          let index = 0;
          let mode = "all";

          if (
            interaction.customId.startsWith(
              "topstaff_page_"
            )
          ) {
            const [p, m] =
              interaction.customId
                .replace(
                  "topstaff_page_",
                  ""
                )
                .split("_");

            page = p || "claimed";
            mode = m || "all";
            index = 0;
          } else if (
            interaction.customId.startsWith(
              "topstaff_nav_"
            )
          ) {
            const [p, i, m] =
              interaction.customId
                .replace(
                  "topstaff_nav_",
                  ""
                )
                .split("_");

            page = p || "claimed";
            index =
              parseInt(i, 10) || 0;
            mode = m || "all";
          } else {
            const [m, p, i] =
              interaction.customId
                .replace(
                  "topstaff_mode_",
                  ""
                )
                .split("_");

            mode = m || "all";
            page = p || "claimed";
            index =
              parseInt(i, 10) || 0;
          }

          const payload =
            await leaderboardManager
              .buildLeaderboardPayload(
                interaction.guild,
                page,
                index,
                mode
              );

          await interaction
            .editReply(payload)
            .catch(() => {});

          return;
        }



        if (
          interaction.customId.startsWith(
            "training_begin_"
          )
        ) {
          const channelId =
            interaction.customId.replace(
              "training_begin_",
              ""
            );

          await trainingManager.handleBeginButton(
            interaction,
            channelId
          );

          return;
        }

        if (
          interaction.customId.startsWith(
            "training_practice_"
          )
        ) {
          const channelId =
            interaction.customId.replace(
              "training_practice_",
              ""
            );

          await trainingManager.beginWarnPractice(
            interaction,
            channelId
          );

          return;
        }

        if (
          interaction.customId.startsWith(
            "training_start_scenarios_"
          )
        ) {
          const channelId =
            interaction.customId.replace(
              "training_start_scenarios_",
              ""
            );

          if (
            typeof trainingManager
              .handleStartScenarios ===
            "function"
          ) {
            await trainingManager
              .handleStartScenarios(
                interaction,
                channelId
              );
          }

          return;
        }

        if (
          interaction.customId.startsWith(
            "training_restart_"
          )
        ) {
          const channelId =
            interaction.customId.replace(
              "training_restart_",
              ""
            );

          if (
            typeof trainingManager
              .handleRestartTraining ===
            "function"
          ) {
            await trainingManager
              .handleRestartTraining(
                interaction,
                channelId
              );
          }

          return;
        }

        if (
          interaction.customId.startsWith(
            "training_choice_"
          )
        ) {
          const rest =
            interaction.customId.replace(
              "training_choice_",
              ""
            );

          const [
            channelId,
            scenarioId,
            choice
          ] = rest.split("_");

          await trainingManager
            .handleScenarioChoice(
              interaction,
              channelId,
              scenarioId,
              choice
            );

          return;
        }



        if (
          interaction.customId.startsWith(
            "blockedwords_dm_"
          )
        ) {
          await blockedWords.handleDmButtonClick(
            interaction
          );

          return;
        }



        if (
          interaction.customId.startsWith(
            "suggest_open_"
          )
        ) {
          const category =
            interaction.customId.replace(
              "suggest_open_",
              ""
            );

          await suggestionsManager.openModal(
            interaction,
            category
          );

          return;
        }



        if (
          interaction.customId.startsWith(
            "staffstats_"
          )
        ) {
          if (
            !hasStaffAccess(
              interaction.member
            )
          ) {
            await interaction.reply({
              content:
                "🚫 You don't have permission to use this.",
              flags: 64
            });

            return;
          }

          const [
            ,
            userId,
            daysStr
          ] =
            interaction.customId.split("_");

          const days =
            parseInt(daysStr, 10);

          await interaction.update({
            embeds: [
              await buildStaffStatsEmbed(
                interaction.guild,
                userId,
                days
              )
            ],
            components: [
              buildStaffStatsRow(
                userId,
                days
              )
            ]
          });

          return;
        }



        if (
          interaction.customId.startsWith(
            "guessticket_close_"
          )
        ) {
          await interaction
            .deferReply({
              flags: 64
            })
            .catch(() => {});

          await guessGameManager
            .closeGuessTicket(
              interaction.channel
            );

          await interaction
            .editReply({
              content: "🔒 Closing..."
            })
            .catch(() => {});

          return;
        }



        if (
          interaction.customId.startsWith(
            "race_claim_"
          )
        ) {
          await raceManager.handleClaimClick(
            interaction
          );

          return;
        }



        if (
          interaction.customId.startsWith(
            "ticket_replace_confirm_"
          )
        ) {
          const type =
            interaction.customId.replace(
              "ticket_replace_confirm_",
              ""
            );

          if (
            typeof modalHandler
              .handleReplaceConfirm ===
            "function"
          ) {
            await modalHandler
              .handleReplaceConfirm(
                interaction,
                type
              );
          }

          return;
        }

        if (
          interaction.customId ===
          "ticket_replace_cancel"
        ) {
          if (
            typeof modalHandler
              .handleReplaceCancel ===
            "function"
          ) {
            await modalHandler
              .handleReplaceCancel(
                interaction
              );
          }

          return;
        }



        if (
          interaction.customId.startsWith(
            "ticket_open_"
          )
        ) {
          const type =
            interaction.customId.replace(
              "ticket_open_",
              ""
            );

          await modalHandler
            .handleTicketButtonClick(
              interaction,
              type
            );

          return;
        }

        if (
          interaction.customId.startsWith(
            "ticket_close_"
          )
        ) {
          await buttonHandler
            .handleCloseButtonClick(
              interaction
            );

          return;
        }

        if (
          interaction.customId.startsWith(
            "ticket_claim_"
          ) ||
          interaction.customId.startsWith(
            "ticket_timer_"
          )
        ) {
          await buttonHandler
            .handleTicketAction(
              interaction,
              client
            );

          return;
        }
      }



      if (interaction.isModalSubmit()) {
        if (
          interaction.customId.startsWith(
            "suggest_modal_"
          )
        ) {
          const category =
            interaction.customId.replace(
              "suggest_modal_",
              ""
            );

          await suggestionsManager.handleSubmit(
            interaction,
            category
          );

          return;
        }

        if (
          interaction.customId.startsWith(
            "ticket_close_modal_"
          )
        ) {
          await buttonHandler
            .handleCloseModalSubmit(
              interaction
            );

          return;
        }

        if (
          interaction.customId.startsWith(
            "ticket_modal_"
          )
        ) {
          await modalHandler
            .handleModalSubmit(
              interaction
            );

          return;
        }
      }
    } catch (err) {
      console.error(
        "Interaction error:",
        err
      );

      const payload = {
        content:
          `❌ ${
            err.message ||
            "Something went wrong handling that. Please try again."
          }`,
        flags: 64
      };

      if (
        interaction.deferred ||
        interaction.replied
      ) {
        await interaction
          .editReply(payload)
          .catch(() => {});
      } else {
        await interaction
          .reply(payload)
          .catch(() => {});
      }
    }
  }
};
