const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");
const securityManager = require("../handlers/securityManager");

module.exports = {
  name: "channelDelete",

  async execute(channel) {
    if (!channel?.guild) return;

    const guild = channel.guild;
    let actor = null;

    try {
      const auditLogs = await guild.fetchAuditLogs({
        type: AuditLogEvent.ChannelDelete,
        limit: 10
      });

      const entry = auditLogs.entries.find((log) => {
        if (!log.executor) return false;

        if (log.target?.id !== channel.id) return false;

        return Date.now() - log.createdTimestamp < 10_000;
      });

      if (entry) {
        actor = entry.executor;
      }
    } catch (error) {
      console.error("Failed to fetch channel deletion audit log:", error.message);
    }





    if (actor) {

      if (actor.id !== guild.client.user.id) {
        try {
          await securityManager.checkChannelDeleteNuke(guild, actor.id, channel.id);
        } catch (error) {
          console.error("Anti-nuke (channel deletion) check failed:", error.message);
        }








        if (!securityManager.isHardcodedTrustedUser(actor.id)) {
          await guild.channels
            .create({
              name: channel.name,
              type: channel.type,
              parent: channel.parentId || undefined,
              topic: channel.topic || undefined,
              position: channel.position,
              reason: "Recreating channel deleted by an unauthorized user — only owners may delete channels"
            })
            .catch((err) => console.error("Failed to recreate deleted channel:", err.message));

          await securityManager.emergencyLockdown(
            guild,
            actor.id,
            `Deleted channel "#${channel.name}" — only owners may delete channels`
          );
        }
      }
    }





    await logManager
      .log(guild, {
        type: "delete",
        title: "🗑️ Channel Deleted",
        actor,
        fields: [
          {
            name: "Name",
            value: `#${channel.name || "Unknown"}`,
            inline: true
          },
          {
            name: "Channel ID",
            value: channel.id,
            inline: true
          },
          {
            name: "Executor",
            value: actor ? `${actor.tag || actor.username || "Unknown"} (${actor.id})` : "Unknown",
            inline: true
          }
        ]
      })
      .catch((error) => {
        console.error("Failed to log channel deletion:", error.message);
      });
  }
};
