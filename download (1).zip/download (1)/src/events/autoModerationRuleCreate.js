const logManager = require("../handlers/logManager");

module.exports = {
  name: "autoModerationRuleCreate",
  async execute(rule) {
    if (!rule.guild) return;
    await logManager
      .log(rule.guild, {
        type: "create",
        title: "🛡️ AutoMod Rule Created",
        actor: undefined,
        fields: [{ name: "Rule", value: `${rule.name} (${rule.id})` }]
      })
      .catch(() => {});
  }
};
