const logManager = require("../handlers/logManager");

module.exports = {
  name: "messageUpdate",
  async execute(oldMessage, newMessage, client) {
    if (!newMessage.guild) return;
    if (newMessage.author?.bot) return;

    if (oldMessage.content === newMessage.content) return;

    await logManager
      .log(newMessage.guild, {
        type: "update",
        title: "✏️ Message Edited",
        actor: newMessage.author,
        fields: [
          { name: "Channel", value: `${newMessage.channel}`, inline: true },
          { name: "Jump to message", value: `[Click here](${newMessage.url})`, inline: true },
          {
            name: "Before",
            value: oldMessage.content ? oldMessage.content.slice(0, 1000) : "*(empty)*"
          },
          {
            name: "After",
            value: newMessage.content ? newMessage.content.slice(0, 1000) : "*(empty)*"
          }
        ]
      })
      .catch(() => {});
  }
};
