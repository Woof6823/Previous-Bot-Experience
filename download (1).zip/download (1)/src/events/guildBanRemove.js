const { AuditLogEvent } = require("discord.js");
const db = require("../database");
const logManager = require("../handlers/logManager");
const protectedBanManager = require("../handlers/protectedBanManager");

module.exports = {
  name: "guildBanRemove",
  async execute(ban) {
    let actor;
    let reason = null;
    try {
      const logs = await ban.guild.fetchAuditLogs({
        type: AuditLogEvent.MemberBanRemove,
        limit: 5
      });
      const entry = logs.entries.find(
        (e) => e.target?.id === ban.user.id && Date.now() - e.createdTimestamp < 10000
      );
      actor = entry?.executor;
      reason = entry?.reason || null;
    } catch {
      actor = undefined;
    }





    protectedBanManager.handleBanRemove(ban.guild, ban.user.id, actor?.id || null).catch((err) => {
      console.error("Permanent-ban re-enforcement failed:", err.message);
    });



    if (actor && actor.id !== ban.guild.client.user.id) {
      db.addModLog(ban.user.id, actor.id, "unban", reason || "Manually unbanned.");
    }

    await logManager
      .log(ban.guild, {
        type: "mod",
        title: "🔓 Member Unbanned",
        actor,
        target: `${ban.user.tag} (${ban.user.id})`,
        color: 0x57f287
      })
      .catch(() => {});
  }
};
