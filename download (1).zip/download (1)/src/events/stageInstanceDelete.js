const logManager = require("../handlers/logManager");

module.exports = {
  name: "stageInstanceDelete",
  async execute(stageInstance) {
    if (!stageInstance.guild) return;
    await logManager
      .log(stageInstance.guild, {
        type: "delete",
        title: "🎙️ Stage Ended",
        fields: [{ name: "Channel", value: `${stageInstance.channel || stageInstance.channelId}`, inline: true }]
      })
      .catch(() => {});
  }
};
