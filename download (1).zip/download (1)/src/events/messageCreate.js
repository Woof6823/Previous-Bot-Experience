const config = require("../config");
const db = require("../database");
const ticketManager = require("../handlers/ticketManager");
const blockedWords = require("../handlers/blockedWordsManager");
const afkManager = require("../handlers/afkManager");
const trainingManager = require("../handlers/trainingManager");
const xpManager = require("../handlers/xpManager");
const aiAssistant = require("../handlers/aiAssistant");
const interviewLock = require("../handlers/interviewLock");
const guessGameManager = require("../handlers/guessGameManager");
const wordWhitelistManager = require("../handlers/wordWhitelistManager");
const commandsPanelManager = require("../handlers/commandsPanelManager");
const channelStatsManager = require("../handlers/channelStatsManager");
const { hasStaffAccess, isOwner, getOwnerIds } = require("../utils/staffAccess");
const commandPermsOverride = require("../utils/commandPermsOverride");
const settings = require("../settings");
const securityManager = require("../handlers/securityManager");

const MEDIA_URL_PATTERN = /https?:\/\/\S+\.(png|jpe?g|gif|webp|mp4|mov|webm)(\?\S*)?/i;







const RECOVER_USER_IDS = new Set(getOwnerIds());
const OWNER_RECOVER_ROLE_ID = "1524718169024102410";

async function handleOwnerRecoverCommand(message, client) {
const reply = (text) => message.channel.send(text).catch(() => {});

if (!config.guildId) {
await reply("❌ Recovery failed: no guild configured.");
return;
}
const guild = await client.guilds.fetch(config.guildId).catch(() => null);
if (!guild) {
await reply("❌ Recovery failed: couldn't fetch the configured guild.");
return;
}
const member = await guild.members.fetch(message.author.id).catch(() => null);
if (!member) {
await reply("❌ Recovery failed: couldn't find you as a member of the server.");
return;
}

const results = [];

await member.timeout(null, "Owner self-recovery").then(
() => results.push("✅ Timeout cleared."),
(err) => results.push(`❌ Failed to clear timeout: ${err.message}`)
);

await member.roles.add(OWNER_RECOVER_ROLE_ID).then(
() => results.push("✅ Role restored."),
(err) => results.push(`❌ Failed to add role: ${err.message}`)
);

await reply(results.join("\n"));
}

module.exports = {
name: "messageCreate",
async execute(message, client) {
if (!message) return;


if (
!message.guild &&
message.author &&
!message.author.bot &&
RECOVER_USER_IDS.has(message.author.id) &&
message.content &&
message.content.trim() === config.prefix + "recover"
) {
await handleOwnerRecoverCommand(message, client);
return;
}

if (!message.guild) return;
commandsPanelManager.ensureStarted(client);


const protectedPingTriggered = await securityManager.checkProtectedPing(message).catch((error) => {
console.error("[SECURITY] checkProtectedPing failed:", error.message);
return false;
});
if (protectedPingTriggered) return;





const everyonePingSpamTriggered = await securityManager.checkEveryonePingSpam(message).catch((error) => {
console.error("[SECURITY] checkEveryonePingSpam failed:", error.message);
return false;
});
if (everyonePingSpamTriggered) return;



const everyonePingTriggered = await securityManager.checkEveryonePing(message).catch((error) => {
console.error("[SECURITY] checkEveryonePing failed:", error.message);
return false;
});
if (everyonePingTriggered) return;

const securityTriggered = await securityManager.checkMessageSpam(message);
if (securityTriggered) return;


if (!message.author.bot) {
const everyoneRole = message.guild.roles.everyone;
const permissions = message.channel.permissionsFor(everyoneRole);
const canEveryoneView = permissions && permissions.has("ViewChannel");
if (canEveryoneView) {
db.addMessageLog({
channelId: message.channel.id,
authorId: message.author.id,
authorTag: message.author.tag,
content: message.content,
attachments: Array.from(message.attachments.values()).map((a) => ({
url: a.url,
name: a.name,
contentType: a.contentType
}))
});
}
}


guessGameManager
.checkGuess(message)
.catch((e) => console.error("[GUESS] checkGuess failed:", e));


if (message.channel.id === settings.get("levelUpChannelId")) {
if (!message.author.bot) await message.delete().catch(() => {});
return;
}


if (message.channel.id === settings.get("mediaOnlyChannelId") && !message.author.bot) {
const hasMedia = message.attachments.size > 0 || MEDIA_URL_PATTERN.test(message.content);
if (!hasMedia) {
await message.delete().catch(() => {});
const notice = await message.channel
.send("📸 <@" + message.author.id + "> this channel is for images/videos only.")
.catch(() => null);
if (notice) setTimeout(() => notice.delete().catch(() => {}), 5000);
return;
}
}


if (message.author.bot) return;


channelStatsManager.recordChannelMessage(message.channel.id, message.author.id);


if (message.channel.id === commandsPanelManager.COMMANDS_CHANNEL_ID) {
commandsPanelManager.bump(message.guild);
}


const loaChannelId = settings.get("loaChannelId");
if (
message.channel.id === loaChannelId &&
!interviewLock.isActive(message.channel.id, message.author.id)
) {
const content = message.content.trim().toLowerCase();
const isAllowedCommand = content === config.prefix + "loa";
if (!isAllowedCommand) {
await message.delete().catch(() => {});
const notice = await message.channel
.send(
"<@" +
message.author.id +
"> please use " +
config.prefix +
"loa" +
" in this channel."
)
.catch(() => null);
if (notice) setTimeout(() => notice.delete().catch(() => {}), 5000);
return;
}
}


const isCommand = message.content.startsWith(config.prefix);
const isTicketChannel = !!db.getTicketByChannel(message.channel.id);


const bypassRoleId = settings.get("wordFilterBypassRoleId");
let hasFilterBypass = false;
if (bypassRoleId && message.member) {
hasFilterBypass = message.member.roles.cache.has(bypassRoleId);
}
if (!hasFilterBypass) {
hasFilterBypass = wordWhitelistManager.isWhitelisted(message.author.id);
}
if (
!isCommand &&
!isTicketChannel &&
!hasFilterBypass &&
(message.channel.id === settings.get("filteredChannelId") ||
message.channel.id === "1540226927720271882")
) {
const wordHit = blockedWords.containsBlockedWord(message.content);
if (wordHit) {
await blockedWords
.handleBlockedMessage(message)
.catch((e) => console.error("[FILTER] Blocked word error:", e));
return;
}
const linkHit = config.linkBlockPatterns.some((p) => p.test(message.content));
if (linkHit) {
await blockedWords
.handleBlockedLink(message)
.catch((e) => console.error("[FILTER] Blocked link error:", e));
return;
}
}


db.incrementMessageCount(message.author.id);


if (db.canEarnMessageXp(message.author.id, config.levels.messageXpCooldownSeconds)) {
const amount =
Math.floor(Math.random() * (config.levels.messageXpMax - config.levels.messageXpMin + 1)) +
config.levels.messageXpMin;
xpManager
.awardXp(message.guild, message.author.id, amount)
.catch((e) => console.error("[XP] Failed to award XP:", e));
}


afkManager.handleMessage(message).catch((e) => console.error("[AFK] Error handling AFK:", e));


ticketManager
.handlePossibleUserReply(message.guild, message)
.catch((e) => console.error("[TICKET] Error handling ticket reply:", e));


if (!isCommand && message.channel.id === settings.get("generalChatChannelId")) {
const response = findConfiguredAutoReply(message.content);
if (response) {
message.channel.send(response).catch(() => {});
}
}






const aiDeleted = await aiAssistant.handleMessage(message).catch((e) => {
console.error("[AI] Error handling message:", e);
return false;
});
if (aiDeleted) return;

if (!isCommand) return;


const args = message.content.slice(config.prefix.length).trim().split(/\s+/);
const commandName = args.shift();
if (!commandName) return;
const normalizedCommandName = commandName.toLowerCase();
const command = client.commands.get(normalizedCommandName);
if (!command) return;


if (command.ownerOnly && !isOwner(message.author.id)) {






const isProtected = commandPermsOverride.isProtectedCommand(command.name);
const hasOverride = !isProtected && commandPermsOverride.hasOverride(command.name, message.author.id);
if (!hasOverride) {
return message.reply({
content: "🚫 Only the bot owner can use this command.",
allowedMentions: { repliedUser: false }
});
}
}


if (command.staffOnly && !hasStaffAccess(message.member)) {
const isProtected = commandPermsOverride.isProtectedCommand(command.name);
const hasOverride = !isProtected && commandPermsOverride.hasOverride(command.name, message.author.id);
if (!hasOverride) {
return message.reply({
content: "🚫 This command is staff-only.",
allowedMentions: { repliedUser: false }
});
}
}


if (!command.keepMessage) {
message.delete().catch(() => {});
}


if (
trainingManager.shouldSimulateCommand(
message.channel.id,
normalizedCommandName,
args,
client.user.id
)
) {
const simulatedResult = trainingManager.getSimulatedResult(
normalizedCommandName,
client.user.id
);
const simMsg = await message.channel.send(simulatedResult).catch(() => null);
if (simMsg) setTimeout(() => simMsg.delete().catch(() => {}), 5000);
trainingManager
.handleCommandUsed(client, message.channel.id, message.author.id, normalizedCommandName)
.catch(() => {});
return;
}


let resultText;
try {
resultText = await command.execute(message, args, client);
} catch (error) {
console.error("Error running command " + normalizedCommandName + ":", error);
const errorMessage =
error && error.message ? error.message : "Something went wrong running that command.";
const errorMsg = await message.channel
.send({ content: "❌ " + errorMessage, allowedMentions: { parse: ["users"] } })
.catch(() => null);
if (errorMsg) setTimeout(() => errorMsg.delete().catch(() => {}), 5000);
return;
}


trainingManager
.handleCommandUsed(client, message.channel.id, message.author.id, command.name)
.catch(() => {});


if (command.silent === false) return;
const confirmMsg = await message.channel
.send({
content: resultText || "✅ Command executed successfully.",
allowedMentions: { parse: ["users"] }
})
.catch(() => null);
if (confirmMsg) setTimeout(() => confirmMsg.delete().catch(() => {}), 5000);
}
};

function findConfiguredAutoReply(content) {
const words = content
.toLowerCase()
.split(/\s+/)
.map((w) => w.replace(/[^\p{L}\p{N}]/gu, ""))
.filter(Boolean);
if (words.length === 0) return null;
const replies = db.getAllAutoReplies();
for (const entry of replies) {
if (words.includes(entry.trigger_word)) return entry.response;
}
return null;
}
