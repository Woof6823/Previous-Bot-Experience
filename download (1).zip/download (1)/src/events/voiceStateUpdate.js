const db = require("../database");
const config = require("../config");
const tempVoiceManager = require("../handlers/tempVoiceManager");
const xpManager = require("../handlers/xpManager");
const logManager = require("../handlers/logManager");
const ltlManager = require("../handlers/ltlManager");

function logVoiceActivity(guild, oldState, newState) {
  const member = newState.member || oldState.member;
  if (!member || member.user.bot) return;

  if (!oldState.channelId && newState.channelId) {
    logManager
      .log(guild, {
        type: "voice",
        title: "🔊 Joined Voice",
        actor: member.user,
        actorLabel: "👤 Member",
        fields: [{ name: "Channel", value: `${newState.channel}`, inline: true }]
      })
      .catch(() => {});
  } else if (oldState.channelId && !newState.channelId) {
    logManager
      .log(guild, {
        type: "voice",
        title: "🔇 Left Voice",
        actor: member.user,
        actorLabel: "👤 Member",
        fields: [{ name: "Channel", value: `${oldState.channel}`, inline: true }]
      })
      .catch(() => {});
  } else if (
    oldState.channelId &&
    newState.channelId &&
    oldState.channelId !== newState.channelId
  ) {
    logManager
      .log(guild, {
        type: "voice",
        title: "🔀 Switched Voice Channel",
        actor: member.user,
        actorLabel: "👤 Member",
        fields: [
          { name: "From", value: `${oldState.channel}`, inline: true },
          { name: "To", value: `${newState.channel}`, inline: true }
        ]
      })
      .catch(() => {});
  }




  if (oldState.serverMute !== newState.serverMute) {
    logManager
      .log(guild, {
        type: "voice",
        title: newState.serverMute ? "🔇 Server-Muted" : "🔊 Server-Unmuted",
        actor: member.user,
        actorLabel: "👤 Member",
        fields: newState.channel ? [{ name: "Channel", value: `${newState.channel}`, inline: true }] : []
      })
      .catch(() => {});
  }

  if (oldState.serverDeaf !== newState.serverDeaf) {
    logManager
      .log(guild, {
        type: "voice",
        title: newState.serverDeaf ? "🔇 Server-Deafened" : "🔊 Server-Undeafened",
        actor: member.user,
        actorLabel: "👤 Member",
        fields: newState.channel ? [{ name: "Channel", value: `${newState.channel}`, inline: true }] : []
      })
      .catch(() => {});
  }

  if (oldState.streaming !== newState.streaming) {
    logManager
      .log(guild, {
        type: "voice",
        title: newState.streaming ? "🎥 Started Streaming" : "🎥 Stopped Streaming",
        actor: member.user,
        actorLabel: "👤 Member",
        fields: newState.channel ? [{ name: "Channel", value: `${newState.channel}`, inline: true }] : []
      })
      .catch(() => {});
  }

  if (oldState.selfVideo !== newState.selfVideo) {
    logManager
      .log(guild, {
        type: "voice",
        title: newState.selfVideo ? "📷 Camera Enabled" : "📷 Camera Disabled",
        actor: member.user,
        actorLabel: "👤 Member",
        fields: newState.channel ? [{ name: "Channel", value: `${newState.channel}`, inline: true }] : []
      })
      .catch(() => {});
  }

  if (oldState.suppress !== newState.suppress) {
    logManager
      .log(guild, {
        type: "voice",
        title: newState.suppress ? "🔈 Suppressed (moved to audience)" : "🔈 Unsuppressed (moved to speaker)",
        actor: member.user,
        actorLabel: "👤 Member",
        fields: newState.channel ? [{ name: "Channel", value: `${newState.channel}`, inline: true }] : []
      })
      .catch(() => {});
  }
}




function trackVoicePresence(guild, oldState, newState) {
  const userId = newState.id;
  const wasInVoice = !!oldState.channelId;
  const isInVoice = !!newState.channelId;

  if (!wasInVoice && isInVoice) {
    db.startVCSession(userId, newState.channelId);
  } else if (wasInVoice && !isInVoice) {
    const session = db.endVCSession(userId);
    if (session) {
      const seconds = Math.floor((Date.now() - session.joined_at) / 1000);
      db.addVoiceSeconds(userId, seconds);

      const minutes = Math.floor(seconds / 60);
      if (minutes > 0) {
        xpManager.awardXp(guild, userId, minutes * config.levels.voiceXpPerMinute).catch(() => {});
      }
    }
  }


}


















async function handleLtlVoiceState(oldState, newState) {
  const guild = newState.guild || oldState.guild;
  if (!guild) return false;

  const member = newState.member || oldState.member;
  if (!member || member.user.bot) return false;

  const event = db.getActiveLtlEvent(guild.id);
  if (!event) return false;

  const ltlChannelId = event.channel_id;
  const joinedLtlChannel =
    newState.channelId === ltlChannelId && oldState.channelId !== ltlChannelId;
  const leftLtlChannel = oldState.channelId === ltlChannelId && newState.channelId !== ltlChannelId;

  if (!joinedLtlChannel && !leftLtlChannel) return false;



  if (joinedLtlChannel && event.status === "scheduled") {
    await member.voice.disconnect("LTL event has not started yet.").catch(() => {});
    return true;
  }

  if (joinedLtlChannel && event.status === "active") {
    db.addLtlParticipant(event.id, member.id, Date.now(), false);
    return true;
  }

  if (leftLtlChannel && event.status === "active") {
    const participant = db.getLtlParticipant(event.id, member.id);
    if (participant && participant.status === "active") {
      db.markLtlParticipantLeft(event.id, member.id, Date.now(), "left");
    }





    const locked = event.end_at && Date.now() >= event.end_at;
    if (locked) {
      const eligibleRemaining = db
        .getActiveLtlParticipants(event.id)
        .filter((p) => !p.excluded_from_winner);

      if (eligibleRemaining.length <= 1) {
        await ltlManager.endEvent(guild.client, guild.id).catch((err) => {
          console.error("LTL auto-end failed:", err.message);
        });
      }
    }

    return true;
  }

  return true;
}

module.exports = {
  name: "voiceStateUpdate",
  async execute(oldState, newState) {
    const guild = newState.guild || oldState.guild;
    if (!guild) return;



    await handleLtlVoiceState(oldState, newState).catch((err) => {
      console.error("LTL voice-state handling failed:", err.message);
    });

    trackVoicePresence(guild, oldState, newState);
    logVoiceActivity(guild, oldState, newState);


    const joinChannelId = db.getSetting("temp_vc_join_channel_id");
    if (newState.channelId && newState.channelId === joinChannelId) {
      const member = newState.member;

      const cooldownRemaining = tempVoiceManager.checkCooldown(member.id);
      if (cooldownRemaining > 0) {
        await member.voice.disconnect().catch(() => {});
        member.user
          .send(
            `⏱️ You're on a short cooldown for creating voice channels — try again in ${cooldownRemaining}s.`
          )
          .catch(() => {});
        return;
      }

      const categoryId = db.getSetting("temp_vc_category_id");
      const category = guild.channels.cache.get(categoryId);
      const joinChannel = guild.channels.cache.get(joinChannelId);
      if (!category || !joinChannel) return;

      await tempVoiceManager
        .createUserChannel(guild, category, joinChannel, member)
        .catch((err) => {
          console.error("Failed to create temp voice channel:", err.message);
        });
      return;
    }


    if (oldState.channelId && oldState.channelId !== newState.channelId) {
      const tempVC = db.getTempVC(oldState.channelId);
      if (!tempVC) return;



      if (oldState.member.id === tempVC.owner_id) {
        const channel = guild.channels.cache.get(oldState.channelId);
        if (channel) {
          await tempVoiceManager.deleteChannelAndKickAll(guild, channel).catch((err) => {
            console.error("Failed to clean up temp voice channel:", err.message);
          });
        } else {
          db.deleteTempVC(oldState.channelId);
        }
      }
    }
  }
};
