const securityManager = require("../handlers/securityManager");

module.exports = {
  name: "webhookUpdate",

  async execute(channel) {
    if (!channel?.guild) return;

    try {
      await securityManager.checkWebhookCreate(channel);
    } catch (error) {
      console.error("Anti-webhook check failed:", error.message);
    }
  }
};
