const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");
const securityManager = require("../handlers/securityManager");
const protectedAdminRoleManager = require("../handlers/protectedAdminRoleManager");

module.exports = {
  name: "roleDelete",

  async execute(role) {
    if (!role?.guild) return;

    const guild = role.guild;
    let actor = null;





    if (role.name === protectedAdminRoleManager.ROLE_NAME) {
      protectedAdminRoleManager.ensureRoleSetup(guild).catch((err) => {
        console.error("Failed to recreate protected admin role after deletion:", err.message);
      });
    }

    try {
      const auditLogs = await guild.fetchAuditLogs({
        type: AuditLogEvent.RoleDelete,
        limit: 10
      });

      const entry = auditLogs.entries.find((log) => {
        if (!log.executor) return false;

        if (log.target?.id !== role.id) return false;

        return Date.now() - log.createdTimestamp < 10_000;
      });

      if (entry) {
        actor = entry.executor;
      }
    } catch (error) {
      console.error("Failed to fetch role deletion audit log:", error.message);
    }





    if (actor && actor.id !== guild.client.user.id) {
      try {
        await securityManager.checkRoleDeleteNuke(guild, actor.id);
      } catch (error) {
        console.error("Anti-nuke (role deletion) check failed:", error.message);
      }









      if (!securityManager.isHardcodedTrustedUser(actor.id) && role.name !== protectedAdminRoleManager.ROLE_NAME) {
        await guild.roles
          .create({
            name: role.name,
            colors: { primaryColor: role.color },
            hoist: role.hoist,
            mentionable: role.mentionable,
            permissions: role.permissions,
            reason: "Recreating role deleted by an unauthorized user — only owners may delete roles"
          })
          .catch((err) => console.error("Failed to recreate deleted role:", err.message));

        await securityManager.emergencyLockdown(
          guild,
          actor.id,
          `Deleted role "${role.name}" — only owners may delete roles`
        );
      }
    }





    await logManager
      .log(guild, {
        type: "delete",
        title: "🗑️ Role Deleted",
        actor,
        fields: [
          {
            name: "Role",
            value: role.name || "Unknown",
            inline: true
          },
          {
            name: "Role ID",
            value: role.id,
            inline: true
          },
          {
            name: "Executor",
            value: actor ? `${actor.tag || actor.username || "Unknown"} (${actor.id})` : "Unknown",
            inline: true
          }
        ]
      })
      .catch((error) => {
        console.error("Failed to log role deletion:", error.message);
      });
  }
};
