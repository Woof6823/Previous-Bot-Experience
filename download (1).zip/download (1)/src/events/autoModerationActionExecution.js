const logManager = require("../handlers/logManager");

module.exports = {
  name: "autoModerationActionExecution",
  async execute(execution) {
    const guild = execution.guild;
    if (!guild) return;

    await logManager
      .log(guild, {
        type: "mod",
        title: "🛡️ AutoMod Blocked/Actioned a Message",
        target: `<@${execution.userId}> (${execution.userId})`,
        fields: [
          { name: "Rule", value: `${execution.ruleId}`, inline: true },
          { name: "Channel", value: execution.channelId ? `<#${execution.channelId}>` : "Unknown", inline: true },
          { name: "Action", value: `${execution.action?.type ?? "Unknown"}`, inline: true },
          ...(execution.matchedContent
            ? [{ name: "Matched Content", value: execution.matchedContent.slice(0, 500) }]
            : []),
          ...(execution.matchedKeyword
            ? [{ name: "Matched Keyword", value: execution.matchedKeyword }]
            : [])
        ]
      })
      .catch(() => {});
  }
};
