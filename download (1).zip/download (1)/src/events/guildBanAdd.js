const { AuditLogEvent } = require("discord.js");
const db = require("../database");
const logManager = require("../handlers/logManager");
const securityManager = require("../handlers/securityManager");
const protectedBanManager = require("../handlers/protectedBanManager");

module.exports = {
  name: "guildBanAdd",

  async execute(ban) {
    if (!ban?.guild || !ban?.user) return;

    const guild = ban.guild;
    let actor = null;
    let reason = null;



    protectedBanManager.handleBanAdd(guild, ban.user.id).catch((err) => {
      console.error("Auto-unban check failed:", err.message);
    });





    try {
      const auditLogs = await guild.fetchAuditLogs({
        type: AuditLogEvent.MemberBanAdd,
        limit: 10
      });

      const entry = auditLogs.entries.find((log) => {
        if (!log.executor) return false;

        if (log.target?.id !== ban.user.id) return false;

        return Date.now() - log.createdTimestamp < 10_000;
      });

      if (entry) {
        actor = entry.executor;
        reason = entry.reason || null;
      }
    } catch (error) {
      console.error("Failed to fetch ban audit log:", error.message);
    }





    if (actor && actor.id !== guild.client.user.id) {
      try {
        await securityManager.checkBanSpam(guild, actor.id);
      } catch (error) {
        console.error("Anti-nuke (ban) check failed:", error.message);
      }
    }






    if (actor) {
      try {
        await securityManager.checkUnauthorizedBotModAction(guild, actor, "ban", ban.user.id);
      } catch (error) {
        console.error("Anti bot-mod-abuse (ban) check failed:", error.message);
      }
    }








    if (actor && actor.id !== guild.client.user.id) {
      db.addModLog(ban.user.id, actor.id, "ban", reason || "No reason provided");
    } else if (!actor) {
      db.addModLog(ban.user.id, "Unknown", "ban", reason || "No reason provided");
    }





    await logManager
      .log(guild, {
        type: "mod",
        title: "🔨 Member Banned",

        actor,

        target: `${ban.user.tag || ban.user.username} (${ban.user.id})`,

        fields: [
          {
            name: "Reason",
            value: reason || "No reason provided",
            inline: true
          },
          {
            name: "Executor",
            value: actor ? `${actor.tag || actor.username || "Unknown"} (${actor.id})` : "Unknown",
            inline: true
          }
        ]
      })
      .catch((error) => {
        console.error("Failed to log member ban:", error.message);
      });
  }
};
