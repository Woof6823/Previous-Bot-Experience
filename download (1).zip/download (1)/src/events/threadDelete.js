const logManager = require("../handlers/logManager");

module.exports = {
  name: "threadDelete",
  async execute(thread) {
    if (!thread.guild) return;
    await logManager
      .log(thread.guild, {
        type: "delete",
        title: "🗑️ Thread Deleted",
        fields: [{ name: "Thread", value: `${thread.name}`, inline: true }]
      })
      .catch(() => {});
  }
};
