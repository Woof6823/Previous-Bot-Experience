const { AuditLogEvent } = require("discord.js");
const logManager = require("../handlers/logManager");

module.exports = {
  name: "guildScheduledEventDelete",
  async execute(event) {
    if (!event.guild) return;
    let actor;
    try {
      const logs = await event.guild.fetchAuditLogs({
        type: AuditLogEvent.GuildScheduledEventDelete,
        limit: 5
      });
      const entry = logs.entries.find((e) => Date.now() - e.createdTimestamp < 10000);
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }

    await logManager
      .log(event.guild, {
        type: "delete",
        title: "📅 Scheduled Event Deleted / Cancelled",
        actor,
        fields: [{ name: "Event", value: `${event.name} (${event.id})` }]
      })
      .catch(() => {});
  }
};
