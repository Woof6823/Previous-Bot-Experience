const logManager = require("../handlers/logManager");
const inviteTracker = require("../handlers/inviteTracker");

module.exports = {
  name: "inviteCreate",
  async execute(invite) {
    if (!invite.guild) return;
    inviteTracker.setInvite(invite.code, invite.guild.id, invite.uses || 0);
    await logManager
      .log(invite.guild, {
        type: "create",
        title: "📨 Invite Created",
        actor: invite.inviter || undefined,
        fields: [
          { name: "Code", value: invite.code, inline: true },
          {
            name: "Channel",
            value: invite.channel ? `${invite.channel}` : "Unknown",
            inline: true
          },
          {
            name: "Max Uses",
            value: invite.maxUses ? `${invite.maxUses}` : "Unlimited",
            inline: true
          },
          {
            name: "Expires",
            value: invite.expiresTimestamp
              ? `<t:${Math.floor(invite.expiresTimestamp / 1000)}:R>`
              : "Never",
            inline: true
          },
          { name: "Temporary", value: invite.temporary ? "Yes" : "No", inline: true }
        ]
      })
      .catch(() => {});
  }
};
