const logManager = require("../handlers/logManager");

module.exports = {
  name: "threadUpdate",
  async execute(oldThread, newThread) {
    if (!newThread.guild) return;

    const changes = [];
    if (oldThread.name !== newThread.name) {
      changes.push(`Name: \`${oldThread.name}\` → \`${newThread.name}\``);
    }
    if (oldThread.archived !== newThread.archived) {
      changes.push(`Archived: \`${oldThread.archived}\` → \`${newThread.archived}\``);
    }
    if (oldThread.locked !== newThread.locked) {
      changes.push(`Locked: \`${oldThread.locked}\` → \`${newThread.locked}\``);
    }
    if (oldThread.rateLimitPerUser !== newThread.rateLimitPerUser) {
      changes.push(
        `Slowmode: \`${oldThread.rateLimitPerUser}s\` → \`${newThread.rateLimitPerUser}s\``
      );
    }

    if (changes.length === 0) return;

    await logManager
      .log(newThread.guild, {
        type: "update",
        title: "🧵 Thread Updated",
        fields: [
          { name: "Thread", value: `${newThread}`, inline: true },
          { name: "Changes", value: changes.join("\n").slice(0, 1024) }
        ]
      })
      .catch(() => {});
  }
};
