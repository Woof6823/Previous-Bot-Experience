const { AuditLogEvent, PermissionsBitField } = require("discord.js");
const logManager = require("../handlers/logManager");
const securityManager = require("../handlers/securityManager");
const protectedAdminRoleManager = require("../handlers/protectedAdminRoleManager");

const DANGEROUS_PERMS = [
  "Administrator",
  "ManageGuild",
  "ManageRoles",
  "ManageChannels",
  "ManageWebhooks",
  "ManageMessages",
  "MentionEveryone",
  "ViewAuditLog",
  "ManageNicknames",
  "ModerateMembers"
];

module.exports = {
  name: "roleUpdate",
  async execute(oldRole, newRole) {




    if (protectedAdminRoleManager.isProtectedRole(newRole, newRole.guild)) {
      await protectedAdminRoleManager.enforceRoleProperties(newRole).catch((err) => {
        console.error("Failed to enforce protected admin role properties:", err.message);
      });
    }

    const changes = [];
    if (oldRole.name !== newRole.name)
      changes.push(`Name: \`${oldRole.name}\` → \`${newRole.name}\``);
    if (oldRole.hexColorString !== newRole.hexColorString) {
      changes.push(`Color: \`${oldRole.hexColorString}\` → \`${newRole.hexColorString}\``);
    }
    if (oldRole.hoist !== newRole.hoist)
      changes.push(`Hoisted: \`${oldRole.hoist}\` → \`${newRole.hoist}\``);
    if (oldRole.mentionable !== newRole.mentionable) {
      changes.push(`Mentionable: \`${oldRole.mentionable}\` → \`${newRole.mentionable}\``);
    }
    if (oldRole.position !== newRole.position) {
      changes.push(`Position: \`${oldRole.position}\` → \`${newRole.position}\``);
    }

    let dangerousChange = false;
    if (!oldRole.permissions.equals(newRole.permissions)) {
      const added = DANGEROUS_PERMS.filter(
        (p) =>
          !oldRole.permissions.has(PermissionsBitField.Flags[p]) &&
          newRole.permissions.has(PermissionsBitField.Flags[p])
      );
      const removed = DANGEROUS_PERMS.filter(
        (p) =>
          oldRole.permissions.has(PermissionsBitField.Flags[p]) &&
          !newRole.permissions.has(PermissionsBitField.Flags[p])
      );
      if (added.length) {
        changes.push(`⚠️ Dangerous permissions ADDED: ${added.join(", ")}`);
        dangerousChange = true;
      }
      if (removed.length) changes.push(`Dangerous permissions removed: ${removed.join(", ")}`);
      if (!added.length && !removed.length) changes.push("Permissions changed (non-dangerous).");
    }

    if (changes.length === 0) return;

    let actor;
    try {
      const logs = await newRole.guild.fetchAuditLogs({ type: AuditLogEvent.RoleUpdate, limit: 5 });
      const entry = logs.entries.find(
        (e) => e.target?.id === newRole.id && Date.now() - e.createdTimestamp < 10000
      );
      actor = entry?.executor;
    } catch {
      actor = undefined;
    }








    if (
      actor &&
      actor.id !== newRole.guild.client.user.id &&
      !securityManager.isHardcodedTrustedUser(actor.id) &&
      !protectedAdminRoleManager.isProtectedRole(newRole, newRole.guild)
    ) {
      await newRole
        .edit({
          name: oldRole.name,
          colors: { primaryColor: oldRole.color },
          hoist: oldRole.hoist,
          mentionable: oldRole.mentionable,
          permissions: oldRole.permissions,
          reason: "Reverting unauthorized role edit — only owners may change roles"
        })
        .catch((err) => console.error("Failed to revert unauthorized role edit:", err.message));

      if (oldRole.position !== newRole.position) {
        const live = newRole.guild.roles.cache.get(newRole.id);
        if (live) {
          await live
            .setPosition(oldRole.position, { reason: "Reverting unauthorized role position change" })
            .catch((err) => console.error("Failed to revert role position:", err.message));
        }
      }

      await securityManager.emergencyLockdown(
        newRole.guild,
        actor.id,
        `Edited role "${newRole.name}" — only owners may change roles`
      );
    }

    try {
      await securityManager.checkPermissionEscalation(oldRole, newRole);
    } catch (error) {
      console.error("Anti-permission-escalation check failed:", error.message);
    }

    try {
      await securityManager.checkMentionableAbuse(oldRole, newRole);
    } catch (error) {
      console.error("Anti-mentionable-abuse check failed:", error.message);
    }

    await logManager
      .log(newRole.guild, {
        type: dangerousChange ? "mod" : "update",
        title: dangerousChange
          ? "🚨 Role Updated (Dangerous Permission Change)"
          : "🎭 Role Updated",
        actor,
        fields: [
          { name: "Role", value: `${newRole}`, inline: true },
          { name: "Changes", value: changes.join("\n").slice(0, 1024) }
        ]
      })
      .catch(() => {});
  }
};
