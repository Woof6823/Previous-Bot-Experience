const securityManager = require("../handlers/securityManager");

module.exports = {
  name: "securitywhitelistadd",
  description:
    "Disabled. Per policy, ABSOLUTELY NO ONE except the 5 hardcoded owners may ever bypass a security rule — this command used to grant that bypass, so it no longer does anything.",
  ownerOnly: false,
  staffOnly: false,
  silent: false,

  async execute(message) {
    if (!securityManager.isHardcodedTrustedUser(message.author.id)) {
      throw new Error("🚫 Only the hardcoded trusted users can use this command.");
    }

    return (
      "🚫 This command is disabled.\n\n" +
      "No user — no matter who adds them — is allowed to bypass any security rule except the 5 hardcoded owners. " +
      "Every anti-nuke check, the protected-ping mute, and the mass @everyone/@here strip all check " +
      "`isHardcodedTrustedUser()` only. There is no command, setting, or list that can extend that."
    );
  }
};
