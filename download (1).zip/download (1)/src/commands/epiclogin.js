const { EmbedBuilder } = require("discord.js");
const { hasStaffAccess } = require("../utils/staffAccess");

const EPIC_LOGIN_URL =
  "https://www.epicgames.com/id/login?lang=en-US&noHostRedirect=true&redirectUrl=https%3A%2F%2Fstore.epicgames.com%2F&client_id=875a3b57d3a640a6b7f9b4e883463ab4";

module.exports = {
  name: "epiclogin",
  description:
    "Sends the Epic Games login link with instructions to add SRG to your Epic username.",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message) {
    if (!hasStaffAccess(message.member)) {
      throw new Error("🚫 You don't have permission to use this.");
    }

    const embed = new EmbedBuilder()
      .setColor(0x2e2e2e)
      .setTitle("🔗 Add SRG to Your Epic Games Username")
      .setDescription(
        `**Step 1 — Log in**\n` +
          `Click the link below to open the Epic Games login page. You can log in with your email, ` +
          `PlayStation account, Xbox account, or any other linked login method.\n\n` +
          `**[Click here to log in to Epic Games](${EPIC_LOGIN_URL})**\n\n` +
          `**Step 2 — Change your username**\n` +
          `Once logged in, go to your **Account Settings** and change your Epic Games display name to ` +
          `include **SRG** — free of charge.`
      )
      .setFooter({ text: "Surge Esports" });

    await message.channel.send({ embeds: [embed] }).catch(() => {});
  }
};
