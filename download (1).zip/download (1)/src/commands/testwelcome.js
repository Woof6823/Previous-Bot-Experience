const welcomeManager = require("../handlers/welcomeManager");

module.exports = {
  name: "testwelcome",
  description: "Sends a full test of the join flow for you: welcome embed and welcome DM.",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    await welcomeManager.sendWelcomeMessage(message.member);
    await welcomeManager.sendWelcomeDM(message.member);
    return "✅ Test welcome embed and welcome DM sent.";
  }
};
