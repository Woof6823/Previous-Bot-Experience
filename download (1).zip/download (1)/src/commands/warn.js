const { EmbedBuilder } = require("discord.js");
const db = require("../database");
const { resolveTargetId, announceModAction } = require("../utils/moderation");
const { hasModPermission, canModerateTarget } = require("../utils/modPermissions");
const { isOwner } = require("../utils/staffAccess");
const logManager = require("../handlers/logManager");
const APPEALS_LINK = "https://discord.gg/xWb9d4yB4J";

module.exports = {
  name: "warn",
  description: "Warns a user. Usage: *warn <userid or @user> <reason>",
  ownerOnly: false,
  silent: false,
  async execute(message, args) {
    const targetId = resolveTargetId(args[0]);
    const reason = args.slice(1).join(" ") || "No reason provided";

    if (!targetId) throw new Error("Usage: `*warn <userid or @user> <reason>`");
    if (isOwner(targetId)) throw new Error("🚫 This user can never be warned.");

    const targetMember = await message.guild.members.fetch(targetId).catch(() => null);
    if (targetMember && targetMember.id === message.author.id)
      throw new Error("You cannot warn yourself.");
    if (targetMember && targetMember.id === message.client.user.id)
      throw new Error("I cannot warn myself.");

    if (targetMember) {
      const check = canModerateTarget(message.member, targetMember, "warn");
      if (!check.allowed) {
        if (check.reason === "owner_target") {
          throw new Error("🚫 This user can never be warned.");
        }
        if (check.reason === "hierarchy") {
          throw new Error("🚫 You can't warn someone with a role equal to or higher than yours.");
        }
        throw new Error("🚫 You don't have permission to warn people. You need the staff access role.");
      }
    } else if (!hasModPermission(message.member, "warn")) {
      throw new Error("🚫 You don't have permission to warn people. You need the staff access role.");
    }



    db.addWarning(targetId, message.author.id, reason);
    db.addModLog(targetId, message.author.id, "warn", reason);

    const dmEmbed = new EmbedBuilder()
      .setColor(0xf5c400)
      .setTitle(`⚠️ Warned in ${message.guild.name}`)
      .setDescription(
        `You have received a warning in **${message.guild.name}**.\n**Reason:** ${reason}\nIf you believe this is a mistake or your account was compromised, you can appeal in our appeals server:\n${APPEALS_LINK}`
      )
      .setTimestamp();

    const user = targetMember
      ? targetMember.user
      : await message.client.users.fetch(targetId).catch(() => null);
    if (user) await user.send({ embeds: [dmEmbed] }).catch(() => {});

    logManager
      .log(message.guild, {
        type: "moderation",
        title: "⚠️ Member Warned",
        target: `<@${targetId}> (${targetId})`,
        actor: message.author,
        fields: [{ name: "Reason", value: reason }]
      })
      .catch(() => {});

    await announceModAction(message.channel, targetId, "warned");
    return `⚠️ <@${targetId}> has been warned.`;
  }
};
