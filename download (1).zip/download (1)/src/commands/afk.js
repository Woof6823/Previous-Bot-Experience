const afkManager = require("../handlers/afkManager");

module.exports = {
  name: "afk",
  description: "Sets you as AFK with an optional reason. Usage: *afk [reason]",
  ownerOnly: false,
  silent: true,
  async execute(message, args) {

    if (afkManager.getAfkRow(message.author.id)) {
      const notice = await message.reply("⚠️ You are already AFK.").catch(() => null);
      if (notice) setTimeout(() => notice.delete().catch(() => {}), 5000);
      return;
    }

    const reason = args.join(" ").trim().slice(0, 300) || "AFK";

    if (afkManager.containsDisallowedPing(reason)) {
      const notice = await message
        .reply({
          content: "🚫 AFK reasons can't include @everyone, @here, or a user ping — this AFK is not allowed.",
          allowedMentions: { parse: [] }
        })
        .catch(() => null);
      if (notice) setTimeout(() => notice.delete().catch(() => {}), 5000);
      return;
    }

    await afkManager.setAfk(message.author.id, reason, message.member);


    const notice = await message.channel
      .send(`✅ <@${message.author.id}> is now AFK: **${reason}**`)
      .catch(() => null);

    if (notice) {
      setTimeout(() => notice.delete().catch(() => {}), 2000);
    }
  }
};
