const { EmbedBuilder } = require("discord.js");
const config = require("../config");

module.exports = {
    name: "embed",
    description: "Embeds your next message into a nicely styled embed.",
    ownerOnly: false,
    staffOnly: false,
    silent: false,
    async execute(message) {
        const prompt = await message.channel.send(
            `📝 ${message.author}, send the content you'd like to embed below. Type \`cancel\` to abort.`
        );

        const filter = (m) => m.author.id === message.author.id;
        const collected = await message.channel
            .awaitMessages({ filter, max: 1, time: 120000, errors: ["time"] })
            .catch(() => null);

        prompt.delete().catch(() => {});

        if (!collected) {
            const timeout = await message.channel.send("⏱️ You took too long to respond — embed cancelled.");
            setTimeout(() => timeout.delete().catch(() => {}), 5000);
            return;
        }

        const reply = collected.first();
        const content = reply.content.trim();
        await reply.delete().catch(() => {});

        if (!content || content.toLowerCase() === "cancel") {
            const cancelMsg = await message.channel.send("❌ Embed cancelled.");
            setTimeout(() => cancelMsg.delete().catch(() => {}), 5000);
            return;
        }

        const embed = new EmbedBuilder()
            .setColor(config.brandColor)
            .setAuthor({
                name: message.member?.displayName || message.author.username,
                iconURL: message.author.displayAvatarURL({ extension: "png", size: 128 })
            })
            .setDescription(content.slice(0, 4096))
            .setFooter({ text: message.guild.name })
            .setTimestamp();

        await message.channel.send({ embeds: [embed] });
    }
};
