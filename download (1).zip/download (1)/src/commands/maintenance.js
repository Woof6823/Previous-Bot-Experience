const config = require("../config");
const botStatusManager = require("../handlers/botStatusManager");

module.exports = {
  name: "maintenance",
  description:
    "Announces the bot/server is under maintenance and pings staff. Bot status channel only.",
  ownerOnly: true,
  silent: false,
  async execute(message, args, client) {
    if (
      message.channel.id !== config.botStatusChannelId &&
      message.channel.id !== config.testingChannelId
    ) {
      throw new Error("This command only works in the bot status channel.");
    }
    await botStatusManager.announce(client, "maintenance");
  }
};
