const db = require("../database");
const ticketManager = require("../handlers/ticketManager");

module.exports = {
  name: "undelay",
  description: "Clears a ticket's delayed status.",
  ownerOnly: false,
  staffOnly: true,
  silent: true,
  async execute(message) {
    const ticket = db.getTicketByChannel(message.channel.id);
    if (!ticket || ticket.status !== "open") {
      throw new Error("This command only works inside an open ticket channel.");
    }

    db.setTicketDelayed(message.channel.id, false, null);
    const updated = db.getTicketByChannel(message.channel.id);
    ticketManager.queueChannelRename(message.channel, message.channel.id);
    await ticketManager.refreshTicketMessage(message.guild, updated);

    return "✅ Delayed status cleared.";
  }
};
