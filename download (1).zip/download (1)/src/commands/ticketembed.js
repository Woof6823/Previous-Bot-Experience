const db = require("../database");
const ticketManager = require("../handlers/ticketManager");

module.exports = {
  name: "ticketembed",
  description: "Posts the Surge ticket panel in this channel and sets up ticket categories.",
  ownerOnly: true,
  silent: false,
  async execute(message, args, client) {
    await ticketManager.ensureCategories(message.guild);

    const panel = ticketManager.buildTicketPanelEmbed(client);
    const sent = await message.channel.send(panel);


    db.setSetting("ticket_panel_channel_id", message.channel.id);
    db.setSetting("ticket_panel_message_id", sent.id);
  }
};
