const tempVoiceManager = require("../handlers/tempVoiceManager");

module.exports = {
  name: "lock",
  description: "Locks your voice channel so nobody new can join. Run inside your VC's chat.",
  ownerOnly: false,
  silent: true,
  async execute(message) {
    tempVoiceManager.requireOwnedVC(message);
    await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, {
      Connect: false
    });
    return "🔒 Channel locked.";
  }
};
