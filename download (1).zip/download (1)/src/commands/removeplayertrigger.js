const db = require("../database");

module.exports = {
  name: "removeplayertrigger",
  description: "Removes a 'looking for players' trigger word. Usage: *removeplayertrigger <word>",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const word = args.join(" ").trim();
    if (!word) throw new Error("Usage: `*removeplayertrigger <word>`");
    const removed = db.removeTriggerWord("lfp", word);
    if (!removed) throw new Error(`**${word}** wasn't a trigger word.`);
    return `✅ Removed **${word}**.`;
  }
};
