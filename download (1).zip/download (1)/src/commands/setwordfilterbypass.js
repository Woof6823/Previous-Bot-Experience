const settings = require("../settings");

module.exports = {
  name: "setwordfilterbypass",
  description:
    "Sets the role that bypasses the blocked-word/link filter in the filtered channel entirely. Usage: *setwordfilterbypass @role",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    const role = message.mentions.roles.first();
    if (!role) {
      throw new Error("Usage: `*setwordfilterbypass @role`");
    }

    settings.set("wordFilterBypassRoleId", role.id);
    return `✅ ${role} can now post anything in the filtered channel — the blocked-word and blocked-link filter is skipped entirely for that role.`;
  }
};
