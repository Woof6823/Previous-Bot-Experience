const { hasStaffAccess } = require("../utils/staffAccess");
const { resolveTargetId } = require("../utils/moderation");
const { buildStaffStatsEmbed, buildStaffStatsRow } = require("../handlers/staffStatsManager");

module.exports = {
  name: "staffstats",
  description: "Shows a staff member's ticket/message/VC activity. Usage: *staffstats <userid>",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message, args) {
    if (!hasStaffAccess(message.member)) {
      throw new Error("🚫 You don't have permission to use this.");
    }

    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      throw new Error("Usage: `*staffstats <userid or @user>`");
    }

    await message.channel.send({
      embeds: [await buildStaffStatsEmbed(message.guild, targetId, 7)],
      components: [buildStaffStatsRow(targetId, 7)]
    });
  }
};
