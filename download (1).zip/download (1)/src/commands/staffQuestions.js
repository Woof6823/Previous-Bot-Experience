const { PermissionsBitField } = require("discord.js");
const db = require("../database");

const QUESTIONS = [
  {
    n: 1,
    text: "1) Two players are trash-talking each other in the public Discord server. It's starting to get heated, and other members are joining in. What would you do step by step to stop the argument, and how would you make sure it doesn't happen again later?"
  },
  {
    n: 2,
    text: "2) A well-known player in your community starts breaking small rules, like spamming or talking over others in VC. You don't want to seem harsh, but you also can't ignore it. What's the best way to remind them of the rules while still keeping things friendly and professional?"
  },
  {
    n: 3,
    text: "3) Imagine another moderator made a decision you personally don't agree with. What would you do, would you correct them in public, talk to them privately, or go to a higher staff member?"
  },
  {
    n: 4,
    text: "4) When you need to give a player a warning or timeout, how would you explain it in a way that feels fair and respectful instead of aggressive or rude?"
  },
  {
    n: 5,
    text: "5) Being a moderator means teamwork. How would you help your fellow staff members during a busy tournament when things get chaotic or confusing?"
  },
  {
    n: 6,
    text: "6) If someone breaks the rules in the server chat, how do you decide whether to just delete their message, warn them, or mute/ban them? What do you think about giving second chances?"
  },
  {
    n: 7,
    text: "7) If a new member joins the Discord and starts asking how to join the team or what the rules are, how would you greet them and explain everything in a clear and friendly way?"
  },
  {
    n: 8,
    text: "8) How do you think moderators can help make an esports community feel more welcoming and fun for everyone even for new players who might not be as skilled yet?"
  }
];

function buildStaffQuestionCommand({ n, text }) {
  return {
    name: `staffq${n}`,
    description: `Sends staff-application interview question ${n}. Admin perms only, staff tickets only.`,
    ownerOnly: false,



    silent: false,
    async execute(message) {
      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        throw new Error("🚫 You need Administrator permissions to use this.");
      }
      const ticket = db.getTicketByChannel(message.channel.id);
      if (!ticket || ticket.status !== "open" || ticket.type !== "staff") {
        throw new Error("This command only works inside an open Staff Application ticket.");
      }
      await message.channel.send(text).catch(() => {});
    }
  };
}

module.exports = QUESTIONS.map(buildStaffQuestionCommand);
