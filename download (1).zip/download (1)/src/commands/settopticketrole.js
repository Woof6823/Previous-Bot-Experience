const db = require("../database");

module.exports = {
  name: "settopticketrole",
  description:
    "Sets the role automatically given to whoever has claimed the most tickets in the last 24h. Usage: *settopticketrole @role",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    const role = message.mentions.roles.first();
    if (!role) {
      throw new Error("Usage: `*settopticketrole @role`");
    }
    db.setSetting("top_ticket_role_id", role.id);
    return `✅ ${role} will now be automatically given to the top ticket claimer of the last 24 hours.`;
  }
};
