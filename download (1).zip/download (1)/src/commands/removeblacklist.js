const db = require("../database");
const config = require("../config");
const { resolveTargetId } = require("../utils/moderation");
const blacklistManager = require("../handlers/blacklistManager");
const settings = require("../settings");

module.exports = {
  name: "removeblacklist",
  description: "Removes a full blacklist. Usage: *removeblacklist <userid>",
  ownerOnly: true,
  silent: false,
  async execute(message, args) {
    if (
      message.channel.id !== settings.get("blacklistChannelId") &&
      message.channel.id !== config.testingChannelId
    ) {
      throw new Error(`This command only works in <#${settings.get("blacklistChannelId")}>.`);
    }

    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      throw new Error("Usage: `*removeblacklist <userid>`");
    }

    if (!db.getBlacklist(targetId, "full")) {
      throw new Error("That user isn't on the full blacklist.");
    }



    await blacklistManager.markRemoved(message.guild, targetId, "full", `<@${message.author.id}>`);
    db.removeBlacklist(targetId, "full");

    const targetMember = await message.guild.members.fetch(targetId).catch(() => null);
    if (targetMember && config.fullBlacklistRoleId) {
      await targetMember.roles.remove(config.fullBlacklistRoleId).catch(() => {});
    }

    await message.channel.send(`✅ <@${targetId}> has been removed from the full blacklist.`);
    await blacklistManager.refreshPanel(message.channel);
  }
};
