const { EmbedBuilder } = require("discord.js");
const config = require("../config");
const rosterCommands = require("./rosterApplications");

module.exports = {
  name: "commandsguide",
  description: "Posts a reference embed listing every roster-ticket command.",
  ownerOnly: true,
  silent: false,
  async execute(message) {
    const names = rosterCommands.map((c) => `\`*${c.name}\``);
    const chunks = [];
    for (let i = 0; i < names.length; i += 12) chunks.push(names.slice(i, i + 12));

    for (const [index, chunk] of chunks.entries()) {
      const embed = new EmbedBuilder()
        .setColor(config.brandColor)
        .setTitle(index === 0 ? "📖 Roster Ticket Commands" : "📖 Roster Ticket Commands (cont.)")
        .setDescription(
          "These only work inside Roster ticket channels, and only for the ticket support role. Each one posts the requirements message for that role directly in the ticket."
        )
        .addFields(chunk.map((n) => ({ name: n, value: "\u200b", inline: true })));

      await message.channel.send({ embeds: [embed] });
    }
  }
};
