const config = require("../config");
const userStats = require("../handlers/userStatsManager");
module.exports = {
  name: "stats",
  description: "Shows a member's activity stats card. Usage: *stats [userid or @user]",
  ownerOnly: false,
  silent: false,
  keepMessage: true,
  async execute(message, args) {
    if (
      message.channel.id !== userStats.STATS_CHANNEL_ID &&
      message.channel.id !== config.testingChannelId
    ) {
      throw new Error(`Please use this in <#${userStats.STATS_CHANNEL_ID}>.`);
    }
    const targetId = args[0] ? args[0].replace(/[<@!>]/g, "") : message.author.id;
    const payload = await userStats.buildStatsPayload(
      message.guild,
      targetId,
      14,
      "full",
      message.author.id,
      Date.now()
    );
    await message.channel.send(payload);
  }
};
