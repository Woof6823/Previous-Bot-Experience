const { resolveTargetId } = require("../utils/moderation");
const tempVoiceManager = require("../handlers/tempVoiceManager");

module.exports = {
  name: "permit",
  description:
    "Lets a specific person join your (possibly locked) voice channel. Usage: *permit @user",
  ownerOnly: false,
  silent: true,
  async execute(message, args) {
    tempVoiceManager.requireOwnedVC(message);

    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      throw new Error("Usage: `*permit <userid or @user>`");
    }

    const targetMember = await message.guild.members.fetch(targetId).catch(() => null);
    if (!targetMember) {
      throw new Error("Couldn't find that member in this server.");
    }

    await message.channel.permissionOverwrites.edit(targetMember, {
      ViewChannel: true,
      Connect: true
    });

    return `✅ <@${targetId}> can now join this channel.`;
  }
};
