const db = require("../database");

module.exports = {
  name: "setuplogs",
  description:
    "Sets this channel as the server log channel (logs joins/leaves, message edits/deletes, moderation actions, channel/role changes, voice activity, and more).",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    db.setSetting("log_channel_id", message.channel.id);
    return "✅ This channel is now the log channel.";
  }
};
