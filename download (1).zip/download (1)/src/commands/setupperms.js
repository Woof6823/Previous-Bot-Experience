const { EmbedBuilder } = require("discord.js");
const config = require("../config");
const { getOwnerIds } = require("../utils/staffAccess");
const settings = require("../settings");


















function buildPermsInfoEmbed() {
  const staffAccessRoleId = settings.get("staffAccessRoleId");
  const owners = getOwnerIds();

  return new EmbedBuilder()
    .setColor(config.brandColor)
    .setTitle("⚙️ Moderation Permissions")
    .setDescription(
      "Moderation permissions now come directly from Discord's own role permissions instead of a role list picked here.\n\n" +
      "**Warn** — any staff member.\n" +
      "**Mute** — staff member **and** the `Timeout Members` permission ticked on one of their roles.\n" +
      "**Kick** — the `Kick Members` permission ticked on one of their roles.\n" +
      "**Ban** — the `Ban Members` permission ticked on one of their roles.\n\n" +
      "To change who can kick/ban/mute, go to **Server Settings → Roles** and tick/untick the matching permission on the role. " +
      "To make someone staff (able to warn, and to mute if they also have Timeout Members), give them the Staff Access role below.\n\n" +
      "Use `*addcommandperms <command> @user` to grant one person a one-off exception to a specific command instead."
    )
    .addFields(
      {
        name: "Staff Access role",
        value: staffAccessRoleId ? `<@&${staffAccessRoleId}>` : "*Not configured — set it with the setup wizard.*"
      },
      {
        name: `Owners (${owners.length}) — full access to every command, not editable here`,
        value: owners.map((id) => `<@${id}>`).join(", ") || "None."
      }
    )
    .setFooter({ text: "Owners can only be changed with a code deploy — no command can add or remove one." });
}




function buildPermsPanel() {
  return { embeds: [buildPermsInfoEmbed()] };
}

module.exports = {
  name: "setupperms",
  description: "Shows how moderation permissions currently work (they're driven by Discord role permissions, not this bot).",
  ownerOnly: true,
  silent: false,
  async execute(message) {
    await message.channel.send(buildPermsPanel());
  },
  buildPermsInfoEmbed,
  buildPermsPanel
};
