const settings = require("../settings");

module.exports = {
	name: "checkstaff_staffhub",
	description:
		"Checks the mentioned users and lists anyone who does NOT have the configured Staff Access role. Usage: *checkstaff_staffhub @user, @user, @user",
	ownerOnly: true,
	silent: false,
	async execute(message, args) {
		const staffAccessRoleId = settings.get("staffAccessRoleId");
		if (!staffAccessRoleId) {
			throw new Error(
				"The Staff Access role is not configured. Run the setup wizard first."
			);
		}


		const userIds = new Set();
		for (const id of message.mentions.users.keys()) userIds.add(id);
		for (const arg of args) {
			const cleaned = arg.replace(/[<@!>,]/g, "").trim();
			if (/^\d{15,25}$/.test(cleaned)) userIds.add(cleaned);
		}

		if (userIds.size === 0) {
			throw new Error(
				"Mention at least one user. Usage: `*checkstaff_staffhub @user, @user, @user`"
			);
		}

		const missing = [];
		const notInServer = [];
		for (const userId of userIds) {
			const member = await message.guild.members.fetch(userId).catch(() => null);
			if (!member) {
				notInServer.push(userId);
				continue;
			}
			if (!member.roles.cache.has(staffAccessRoleId)) {
				missing.push(userId);
			}
		}

		if (missing.length === 0 && notInServer.length === 0) {
			await message.channel.send({
				content: `✅ All ${userIds.size} mentioned user(s) already have the Staff Access role.`,
				allowedMentions: { parse: [] }
			});
			return;
		}

		const parts = [];
		if (missing.length > 0) {
			parts.push(
				`❌ **Missing the Staff Access role (${missing.length}):**\n` +
					missing.map((id) => `<@${id}>`).join(", ")
			);
		}
		if (notInServer.length > 0) {
			parts.push(
				`⚠️ **Not in this server (${notInServer.length}):**\n` +
					notInServer.map((id) => `<@${id}>`).join(", ")
			);
		}

		await message.channel.send({
			content: parts.join("\n\n"),
			allowedMentions: { users: [...missing, ...notInServer] }
		});
	}
};
