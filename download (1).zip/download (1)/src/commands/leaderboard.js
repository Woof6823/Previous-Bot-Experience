const { EmbedBuilder, AttachmentBuilder } = require("discord.js");
const config = require("../config");
const db = require("../database");
const settings = require("../settings");
const xpManager = require("../handlers/xpManager");
const levelCardRenderer = require("../handlers/levelCardRenderer");
const { resolveDisplayName } = require("../handlers/staffStatsManager");

module.exports = {
  name: "leaderboard",
  description: "Shows the top 10 members by level/XP.",
  ownerOnly: false,
  silent: false,
  keepMessage: true,
  async execute(message) {
    if (
      message.channel.id !== settings.get("levelLeaderboardChannelId") &&
      message.channel.id !== config.testingChannelId
    ) {
      throw new Error(`Please use this in <#${settings.get("levelLeaderboardChannelId")}>.`);
    }
    const rowsRaw = db.getXpLeaderboard(10);
    if (rowsRaw.length > 0) {
      const rows = [];
      for (let i = 0; i < rowsRaw.length; i++) {
        const r = rowsRaw[i];
        rows.push({
          rank: i + 1,
          username: await resolveDisplayName(message.guild, r.user_id),
          level: xpManager.levelFromXp(r.xp),
          xp: r.xp
        });
      }
      const card = await levelCardRenderer.renderLeaderboardCard(rows);
      if (card) {
        await message.channel.send({
          files: [new AttachmentBuilder(card, { name: "leaderboard.png" })]
        });
        return;
      }
    }

    const embed = new EmbedBuilder().setColor(config.brandColor).setTitle("🏆 XP Leaderboard");
    if (rowsRaw.length === 0) {
      embed.setDescription("No data yet.");
    } else {
      embed.setDescription(
        rowsRaw
          .map(
            (r, i) =>
              `**${i + 1}.** <@${r.user_id}> — Level ${xpManager.levelFromXp(r.xp)} (${r.xp} xp)`
          )
          .join("\n")
      );
    }
    await message.channel.send({ embeds: [embed] });
  }
};
