const helpManager = require("../handlers/helpManager");

module.exports = {
  name: "help",
  description: "Shows an interactive guide of all owner-only commands.",
  ownerOnly: true,
  silent: false,
  async execute(message) {
    await message.channel.send({
      embeds: [helpManager.buildOverviewEmbed()],
      components: [helpManager.buildSelectRow()]
    });
  }
};
