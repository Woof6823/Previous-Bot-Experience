const db = require("../database");
const config = require("../config");
const { resolveTargetId } = require("../utils/moderation");
const blacklistManager = require("../handlers/blacklistManager");
const settings = require("../settings");

module.exports = {
  name: "blacklist",
  description: "Blocks a user from opening ANY ticket. Usage: *blacklist <userid> <reason>",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message, args) {
    const blacklistChannelId = settings.get("blacklistChannelId");
    if (
      blacklistChannelId &&
      message.channel.id !== blacklistChannelId &&
      message.channel.id !== config.testingChannelId
    ) {
      throw new Error(`This command only works in <#${blacklistChannelId}>.`);
    }

    const targetId = resolveTargetId(args[0]);
    const reason = args.slice(1).join(" ") || "No reason provided";
    if (!targetId) throw new Error("Usage: `*blacklist <userid> <reason>`");

    db.addBlacklist(targetId, "full", reason, message.author.id);

    const targetMember = await message.guild.members.fetch(targetId).catch(() => null);
    if (targetMember && config.fullBlacklistRoleId) {
      await targetMember.roles.add(config.fullBlacklistRoleId).catch(() => {});
    }

    await blacklistManager.postConfirmationAndRefreshPanel(
      message.channel,
      {
        title: "Full Blacklist Approved",
        userId: targetId,
        requestedBy: message.author.id,
        reason,
        approvedBy: message.author.id
      },
      "full"
    );

    return `✅ <@${targetId}> has been fully blacklisted from all tickets.`;
  }
};
