const { resolveTargetId } = require("../utils/moderation");
const { isOwner } = require("../utils/staffAccess");
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");

async function giveRole(message, member, role) {









  if (!isOwner(message.author.id)) {
    const staffHighestRole = message.member.roles.highest;

    if (role.position >= staffHighestRole.position) {
      throw new Error(
        `🚫 You can only give roles that are below your highest role (<@&${staffHighestRole.id}>). ` +
        `The role <@&${role.id}> is at or above your position.`
      );
    }

    if (member.roles.highest.position >= staffHighestRole.position) {
      throw new Error(
        `🚫 You cannot give roles to someone whose highest role is at or above yours.`
      );
    }
  }

  if (member.roles.cache.has(role.id)) {
    throw new Error(
      `<@${member.id}> already has the **${role.name}** role.`
    );
  }

  try {
    await member.roles.add(role);
  } catch {
    throw new Error(
      "I couldn't add that role — check the bot's role is above it."
    );
  }

  return `✅ Gave **${role.name}** to <@${member.id}>.`;
}

module.exports = {
  name: "giverole",
  description: "Gives a role to a user. Usage: *giverole @user <role name>",
  ownerOnly: false,
  staffOnly: true,
  silent: true,

  async execute(message, args) {
    if (!args[0]) {
      throw new Error(
        "Usage: `*giverole @user <role name>`"
      );
    }

    const targetId = resolveTargetId(args[0]);

    if (!targetId) {
      throw new Error(
        "Usage: `*giverole @user <role name>`"
      );
    }

    const query = args.slice(1).join(" ").trim();

    if (!query) {
      throw new Error(
        "Usage: `*giverole @user <role name>`"
      );
    }

    const member = await message.guild.members
      .fetch(targetId)
      .catch(() => null);

    if (!member) {
      throw new Error(
        "Couldn't find that member in this server."
      );
    }

    const lowerQuery = query.toLowerCase();


    let matches = message.guild.roles.cache.filter(
      (r) =>
        r.name.toLowerCase() === lowerQuery &&
        r.id !== message.guild.id
    );


    if (matches.size === 0) {
      matches = message.guild.roles.cache.filter(
        (r) =>
          r.name.toLowerCase().includes(lowerQuery) &&
          r.id !== message.guild.id
      );
    }

    if (matches.size === 0) {
      throw new Error(
        `No roles found matching \`${query}\`.`
      );
    }

    const matchArray = [...matches.values()];


    if (matchArray.length === 1) {
      return await giveRole(
        message,
        member,
        matchArray[0]
      );
    }


    const cappedMatches = matchArray.slice(0, 25);

    const listText = cappedMatches
      .map((r, i) => `**${i + 1}.** ${r.name}`)
      .join("\n");

    const extraText =
      matchArray.length > 25
        ? `\n*...and ${matchArray.length - 25} more. Please be more specific.*`
        : "";

    const rows = [];
    let currentRow = new ActionRowBuilder();

    cappedMatches.forEach((r, i) => {
      currentRow.addComponents(
        new ButtonBuilder()
          .setCustomId(`giverole_sel_${targetId}_${r.id}`)
          .setLabel(`${i + 1}`)
          .setStyle(ButtonStyle.Primary)
      );

      if (currentRow.components.length === 5) {
        rows.push(currentRow);
        currentRow = new ActionRowBuilder();
      }
    });

    if (currentRow.components.length > 0) {
      rows.push(currentRow);
    }

    await message.channel.send({
      content:
        `Found **${matchArray.length}** roles matching \`${query}\`:\n` +
        `${listText}${extraText}\n` +
        `Click a button to select the role.`,
      components: rows
    });

    return null;
  }
};
