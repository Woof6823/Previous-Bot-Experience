const { PermissionsBitField } = require("discord.js");

function chunkLines(lines, maxLen = 1900) {
  const chunks = [];
  let current = "";
  for (const line of lines) {
    const candidate = current ? `${current}\n${line}` : line;
    if (candidate.length > maxLen) {
      if (current) chunks.push(current);
      current = line;
    } else {
      current = candidate;
    }
  }
  if (current) chunks.push(current);
  return chunks;
}

module.exports = {
  name: "adminlist",
  description: "Lists every role with Administrator permission, then every user with Administrator permission (pings both). Owner-only.",
  ownerOnly: true,
  staffOnly: false,
  silent: false,
  async execute(message) {
    await message.guild.roles.fetch();
    await message.guild.members.fetch();

    const adminRoles = message.guild.roles.cache.filter(
      (role) => role.id !== message.guild.id && role.permissions.has(PermissionsBitField.Flags.Administrator)
    );

    const roleLines = adminRoles.size
      ? [...adminRoles.values()]
          .sort((a, b) => b.position - a.position)
          .map((role) => `<@&${role.id}> — ${role.name} (${role.id})`)
      : ["None."];

    const adminMembers = message.guild.members.cache.filter((member) =>
      member.permissions.has(PermissionsBitField.Flags.Administrator)
    );

    const userLines = adminMembers.size
      ? [...adminMembers.values()]
          .sort((a, b) => a.user.tag.localeCompare(b.user.tag))
          .map((member) => `<@${member.id}> — ${member.user.tag} (${member.id})`)
      : ["None."];

    const roleBlock = ["Roles with Administrator permission:", ...roleLines];
    const userBlock = ["", "Users with Administrator permission:", ...userLines];
    const allLines = [...roleBlock, ...userBlock];





    const chunks = chunkLines(allLines);
    for (const chunk of chunks) {
      await message.channel.send({
        content: chunk,
        allowedMentions: { parse: ["roles", "users"] }
      });
    }

    return "";
  }
};
