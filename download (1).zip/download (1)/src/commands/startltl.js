const db = require("../database");
const ltlManager = require("../handlers/ltlManager");
const { parseLtlDuration } = require("../utils/ltlDuration");
module.exports = {
  name: "startltl",
  aliases: ["ltlstart"],
  description:
    "Schedules a Last-to-Leave event. Usage: *startltl #voice-channel <opens in> <locks in> — locks just closes joining, the event itself runs indefinitely until *ltlend.",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const channel = message.mentions.channels.first();
    const openDelayMs = parseLtlDuration(args[1]);
    const joinWindowMs = parseLtlDuration(args[2]);
    if (!channel || channel.type !== 2  || !openDelayMs || !joinWindowMs) {
      throw new Error(
        "Usage: `*startltl #voice-channel <opens in> <locks in>`\n" +
          "Both times accept hours/minutes/seconds, combined or alone — e.g. `1h30m`, `45s`, `10m`.\n" +
          "`<opens in>` is when the channel unlocks for joining. `<locks in>` is how long after THAT it stays " +
          "open for joining before locking — once locked, the event just keeps running with no set end time, " +
          "until you end it with `*ltlend`.\n" +
          "Example: `*startltl #ltl-vc 1m 5m`"
      );
    }
    const existing = db.getActiveLtlEvent(message.guild.id);
    if (existing) {
      throw new Error(
        "There's already a scheduled or active LTL event. Use `*ltlcancel` to stop it first."
      );
    }
    const startAt = Date.now() + openDelayMs;
    const lockAt = startAt + joinWindowMs;
    await ltlManager.scheduleEvent(message.guild, channel, message.channel, startAt, lockAt);
    return (
      `✅ LTL event scheduled — ${channel} opens <t:${Math.floor(startAt / 1000)}:R>, ` +
      `locks <t:${Math.floor(lockAt / 1000)}:R> after that, then runs with no set end time.`
    );
  }
};
