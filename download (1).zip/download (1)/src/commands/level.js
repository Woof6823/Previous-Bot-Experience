const { EmbedBuilder, AttachmentBuilder } = require("discord.js");
const config = require("../config");
const db = require("../database");
const settings = require("../settings");
const xpManager = require("../handlers/xpManager");
const levelCardRenderer = require("../handlers/levelCardRenderer");
const { resolveDisplayName } = require("../handlers/staffStatsManager");

module.exports = {
  name: "level",
  description: "Shows your (or another user's) level. Usage: *level [userid or @user]",
  ownerOnly: false,
  silent: false,
  keepMessage: true,
  async execute(message, args) {
    if (
      message.channel.id !== settings.get("levelLeaderboardChannelId") &&
      message.channel.id !== config.testingChannelId
    ) {
      throw new Error(`Please use this in <#${settings.get("levelLeaderboardChannelId")}>.`);
    }
    const targetId = args[0] ? args[0].replace(/[<@!>]/g, "") : message.author.id;
    const row = db.getLevelRow(targetId);
    const level = xpManager.levelFromXp(row.xp);
    const rank = db.getXpRank(targetId);
    const currentLevelFloor = xpManager.xpNeededForLevel(level);
    const nextLevelFloor = xpManager.xpNeededForLevel(level + 1);
    const progress = row.xp - currentLevelFloor;
    const needed = nextLevelFloor - currentLevelFloor;
    const displayName = await resolveDisplayName(message.guild, targetId);
    const user = await message.client.users.fetch(targetId).catch(() => null);
    const avatarUrl = user ? user.displayAvatarURL({ extension: "png", size: 128 }) : null;

    const card = await levelCardRenderer.renderLevelCard({
      username: displayName,
      avatarUrl,
      level,
      rank,
      xpIntoLevel: progress,
      xpForNext: needed
    });
    if (card) {
      await message.channel.send({ files: [new AttachmentBuilder(card, { name: "level.png" })] });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(config.brandColor)
      .setTitle(`📊 Level — ${displayName}`)
      .addFields(
        { name: "Level", value: `${level}`, inline: true },
        { name: "Rank", value: `#${rank}`, inline: true },
        { name: "XP", value: `${progress} / ${needed} to next level`, inline: true }
      );
    await message.channel.send({ embeds: [embed] });
  }
};
