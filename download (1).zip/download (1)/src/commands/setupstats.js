const statsManager = require("../handlers/statsManager");

module.exports = {
  name: "setupstats",
  description: "Creates the Members/Goal stat voice channels at the top of the server.",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    await statsManager.ensureStatsChannels(message.guild);
    await statsManager.updateStatsChannels(message.guild);
    return "✅ Stat channels are set up and updated.";
  }
};
