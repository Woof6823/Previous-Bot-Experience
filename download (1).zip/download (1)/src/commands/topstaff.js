const { hasStaffAccess } = require("../utils/staffAccess");
const leaderboardManager = require("../handlers/leaderboardManager");

module.exports = {
  name: "topstaff",
  description: "Shows the staff leaderboard (claimed tickets, messages, or VC hours) with pages.",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message) {
    if (!hasStaffAccess(message.member)) {
      throw new Error("🚫 You don't have permission to use this.");
    }
    const payload = await leaderboardManager.buildLeaderboardPayload(message.guild, "claimed", 0);
    await message.channel.send(payload);
  }
};
