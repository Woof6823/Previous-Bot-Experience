const { db } = require("../database");
const afkManager = require("../handlers/afkManager");

module.exports = {
  name: "resetafk",
  description: "Removes AFK status from everyone who currently has it. Owner only.",
  ownerOnly: true,
  silent: false,
  async execute(message, args, client) {
    const guild = message.guild;
    if (!guild) return;


    const afkUsers = db.prepare("SELECT user_id FROM afk_status").all();
    let removedCount = 0;

    for (const row of afkUsers) {
      const member = await guild.members.fetch(row.user_id).catch(() => null);

      if (member) {

        await afkManager.removeAfk(row.user_id, member, false);
        removedCount++;
      } else {

        db.prepare("DELETE FROM afk_status WHERE user_id = ?").run(row.user_id);
        removedCount++;
      }
    }

    return `✅ Successfully removed AFK status and restored nicknames for **${removedCount}** user(s).`;
  }
};
