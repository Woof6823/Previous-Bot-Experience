const raceManager = require("../handlers/raceManager");

module.exports = {
  name: "claimrace",
  description: "Starts a limited-time role giveaway. Usage: *claimrace @role <amount>",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const role = message.mentions.roles.first();
    const amount = parseInt(
      args.find((a) => /^\d+$/.test(a)),
      10
    );

    if (!role || !amount || amount < 1) {
      throw new Error("Usage: `*claimrace @role <amount>` — e.g. `*claimrace @VIP 5`");
    }

    await raceManager.startRace(message.channel, role.id, amount);
    return "🏁 Race started!";
  }
};
