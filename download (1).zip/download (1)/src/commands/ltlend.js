const ltlManager = require("../handlers/ltlManager");
module.exports = {
  name: "ltlend",
  description:
    "Force-ends the current LTL event early and announces the winner. Normally you shouldn't need this — the event ends itself automatically once only one person is left in the locked channel.",
  ownerOnly: true,
  silent: true,
  async execute(message, args, client) {
    const ended = await ltlManager.endEvent(client, message.guild.id);
    if (!ended) {
      throw new Error("There's no active LTL event right now.");
    }
    return "✅ LTL event ended — results posted.";
  }
};
