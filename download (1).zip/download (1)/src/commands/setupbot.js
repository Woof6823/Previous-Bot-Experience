const { runWizard } = require("../handlers/setupWizard");

module.exports = {
  name: "setupbot",
  description: "Owner-only guided setup using only existing roles, channels, and categories.",
  ownerOnly: true,
  silent: false,
  async execute(message, args, client) {
    await runWizard(message, client);
  }
};
