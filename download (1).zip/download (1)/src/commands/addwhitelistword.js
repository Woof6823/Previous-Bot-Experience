const db = require("../database");

module.exports = {
  name: "addwhitelistword",
  description:
    "Adds a word/phrase that's always allowed, even if it contains a blocked word. Usage: *addwhitelistword <word or phrase>",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const word = args.join(" ").trim();
    if (!word) {
      throw new Error("Usage: `*addwhitelistword <word or phrase>`");
    }
    db.addWhitelistedWord(word);
    return `✅ Added **${word}** to the whitelist.`;
  }
};
