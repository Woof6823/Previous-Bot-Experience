module.exports = {
  name: "pingbots",
  description: "Pings every bot currently in the server, clearly labelled.",
  ownerOnly: true,
  silent: false,
  async execute(message) {





    const bots = [...message.guild.members.cache.values()].filter((m) => m.user.bot);

    if (bots.length === 0) {
      return "No bots found in this server.";
    }

    const lines = bots.map((b) => `🤖 **${b.user.tag}** — <@${b.id}>`);
    const chunks = [];
    let current = `**Bots in this server (${bots.length}):**\n`;
    for (const line of lines) {
      if ((current + "\n" + line).length > 1900) {
        chunks.push(current);
        current = "";
      }
      current += `${line}\n`;
    }
    chunks.push(current);

    for (const chunk of chunks) {
      await message.channel
        .send({ content: chunk, allowedMentions: { users: bots.map((b) => b.id) } })
        .catch(() => {});
    }
  }
};
