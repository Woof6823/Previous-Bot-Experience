const db = require("../database");

module.exports = {
  name: "removewhitelistword",
  description:
    "Removes a word/phrase from the whitelist. Usage: *removewhitelistword <word or phrase>",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const word = args.join(" ").trim();
    if (!word) {
      throw new Error("Usage: `*removewhitelistword <word or phrase>`");
    }
    const removed = db.removeWhitelistedWord(word);
    return removed
      ? `✅ Removed **${word}** from the whitelist.`
      : `⚠️ **${word}** wasn't on the whitelist.`;
  }
};
