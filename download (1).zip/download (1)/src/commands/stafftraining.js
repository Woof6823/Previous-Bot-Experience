const trainingManager = require("../handlers/trainingManager");

module.exports = {
  name: "stafftraining",
  description:
    "Creates a private staff training centre channel for a new staff member. Usage: *stafftraining @user",
  ownerOnly: false,
  staffOnly: true,
  silent: true,
  async execute(message) {
    const trainee = message.mentions.members?.first();
    if (!trainee) {
      throw new Error("Usage: `*stafftraining @user`");
    }
    if (trainee.user.bot) {
      throw new Error("Can't run training for a bot.");
    }

    const channel = await trainingManager.startTrainingChannel(
      message.guild,
      message.member,
      trainee
    );
    return `✅ Training centre created: ${channel}`;
  }
};
