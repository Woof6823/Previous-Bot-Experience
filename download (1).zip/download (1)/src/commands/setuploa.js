const loaManager = require("../handlers/loaManager");
const settings = require("../settings");

module.exports = {
  name: "setuploa",
  description: "Posts the LOA system panel in the LOA channel.",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    const channel = message.guild.channels.cache.get(settings.get("loaChannelId"));
    if (!channel) throw new Error("LOA channel not found — check the ID in config.js.");
    await loaManager.refreshPanel(channel);
    return "✅ LOA panel posted.";
  }
};
