const path = require("path");
const fs = require("fs");
const { AttachmentBuilder } = require("discord.js");
const { hasStaffAccess } = require("../utils/staffAccess");

const VIDEO_PATH = path.join(process.cwd(), "assets", "servertag", "servertag.mp4");

module.exports = {
  name: "servertag",
  description: "Sends the servertag.mp4 video in this channel.",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message) {
    if (!hasStaffAccess(message.member)) {
      throw new Error("🚫 You don't have permission to use this.");
    }

    if (!fs.existsSync(VIDEO_PATH)) {
      throw new Error("⚠️ `servertag.mp4` hasn't been uploaded to `assets/servertag/` yet.");
    }

    await message.channel
      .send({ files: [new AttachmentBuilder(VIDEO_PATH, { name: "servertag.mp4" })] })
      .catch((err) => {
        throw new Error(
          `⚠️ Failed to send the video (likely too large for this server's upload limit): ${err.message}`
        );
      });
  }
};
