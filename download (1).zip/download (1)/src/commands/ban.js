const { EmbedBuilder } = require("discord.js");
const db = require("../database");
const { resolveTargetId, announceModAction } = require("../utils/moderation");
const { hasModPermission, canModerateTarget } = require("../utils/modPermissions");
const { isOwner } = require("../utils/staffAccess");
const logManager = require("../handlers/logManager");

const APPEALS_LINK = "https://discord.gg/xWb9d4yB4J";

module.exports = {
  name: "ban",
  description: "Bans a user. Usage: *ban <userid or @user> <reason>",
  ownerOnly: false,
  silent: false,
  async execute(message, args) {
    const targetId = resolveTargetId(args[0]);
    const reason = args.slice(1).join(" ") || "No reason provided";
    if (!targetId) throw new Error("Usage: `*ban <userid or @user> <reason>`");
    if (targetId === message.author.id) throw new Error("You cannot ban yourself.");
    if (targetId === message.client.user.id) throw new Error("I cannot ban myself.");
    if (isOwner(targetId)) throw new Error("🚫 This user can never be banned.");

    const targetMember = await message.guild.members.fetch(targetId).catch(() => null);

    if (targetMember) {
      const check = canModerateTarget(message.member, targetMember, "ban");
      if (!check.allowed) {
        if (check.reason === "hierarchy") {
          throw new Error("🚫 You can't ban someone with a role equal to or higher than yours.");
        }
        throw new Error(
          "🚫 You don't have permission to ban people. Ask an owner to tick the \"Ban Members\" permission on one of your roles."
        );
      }
    } else if (!hasModPermission(message.member, "ban")) {
      throw new Error(
        "🚫 You don't have permission to ban people. Ask an owner to tick the \"Ban Members\" permission on one of your roles."
      );
    }


    const dmEmbed = new EmbedBuilder()
      .setColor(0xed4245)
      .setTitle(`🔨 Banned from ${message.guild.name}`)
      .setDescription(
        `You have been banned from **${message.guild.name}**.\n\n**Reason:** ${reason}\n\nIf you believe this is a mistake or your account was compromised, you can appeal in our appeals server:\n${APPEALS_LINK}`
      )
      .setTimestamp();

    if (targetMember) {
      await targetMember.send({ embeds: [dmEmbed] }).catch(() => {});
    } else {
      const user = await message.client.users.fetch(targetId).catch(() => null);
      if (user) await user.send({ embeds: [dmEmbed] }).catch(() => {});
    }

    try {



      await message.guild.members.ban(targetId, {
        reason: `${message.author.tag}: ${reason}`,
        deleteMessageSeconds: 604800
      });
    } catch (err) {
      throw new Error(`Failed to ban: ${err.message}`);
    }

    db.addModLog(targetId, message.author.id, "ban", reason);

    logManager
      .log(message.guild, {
        type: "moderation",
        title: "🔨 Member Banned",
        target: `<@${targetId}> (${targetId})`,
        actor: message.author,
        fields: [{ name: "Reason", value: reason }]
      })
      .catch(() => {});

    await announceModAction(message.channel, targetId, "banned");
    return `🔨 <@${targetId}> has been banned.`;
  }
};
