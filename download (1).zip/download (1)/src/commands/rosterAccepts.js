const db = require("../database");
const { hasStaffAccess } = require("../utils/staffAccess");

function buildMessage(roleId, openerId) {
  return `**🎉 Congratulations, <@${openerId}>!**

You have been **accepted to apply for the <@&${roleId}>!** 🏆

To receive the **<@&${roleId}>**, please complete **all of the requirements below** and send **screenshots/proof showing that each requirement has been completed.** 📸✅

**📋 Requirements:**

* 🛒 **Use our Creator Code:** \`RegionX\` in the Fortnite Item Shop.

* 🎮 **Represent us in Fortnite:** Change your Epic Games username so that it has **SRG** at the beginning.

* 💬 **Represent us on Discord:** Add **SRG** to the beginning of your Discord name.

* 🏷️ **Use our Discord Server Tag.**

* 🔗 **Join our Scrims Server:** https://discord.gg/vurge

**✅ Once everything above has been completed and you have provided proof, you will be assigned the <@&${roleId}>!**

Good luck, and welcome to the team! 🫡🔥`;
}

function buildRosterAcceptCommand({ name, roleId }) {
  return {
    name,
    description: `Sends the acceptance + requirements list for the <@&${roleId}> roster. Roster tickets only.`,
    ownerOnly: false,
    staffOnly: true,
    silent: false,
    async execute(message) {
      const ticket = db.getTicketByChannel(message.channel.id);
      if (!ticket || ticket.status !== "open" || ticket.type !== "roster") {
        throw new Error("This command only works inside a Roster ticket channel.");
      }
      if (!hasStaffAccess(message.member)) {
        throw new Error("🚫 You need staff access to use this.");
      }

      await message.channel
        .send(buildMessage(roleId, ticket.user_id))
        .catch(() => {});


      await message.channel
        .send("⚠️ Please send screenshots proof of all completed.")
        .catch(() => {});
    }
  };
}

const ROSTER_ACCEPTS = [
  { name: "tokenpro", roleId: "1513385896794259538" },
  { name: "tokenadmin", roleId: "1538048279705821285" },
  { name: "tokenacademy", roleId: "1538048356960436275" }
];

module.exports = ROSTER_ACCEPTS.map(buildRosterAcceptCommand);
