const suggestionsManager = require("../handlers/suggestionsManager");
const settings = require("../settings");

module.exports = {
  name: "setupsuggestions",
  description: "Posts the suggestions panel in the suggestions channel.",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    const channel = message.guild.channels.cache.get(settings.get("suggestionsChannelId"));
    if (!channel) throw new Error("Suggestions channel not found — check the ID in config.js.");
    await channel.send(suggestionsManager.buildPanel());
    return "✅ Suggestions panel posted.";
  }
};
