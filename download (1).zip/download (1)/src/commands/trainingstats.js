const { EmbedBuilder } = require("discord.js");
const config = require("../config");
const { hasStaffAccess } = require("../utils/staffAccess");
const { resolveDisplayName } = require("../handlers/staffStatsManager");
const { getScenario } = require("../data/rosterScenarios");
const staffRecords = require("../handlers/staffRecords");

function formatMs(ms) {
  const mins = Math.round(ms / 60000);
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h <= 0) return `${m}m`;
  return `${h}h ${m}m`;
}

function scenarioLabel(id) {
  const sc = getScenario(id);
  const pretty = id.replace(/-/g, " ");
  return sc ? `${sc.category} — ${pretty}` : pretty;
}

module.exports = {
  name: "trainingstats",
  aliases: ["trainingsheet"],
  description:
    "Combined staff-training results sheet: completion rate, average/best/worst times, and per-scenario first-try accuracy. Add `names` to list every trainee by name.",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message, args) {
    if (!hasStaffAccess(message.member)) {
      throw new Error("🚫 You don't have permission to use this.");
    }
    const withNames = (args[0] || "").toLowerCase() === "names";

    const all = staffRecords.getAllTrainingSessions();
    const completed = staffRecords
      .getCompletedTrainingSessions()
      .filter((s) => s.completed_at)
      .map((s) => ({ ...s, duration: s.completed_at - s.created_at }))
      .sort((a, b) => a.duration - b.duration);


    const timesEmbed = new EmbedBuilder()
      .setColor(config.brandColor)
      .setTitle("🎓 Training Results Sheet");

    if (completed.length === 0) {
      timesEmbed.setDescription("No completed training sessions recorded yet.");
    } else {
      const total = completed.reduce((sum, s) => sum + s.duration, 0);
      const avg = total / completed.length;
      const best = completed[0];
      const worst = completed[completed.length - 1];
      const bestName = withNames ? await resolveDisplayName(message.guild, best.trainee_id) : null;
      const worstName = withNames
        ? await resolveDisplayName(message.guild, worst.trainee_id)
        : null;

      timesEmbed.setDescription(
        `**Sessions started:** ${all.length}\n**Sessions completed (perfect pass):** ${completed.length}\n**Completion rate:** ${Math.round((completed.length / all.length) * 100)}%`
      );
      timesEmbed.addFields(
        { name: "⏱️ Average time", value: formatMs(avg), inline: true },
        {
          name: "🏆 Best time",
          value: bestName ? `${formatMs(best.duration)} — ${bestName}` : formatMs(best.duration),
          inline: true
        },
        {
          name: "🐢 Worst time",
          value: worstName
            ? `${formatMs(worst.duration)} — ${worstName}`
            : formatMs(worst.duration),
          inline: true
        }
      );

      if (withNames) {
        const lines = [];
        for (const s of completed) {
          const n = await resolveDisplayName(message.guild, s.trainee_id);
          lines.push(
            `**${n}** — ${formatMs(s.duration)} (<t:${Math.floor(s.completed_at / 1000)}:d>)`
          );
        }
        timesEmbed.addFields({ name: "👥 Everyone (fastest first)", value: lines.join("\n") });
      }
    }


    const results = staffRecords.getScenarioResults();
    const byScenario = new Map();
    for (const r of results) {
      if (!byScenario.has(r.scenario_id))
        byScenario.set(r.scenario_id, { attempted: 0, firstTry: 0, mistakes: 0 });
      const entry = byScenario.get(r.scenario_id);
      entry.attempted += 1;
      if (r.completed && r.wrong_count === 0) entry.firstTry += 1;
      entry.mistakes += r.wrong_count;
    }
    const scenarioRows = [...byScenario.entries()]
      .map(([id, e]) => ({ id, ...e, pct: Math.round((e.firstTry / e.attempted) * 100) }))
      .sort((a, b) => a.pct - b.pct);

    const accEmbed = new EmbedBuilder()
      .setColor(config.brandColor)
      .setTitle("🎭 Scenario Accuracy (first-try correct)")
      .setDescription(
        scenarioRows.length
          ? scenarioRows
              .map(
                (r) =>
                  `**${r.pct}%** — ${scenarioLabel(r.id)}  *(${r.firstTry}/${r.attempted} first-try, ${r.mistakes} total mistake${r.mistakes === 1 ? "" : "s"})*`
              )
              .join("\n")
          : "No scenario attempts recorded yet."
      )
      .setFooter({ text: "Lowest accuracy first — the scenarios staff struggle with most." });

    await message.channel.send({ embeds: [timesEmbed, accEmbed] });
  }
};
