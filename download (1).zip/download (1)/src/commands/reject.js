const { resolveTargetId } = require("../utils/moderation");
const tempVoiceManager = require("../handlers/tempVoiceManager");

module.exports = {
  name: "reject",
  description:
    "Kicks someone from your voice channel and blocks them from rejoining. Usage: *reject @user",
  ownerOnly: false,
  silent: true,
  async execute(message, args) {
    tempVoiceManager.requireOwnedVC(message);

    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      throw new Error("Usage: `*reject <userid or @user>`");
    }
    if (targetId === message.author.id) {
      throw new Error("You can't reject yourself from your own channel.");
    }

    const targetMember = await message.guild.members.fetch(targetId).catch(() => null);
    if (!targetMember) {
      throw new Error("Couldn't find that member in this server.");
    }

    await message.channel.permissionOverwrites.edit(targetMember, {
      ViewChannel: false,
      Connect: false
    });

    if (targetMember.voice.channelId === message.channel.id) {
      await targetMember.voice.disconnect().catch(() => {});
    }

    return `🚫 <@${targetId}> has been removed and blocked from this channel.`;
  }
};
