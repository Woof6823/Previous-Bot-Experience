const tempVoiceManager = require("../handlers/tempVoiceManager");

module.exports = {
  name: "unlock",
  description: "Unlocks your voice channel so anyone can join again. Run inside your VC's chat.",
  ownerOnly: false,
  silent: true,
  async execute(message) {
    tempVoiceManager.requireOwnedVC(message);
    await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, {
      Connect: true
    });
    return "🔓 Channel unlocked.";
  }
};
