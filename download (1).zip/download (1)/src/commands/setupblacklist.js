const blacklistManager = require("../handlers/blacklistManager");
const settings = require("../settings");

module.exports = {
  name: "setupblacklist",
  description: "Posts the blacklist system panel in the blacklist channel.",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    const channel = message.guild.channels.cache.get(settings.get("blacklistChannelId"));
    if (!channel) throw new Error("Blacklist channel not found — check the ID in config.js.");
    await blacklistManager.refreshPanel(channel);
    return "✅ Blacklist panel posted.";
  }
};
