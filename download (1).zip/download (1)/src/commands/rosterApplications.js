const db = require("../database");
const ticketManager = require("../handlers/ticketManager");
const { hasStaffAccess } = require("../utils/staffAccess");

const DEFINITIONS = [
  { command: "grinder", roleLabel: "Grinder+ Role" },
  { command: "creator", roleLabel: "Content Creator Role" },
  { command: "juniorcreator", roleLabel: "Junior Content Creator Role" },
  { command: "creativeacademy", roleLabel: "Creative Academy Role" },
  { command: "maincreative", roleLabel: "Main Creative Roster Role" },
  { command: "procreative", roleLabel: "Pro Creative Roster Role" },
  { command: "futureacademy", roleLabel: "Future Academy Role" },
  { command: "academy", roleLabel: "Academy Role" },
  { command: "future2", roleLabel: "Future 2.0 Role" },
  { command: "semipro", roleLabel: "Semi Pro Role" },
  { command: "pro", roleLabel: "Pro Roster" },
  { command: "streamer", roleLabel: "Streamer Role" },
  { command: "vfxgfx", roleLabel: "VFX/GFX Role" }
];

function buildMessage(roleName, openerId) {
  return `**🎉 Congratulations, <@${openerId}>!**

You have been **accepted to apply for the ${roleName}!** 🏆

To receive the **${roleName}**, please complete **all of the requirements below** and send **screenshots/proof showing that each requirement has been completed.** 📸✅

**📋 Requirements:**

* 🛒 **Use our Creator Code:** \`RegionX\` in the Fortnite Item Shop.

* 🎮 **Represent us in Fortnite:** Change your Epic Games username so that it has **SRG** at the beginning.

* 💬 **Represent us on Discord:** Add **SRG** to the beginning of your Discord name.

* 🏷️ **Use our Discord Server Tag.**

* 🔗 **Join our Scrims Server:** https://discord.gg/vurge

**✅ Once everything above has been completed and you have provided proof, you will be assigned the ${roleName}!**

Good luck, and welcome to the team! 🫡🔥`;
}

function makeCommand(def) {
  return {
    name: def.command,
    description: `Roster-ticket command: sends the ${def.roleLabel} application requirements.`,
    ownerOnly: false,
    staffOnly: true,
    silent: false,
    async execute(message) {
      if (!hasStaffAccess(message.member)) {
        throw new Error("🚫 Only ticket support staff can run this command.");
      }
      const ticket = db.getTicketByChannel(message.channel.id);
      if (!ticket || ticket.type !== "roster") {
        throw new Error("This command only works inside a Roster ticket channel.");
      }

      const content = buildMessage(def.roleLabel, ticket.user_id);
      await message.channel.send(content);


      await message.channel.send("⚠️ Please send screenshots proof of all completed.").catch(() => {});

      if (def.command === "pro") {
        db.setTicketProWaiting(message.channel.id, true);
        ticketManager.queueChannelRename(message.channel, message.channel.id);
      }
    }
  };
}

module.exports = DEFINITIONS.map(makeCommand);
