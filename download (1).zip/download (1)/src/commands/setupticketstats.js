const ticketStatsManager = require("../handlers/ticketStatsManager");

module.exports = {
  name: "setupticketstats",
  description: "Posts (or reposts) the live 24h ticket stats embed in this channel.",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    await ticketStatsManager.refreshPanel(message.channel);
    return "✅ Ticket stats panel posted — it updates automatically as tickets are claimed.";
  }
};
