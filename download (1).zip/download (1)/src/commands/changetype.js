const db = require("../database");
const config = require("../config");
const ticketManager = require("../handlers/ticketManager");

module.exports = {
  name: "changetype",
  description:
    "Moves this ticket to a different type. Usage: *changetype <roster|staff|business|general|report>",
  ownerOnly: false,
  staffOnly: true,
  silent: true,
  async execute(message, args) {
    const ticket = db.getTicketByChannel(message.channel.id);
    if (!ticket || ticket.status !== "open") {
      throw new Error("This command only works inside an open ticket channel.");
    }

    const newType = (args[0] || "").toLowerCase();
    if (!config.ticketTypes[newType]) {
      throw new Error(`Usage: \`*changetype <${Object.keys(config.ticketTypes).join("|")}>\``);
    }
    if (newType === ticket.type) {
      throw new Error("That's already this ticket's type.");
    }

    await ticketManager.changeTicketType(message.guild, message.channel.id, newType);
    return `✅ Ticket changed to **${config.ticketTypes[newType].label}** and unclaimed.`;
  }
};
