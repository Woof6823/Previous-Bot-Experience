const { EmbedBuilder } = require("discord.js");
const db = require("../database");
const { resolveTargetId, announceModAction } = require("../utils/moderation");
const { hasModPermission, canModerateTarget } = require("../utils/modPermissions");
const logManager = require("../handlers/logManager");

const APPEALS_LINK = "https://discord.gg/xWb9d4yB4J";

module.exports = {
  name: "kick",
  description: "Kicks a user. Usage: *kick <userid or @user> <reason>",
  ownerOnly: false,
  silent: false,
  async execute(message, args) {
    const targetId = resolveTargetId(args[0]);
    const reason = args.slice(1).join(" ") || "No reason provided";
    if (!targetId) throw new Error("Usage: `*kick <userid or @user> <reason>`");

    const targetMember = await message.guild.members.fetch(targetId).catch(() => null);
    if (!targetMember) throw new Error("That user is not in the server.");
    if (targetMember.id === message.author.id) throw new Error("You cannot kick yourself.");
    if (targetMember.id === message.client.user.id) throw new Error("I cannot kick myself.");

    const check = canModerateTarget(message.member, targetMember, "kick");
    if (!check.allowed) {
      if (check.reason === "owner_target") {
        throw new Error("🚫 This user can never be kicked.");
      }
      if (check.reason === "hierarchy") {
        throw new Error("🚫 You can't kick someone with a role equal to or higher than yours.");
      }
      throw new Error("🚫 You don't have permission to kick people. You need the \"Kick Members\" permission ticked on one of your roles.");
    }

    if (!targetMember.kickable) throw new Error("I don't have permission to kick that user.");

    const dmEmbed = new EmbedBuilder()
      .setColor(0xed4245)
      .setTitle(`👢 Kicked from ${message.guild.name}`)
      .setDescription(
        `You have been kicked from **${message.guild.name}**.\n\n**Reason:** ${reason}\n\nIf you believe this is a mistake or your account was compromised, you can appeal in our appeals server:\n${APPEALS_LINK}`
      )
      .setTimestamp();

    await targetMember.send({ embeds: [dmEmbed] }).catch(() => {});
    await targetMember.kick(`${message.author.tag}: ${reason}`);

    db.addModLog(targetId, message.author.id, "kick", reason);

    logManager
      .log(message.guild, {
        type: "moderation",
        title: "👢 Member Kicked",
        target: `<@${targetId}> (${targetId})`,
        actor: message.author,
        fields: [{ name: "Reason", value: reason }]
      })
      .catch(() => {});

    await announceModAction(message.channel, targetId, "kicked");
    return `👢 <@${targetId}> has been kicked.`;
  }
};
