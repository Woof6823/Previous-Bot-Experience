const db = require("../database");
const { resolveTargetId } = require("../utils/moderation");

module.exports = {
  name: "removethreadblacklist",
  description: "Removes a user from the creator-code forum thread blacklist. Usage: *removethreadblacklist <userid or @user>",
  ownerOnly: true,
  staffOnly: false,
  silent: false,
  async execute(message, args) {
    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      throw new Error("Usage: `*removethreadblacklist <userid or @user>`");
    }

    if (!db.getBlacklist(targetId, "thread")) {
      throw new Error("That user isn't thread-blacklisted.");
    }

    db.removeBlacklist(targetId, "thread");
    return `✅ <@${targetId}> can post creator-code threads again.`;
  }
};
