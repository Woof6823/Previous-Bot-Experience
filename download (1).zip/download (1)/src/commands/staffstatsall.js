const { PermissionFlagsBits } = require("discord.js");
const { buildStaffStatsEmbed } = require("../handlers/staffStatsManager");

const STAFF_ROLE_ID = "1454916770912534706";

module.exports = {
  name: "staffstatsall",
  description: "Display staff statistics for every member with the staff role.",
  ownerOnly: false,
  staffOnly: false,
  silent: false,

  async execute(message) {
    if (!message?.guild) {
      throw new Error("This command can only be used inside a server.");
    }

    if (!message.member?.permissions?.has(PermissionFlagsBits.Administrator)) {
      throw new Error("You must be an Administrator to use this command.");
    }

    const staffRole = await message.guild.roles.fetch(STAFF_ROLE_ID).catch((error) => {
      console.error("[staffstatsall] Failed to fetch staff role:", error);
      return null;
    });

    if (!staffRole) {
      throw new Error(
        `The hardcoded staff role (${STAFF_ROLE_ID}) could not be found in this server.`
      );
    }

    const members = await message.guild.members.fetch();

    const staffMembers = members.filter((member) =>
      member.roles.cache.has(STAFF_ROLE_ID)
    );

    if (!staffMembers.size) {
      await message.channel.send(
        `No members currently have the staff role <@&${STAFF_ROLE_ID}>.`
      );
      return;
    }

    for (const member of staffMembers.values()) {
      try {
        const embed = await buildStaffStatsEmbed(
          message.guild,
          member.id,
          7
        );

        if (embed) {

          await message.channel.send({
            content: `<@${member.id}>`,
            allowedMentions: { users: [] },
            embeds: [embed],
          });
        }
      } catch (error) {
        console.error(
          `[staffstatsall] Failed to build stats for ${member.user?.tag || member.id}:`,
          error
        );
      }
    }
  },
};
