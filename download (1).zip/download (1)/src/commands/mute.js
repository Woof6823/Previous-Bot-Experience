const { EmbedBuilder } = require("discord.js");
const db = require("../database");
const { resolveTargetId, announceModAction } = require("../utils/moderation");
const { hasModPermission, canModerateTarget } = require("../utils/modPermissions");
const logManager = require("../handlers/logManager");

const APPEALS_LINK = "https://discord.gg/xWb9d4yB4J";

function parseDuration(str) {
  if (!str) return 0;
  const match = str.match(/^(\d+)(s|m|h|d|w)$/i);
  if (!match) return 0;
  const val = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();
  if (unit === "s") return val * 1000;
  if (unit === "m") return val * 60 * 1000;
  if (unit === "h") return val * 60 * 60 * 1000;
  if (unit === "d") return val * 24 * 60 * 60 * 1000;
  if (unit === "w") return val * 7 * 24 * 60 * 60 * 1000;
  return 0;
}

module.exports = {
  name: "mute",
  description:
    "Mutes (timeouts) a user. Usage: *mute <userid or @user> <duration e.g. 10m/2h/1d> <reason>",
  ownerOnly: false,
  silent: false,
  async execute(message, args) {
    const targetId = resolveTargetId(args[0]);
    if (!targetId)
      throw new Error("Usage: `*mute <userid or @user> <duration e.g. 10m/2h/1d> <reason>`");

    const durationStr = args[1];
    const durationMs = parseDuration(durationStr);
    if (!durationMs || durationMs <= 0)
      throw new Error("Invalid duration. Use formats like `10m`, `2h`, `1d`.");
    if (durationMs > 28 * 24 * 60 * 60 * 1000)
      throw new Error("Maximum timeout duration is 28 days.");

    const reason = args.slice(2).join(" ") || "No reason provided";

    const targetMember = await message.guild.members.fetch(targetId).catch(() => null);
    if (!targetMember) throw new Error("That user is not in the server.");
    if (targetMember.id === message.author.id) throw new Error("You can't mute yourself.");
    if (targetMember.id === message.client.user.id) throw new Error("I can't mute myself.");

    const check = canModerateTarget(message.member, targetMember, "mute");
    if (!check.allowed) {
      if (check.reason === "owner_target") {
        throw new Error("🚫 This user can never be muted.");
      }
      if (check.reason === "hierarchy") {
        throw new Error("🚫 You can't mute someone with a role equal to or higher than yours.");
      }
      throw new Error("🚫 You don't have permission to mute people. You need the staff access role AND the \"Timeout Members\" permission ticked on one of your roles.");
    }

    if (!targetMember.moderatable)
      throw new Error("I don't have permission to mute that user (check role hierarchy).");

    const dmEmbed = new EmbedBuilder()
      .setColor(0xf5c400)
      .setTitle(`🔇 Muted in ${message.guild.name}`)
      .setDescription(
        `You have been muted (timed out) in **${message.guild.name}** for **${durationStr}**.\n\n**Reason:** ${reason}\n\nIf you believe this is a mistake or your account was compromised, you can appeal in our appeals server:\n${APPEALS_LINK}`
      )
      .setTimestamp();

    await targetMember.send({ embeds: [dmEmbed] }).catch(() => {});
    await targetMember.timeout(durationMs, `${message.author.tag}: ${reason}`);

    db.addModLog(targetId, message.author.id, "mute", reason, durationMs);

    logManager
      .log(message.guild, {
        type: "moderation",
        title: "🔇 Member Muted",
        target: `<@${targetId}> (${targetId})`,
        actor: message.author,
        fields: [
          { name: "Duration", value: durationStr, inline: true },
          { name: "Reason", value: reason, inline: true }
        ]
      })
      .catch(() => {});

    await announceModAction(message.channel, targetId, `muted for ${durationStr}`);
    return `🔇 <@${targetId}> has been muted for ${durationStr}.`;
  }
};
