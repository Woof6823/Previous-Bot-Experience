const config = require("../config");
const botStatusManager = require("../handlers/botStatusManager");

module.exports = {
  name: "notworking",
  description: "Announces the bot/server is not working and pings staff. Bot status channel only.",
  ownerOnly: true,
  silent: false,
  async execute(message, args, client) {
    if (
      message.channel.id !== config.botStatusChannelId &&
      message.channel.id !== config.testingChannelId
    ) {
      throw new Error("This command only works in the bot status channel.");
    }
    await botStatusManager.announce(client, "notworking");
  }
};
