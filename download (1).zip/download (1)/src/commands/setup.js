const setupBot = require("./setupbot");

module.exports = {
  ...setupBot,
  name: "setup",
  description: "Owner-only guided setup using only existing roles, channels, and categories."
};
