const { EmbedBuilder } = require("discord.js");
const securityManager = require("../handlers/securityManager");
const config = require("../config");

module.exports = {
  name: "securitystatus",
  description: "Shows the status of every security feature.",
  ownerOnly: true,
  silent: false,

  async execute(message) {
    const statuses = securityManager.getAllStatuses();

    const enabled = statuses.filter((status) => status.enabled);
    const disabled = statuses.filter((status) => !status.enabled);

    const lines = statuses.map((status) => {
      const icon = status.enabled ? "🟢" : "🔴";

      return (
        `${icon} **${status.label}**\n` +
        `└─ Scope: **${securityManager.describeScope(status.scope)}**\n` +
        `└─ \`${config.prefix}${status.key} on|off|all [#channels]\``
      );
    });

    const embed = new EmbedBuilder()
      .setColor(disabled.length === 0 ? 0x57f287 : 0xfee75c)
      .setTitle("🛡️ Security Suite Status")
      .setDescription(lines.join("\n\n"))
      .addFields(
        {
          name: "Enabled",
          value: `${enabled.length}`,
          inline: true
        },
        {
          name: "Disabled",
          value: `${disabled.length}`,
          inline: true
        },
        {
          name: "Total",
          value: `${statuses.length}`,
          inline: true
        }
      )
      .setFooter({
        text: "Security features are enabled by default unless explicitly disabled."
      })
      .setTimestamp();

    await message.channel.send({
      embeds: [embed]
    });
  }
};
