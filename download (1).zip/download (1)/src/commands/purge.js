module.exports = {
  name: "purge",
  description: "Bulk deletes recent messages in this channel. Usage: *purge <count 1-100>",
  ownerOnly: false,
  staffOnly: true,
  silent: true,
  async execute(message, args) {
    const count = parseInt(args[0], 10);
    if (Number.isNaN(count) || count < 1 || count > 100) {
      throw new Error("Usage: `*purge <count between 1 and 100>`");
    }


    let deleted;
    try {
      deleted = await message.channel.bulkDelete(count, false);
    } catch {

      const messages = await message.channel.messages.fetch({ limit: count }).catch(() => null);
      if (!messages || messages.size === 0) {
        throw new Error("Couldn't find any messages to delete.");
      }
      let deletedCount = 0;
      for (const msg of messages.values()) {
        try {
          await msg.delete();
          deletedCount++;
        } catch {

        }
      }
      return `✅ Deleted ${deletedCount} message(s).`;
    }
    if (!deleted || deleted.size === 0) {
      throw new Error("Couldn't delete those messages (they may be older than 14 days).");
    }
    return `✅ Deleted ${deleted.size} message(s).`;
  }
};
