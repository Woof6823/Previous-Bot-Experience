const db = require("../database");

module.exports = {
  name: "setrosterrole",
  description:
    "Sets which role(s) get pinged + can see Roster tickets. Usage: *setrosterrole @role [@role2 ...]",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    const roles = [...message.mentions.roles.values()];
    if (roles.length === 0) {
      throw new Error("Usage: `*setrosterrole @role [@role2 ...]` — mention one or more roles.");
    }

    const ids = roles.map((r) => r.id);
    db.setSetting("roster_ping_role_ids", JSON.stringify(ids));

    return `✅ Roster tickets will now ping and grant access to: ${roles.map((r) => r.toString()).join(", ")}`;
  }
};
