const { EmbedBuilder } = require("discord.js");
const db = require("../database");
const config = require("../config");
const { resolveTargetId } = require("../utils/moderation");
const { resolveDisplayName } = require("../handlers/staffStatsManager");





function formatModerator(moderatorId) {
  if (/^\d+$/.test(String(moderatorId))) {
    return `<@${moderatorId}>`;
  }
  return moderatorId;
}

function formatDuration(ms) {
  if (!ms || ms <= 0) return null;
  const totalMinutes = Math.round(ms / 60000);
  const days = Math.floor(totalMinutes / 1440);
  const hours = Math.floor((totalMinutes % 1440) / 60);
  const minutes = totalMinutes % 60;
  const parts = [];
  if (days) parts.push(`${days}d`);
  if (hours) parts.push(`${hours}h`);
  if (minutes) parts.push(`${minutes}m`);
  return parts.length ? parts.join(" ") : "<1m";
}

module.exports = {
  name: "modlogs",
  description: "Shows moderation actions taken on a user. Usage: *modlogs <userid or @user>",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message, args) {
    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      throw new Error("Usage: `*modlogs <userid or @user>`");
    }

    const logs = db.getModLogs(targetId, 15);
    const displayName = await resolveDisplayName(message.guild, targetId);
    const embed = new EmbedBuilder()
      .setColor(config.brandColor)
      .setTitle(`📋 Mod Logs for ${displayName}`);

    if (logs.length === 0) {
      embed.setDescription("No moderation actions on record.");
    } else {
      embed.setDescription(
        logs
          .map((l) => {
            const duration = formatDuration(l.duration_ms);
            const durationText = duration ? ` (${duration})` : "";
            return `**${l.action.toUpperCase()}**${durationText} by ${formatModerator(l.moderator_id)} — <t:${Math.floor(l.created_at / 1000)}:R>\n${l.reason || "No reason given."}`;
          })
          .join("\n\n")
      );
    }

    await message.channel.send({ embeds: [embed] });
  }
};
