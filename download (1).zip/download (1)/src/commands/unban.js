const db = require("../database");
const { resolveTargetId, sendModerationDM, announceModAction } = require("../utils/moderation");
const { hasModPermission } = require("../utils/modPermissions");
const { cancelUnbanTimer } = require("../utils/banManager");
const logManager = require("../handlers/logManager");

module.exports = {
  name: "unban",
  description: "Unbans a user. Usage: *unban <userid>",
  ownerOnly: false,
  silent: false,
  async execute(message, args, client) {
    if (!hasModPermission(message.member, "ban")) {
      throw new Error("🚫 You don't have permission to unban people.");
    }

    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      throw new Error("Usage: `*unban <userid>`");
    }

    const bannedUser = await message.guild.bans.fetch(targetId).catch(() => null);
    if (!bannedUser) {
      throw new Error("That user isn't currently banned.");
    }

    await message.guild.members.unban(targetId, `Unbanned by ${message.author.username}`);
    db.addModLog(targetId, message.author.id, "unban", "Manually unbanned.");
    logManager
      .log(message.guild, {
        type: "mod",
        title: "✅ Member Unbanned",
        actor: message.author,
        target: `<@${targetId}>`
      })
      .catch(() => {});

    const activeTempBan = db.getActiveTempBanByUser(targetId);
    if (activeTempBan) {
      cancelUnbanTimer(activeTempBan.id);
      db.deactivateTempBan(activeTempBan.id);
    }

    sendModerationDM(client, targetId, {
      action: "un-banned",
      reason: "You've been unbanned and can rejoin.",
      guildName: message.guild.name
    }).catch(() => {});

    await announceModAction(message.channel, targetId, "unbanned");
    return `✅ <@${targetId}> has been unbanned.`;
  }
};
