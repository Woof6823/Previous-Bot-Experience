const securityManager = require("../handlers/securityManager");
const config = require("../config");

function buildToggleCommand(featureKey) {
  const featureDescription = securityManager.FEATURES[featureKey];

  return {
    name: featureKey,
    description: `Toggle ${featureDescription}. Use on/off, or add channel mentions for a scoped setting.`,
    ownerOnly: true,
    silent: true,

    async execute(message, args) {
      const choice = String(args[0] || "").toLowerCase();

      if (!["on", "off", "all"].includes(choice)) {
        const currentState = securityManager.isEnabled(featureKey) ? "ON" : "OFF";

        throw new Error(
          `Usage: \`${config.prefix}${featureKey} on|off|all [#channels]\`\n` +
            `Current status: **${currentState}**`
        );
      }

      const channelIds = message.mentions.channels.map((channel) => channel.id);
      const enabled = choice !== "off";

      if (choice === "all") {
        if (!securityManager.configureScope(featureKey, true, [])) {
          throw new Error(`Security feature \`${featureKey}\` does not exist.`);
        }
      } else if (!securityManager.configureScope(featureKey, enabled, channelIds)) {
        throw new Error(`Security feature \`${featureKey}\` does not exist.`);
      }

      const status = securityManager.getAllStatuses().find((entry) => entry.key === featureKey);

      return (
        `🛡️ **${featureDescription}**\n` +
        `Scope: **${securityManager.describeScope(status.scope)}**`
      );
    }
  };
}

module.exports = Object.keys(securityManager.FEATURES).map(buildToggleCommand);
