const { parseDuration } = require("../utils/duration");
const guessGameManager = require("../handlers/guessGameManager");

module.exports = {
  name: "guessgame",
  description:
    "Schedules a Guess The Number game. Usage: *guessgame <start> <end> <delay e.g. 30m/2h/1d> [emoji emoji ...]",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const rangeStart = parseInt(args[0], 10);
    const rangeEnd = parseInt(args[1], 10);
    const durationArg = args[2];
    const reactions = args.slice(3);

    if (!Number.isInteger(rangeStart) || !Number.isInteger(rangeEnd) || rangeStart >= rangeEnd) {
      throw new Error(
        "Usage: `*guessgame <start> <end> <delay> [emoji emoji ...]` — start must be less than end."
      );
    }

    const duration = parseDuration(durationArg);
    if (!duration || duration.permanent) {
      throw new Error("Invalid delay — use something like `30m`, `2h`, or `1d`.");
    }

    const startAt = Date.now() + duration.ms;

    await guessGameManager.startGame(message.guild, {
      rangeStart,
      rangeEnd,
      startAt,
      reactions
    });

    return `✅ Guess The Number scheduled — starts <t:${Math.floor(startAt / 1000)}:R>, range **${rangeStart}-${rangeEnd}**.`;
  }
};
