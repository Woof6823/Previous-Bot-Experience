const config = require("../config");
const userStats = require("../handlers/userStatsManager");
module.exports = {
  name: "topstats",
  description: "Server activity leaderboard card with metric tabs, ranges and pages.",
  ownerOnly: false,
  silent: false,
  keepMessage: true,
  async execute(message) {
    if (
      message.channel.id !== userStats.STATS_CHANNEL_ID &&
      message.channel.id !== config.testingChannelId
    ) {
      throw new Error(`Please use this in <#${userStats.STATS_CHANNEL_ID}>.`);
    }
    const payload = await userStats.buildTopStatsPayload(
      message.guild,
      "messages",
      14,
      0,
      Date.now()
    );
    await message.channel.send(payload);
  }
};
