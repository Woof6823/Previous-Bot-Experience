const commandPermsOverride = require("../utils/commandPermsOverride");

module.exports = {
  name: "removecommandperms",
  description:
    "Revokes a per-user command permission previously granted with *addcommandperms. Usage: *removecommandperms <command> @user",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const commandName = (args[0] || "").toLowerCase();
    const user = message.mentions.users.first();

    if (!commandName || !user) {
      throw new Error("Usage: `*removecommandperms <command> @user`");
    }

    commandPermsOverride.removeOverride(commandName, user.id);
    return `✅ Removed ${user}'s permission override for \`*${commandName}\`.`;
  }
};
