const { PermissionsBitField } = require("discord.js");
const db = require("../database");
const { resolveTargetId } = require("../utils/moderation");
const socialAccounts = require("../utils/socialAccounts");

const SESSION_TIMEOUT_MS = 5 * 60 * 1000;
const MAX_ATTEMPTS = 6;

module.exports = {
  name: "linkaccounts",
  description:
    "Links or updates a Discord user's social media accounts for the website. Usage: *linkaccounts @user",
  ownerOnly: false,
  staffOnly: false,
  silent: false,
  async execute(message, args) {




    if (!message.member || !message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      await message.channel.send("🚫 You need the Administrator permission to use this command.");
      return null;
    }


    if (!args[0]) {
      await message.channel.send("Usage: `*linkaccounts @user` or `*linkaccounts <user id>`");
      return null;
    }
    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      await message.channel.send("Usage: `*linkaccounts @user` or `*linkaccounts <user id>`");
      return null;
    }

    const member = await message.guild.members.fetch(targetId).catch(() => null);
    if (!member) {
      await message.channel.send("Couldn't find that user in this server.");
      return null;
    }

    const existing = db.getSocialAccounts(targetId);
    const template = socialAccounts.buildTemplate(existing);

    const prompt = await message.channel.send(
      `Send the links for ${member}'s accounts below. Leave any you don't have blank, and type \`cancel\` to stop.\n\`\`\`\n${template}\n\`\`\``
    );

    const filter = (m) => m.author.id === message.author.id;

    let pending = { ...existing };
    let attempts = 0;
    const deadline = Date.now() + SESSION_TIMEOUT_MS;

    while (attempts < MAX_ATTEMPTS) {
      attempts++;
      const timeLeft = deadline - Date.now();
      if (timeLeft <= 0) {
        await prompt.edit(`⏱️ Session expired for ${member}. No changes were made. Run the command again.`).catch(() => {});
        return null;
      }

      const collected = await message.channel
        .awaitMessages({ filter, max: 1, time: timeLeft, errors: ["time"] })
        .catch(() => null);

      if (!collected) {
        await prompt.edit(`⏱️ Session expired for ${member}. No changes were made. Run the command again.`).catch(() => {});
        return null;
      }

      const reply = collected.first();
      const content = reply.content;
      reply.delete().catch(() => {});

      if (content.trim().toLowerCase() === "cancel") {
        await prompt.edit(`❌ Cancelled — no changes were made for ${member}.`).catch(() => {});
        return null;
      }

      const parsed = socialAccounts.parseSubmission(content);
      if (Object.keys(parsed).length === 0) {
        await message.channel.send(
          "I couldn't read any accounts from that message. Reply with the template lines (e.g. `YouTube: https://youtube.com/@example`), or type `cancel`."
        ).then((m) => setTimeout(() => m.delete().catch(() => {}), 8000)).catch(() => {});
        continue;
      }

      pending = { ...pending, ...parsed };
      const { valid, errors, cleaned } = socialAccounts.validate(pending);

      if (!valid) {
        const errorLines = errors.map((e) => `• **${e.label}**: ${e.reason}`).join("\n");
        await message.channel.send(
          `A few of those links don't look right:\n${errorLines}\n\nResend just the corrected line(s), or type \`cancel\`.`
        );
        continue;
      }

      db.upsertSocialAccounts(targetId, cleaned, message.author.id);
      await prompt.edit(`✅ Accounts updated for ${member}.`).catch(() => {});
      return null;
    }

    await prompt.edit(`❌ Too many invalid attempts for ${member}. No changes were made. Run the command again.`).catch(() => {});
    return null;
  }
};
