const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const accountAgeGateManager = require("../handlers/accountAgeGateManager");






module.exports = {
  name: "accountagekick",
  description:
    "Scans current members for accounts under 3 days old and shows a Confirm/Cancel before kicking any of them. Owner-only, one-time cleanup — new joins are handled automatically.",
  ownerOnly: true,
  silent: false,

  async execute(message) {
    await message.guild.members.fetch().catch(() => {});
    const candidates = accountAgeGateManager.findUnderageMembers(message.guild);

    if (candidates.length === 0) {
      return "✅ No current members have an account under 3 days old — nothing to do.";
    }

    const scanId = accountAgeGateManager.createScan(
      message.guild.id,
      message.author.id,
      candidates.map((m) => m.id)
    );

    const preview = candidates
      .slice(0, 25)
      .map(
        (m) =>
          `• ${m.user.tag} (${m.id}) — created <t:${Math.floor(m.user.createdTimestamp / 1000)}:R>`
      )
      .join("\n");

    const embed = new EmbedBuilder()
      .setColor(0xf5c400)
      .setTitle("⚠️ Account Age Kick — Review Before Confirming")
      .setDescription(
        `**${candidates.length}** current member(s) have an account under 3 days old and would be DMed then kicked.\n\n` +
          preview +
          (candidates.length > 25 ? `\n...and ${candidates.length - 25} more.` : "")
      )
      .setFooter({
        text: "Expires in 10 minutes if not confirmed. Only the 5 owners can Confirm, List, or Cancel."
      });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`accountagekick_confirm_${scanId}`)
        .setLabel(`Confirm — Kick ${candidates.length}`)
        .setEmoji("✅")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId(`accountagekick_list_${scanId}`)
        .setLabel("Ping All In Channel")
        .setEmoji("📋")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`accountagekick_cancel_${scanId}`)
        .setLabel("Cancel")
        .setEmoji("❌")
        .setStyle(ButtonStyle.Secondary)
    );

    await message.channel.send({ embeds: [embed], components: [row] });
    return "";
  }
};
