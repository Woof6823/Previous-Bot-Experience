const config = require("../config");
const db = require("../database");
const loaManager = require("../handlers/loaManager");
const interviewLock = require("../handlers/interviewLock");
const settings = require("../settings");

async function ask(channel, authorId, question) {
  const prompt = await channel.send(`<@${authorId}> ${question}`);
  const filter = (m) => m.author.id === authorId;
  const collected = await channel
    .awaitMessages({ filter, max: 1, time: 60000, errors: ["time"] })
    .catch(() => null);
  prompt.delete().catch(() => {});
  if (!collected) return null;
  const answerMsg = collected.first();
  const answer = answerMsg.content.trim();
  answerMsg.delete().catch(() => {});
  return answer;
}

module.exports = {
  name: "loa",
  description: "Submits a Leave of Absence request. Run in the LOA channel.",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message) {
    if (
      message.channel.id !== settings.get("loaChannelId") &&
      message.channel.id !== config.testingChannelId
    ) {
      throw new Error(`This command only works in <#${settings.get("loaChannelId")}>.`);
    }

    interviewLock.start(message.channel.id, message.author.id);
    try {
      const name = await ask(message.channel, message.author.id, "What's your name?");
      if (name === null) return void (await message.channel.send("⏱️ Timed out."));

      const startDate = await ask(
        message.channel,
        message.author.id,
        "What date does your LOA start?"
      );
      if (startDate === null) return void (await message.channel.send("⏱️ Timed out."));

      const endDate = await ask(message.channel, message.author.id, "What date does your LOA end?");
      if (endDate === null) return void (await message.channel.send("⏱️ Timed out."));

      const reason = await ask(message.channel, message.author.id, "What's the reason?");
      if (reason === null) return void (await message.channel.send("⏱️ Timed out."));

      db.addLOA(message.author.id, name, startDate, endDate, reason);

      await loaManager.postLOAAndRefreshPanel(message.channel, {
        userId: message.author.id,
        name,
        startDate,
        endDate,
        reason
      });
    } finally {
      interviewLock.end(message.channel.id, message.author.id);
    }
  }
};
