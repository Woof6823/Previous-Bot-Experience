const { EmbedBuilder } = require("discord.js");
const securityManager = require("../handlers/securityManager");

module.exports = {
  name: "securitywhitelist",
  description:
    "Shows the 5 hardcoded owners who are the ONLY users ever exempt from any security rule. Restricted to the hardcoded trusted IDs only.",




  ownerOnly: false,
  staffOnly: false,
  silent: false,

  async execute(message) {
    if (!securityManager.isHardcodedTrustedUser(message.author.id)) {
      throw new Error("🚫 Only the hardcoded trusted users can use this command.");
    }

    const hardcoded = [...securityManager.TRUSTED_USER_IDS];
    const legacyExtra = securityManager.getExtraTrustedUsers();

    const hardcodedLines = hardcoded.length
      ? hardcoded.map((id) => `<@${id}> — \`${id}\``)
      : ["None."];

    const embed = new EmbedBuilder()
      .setColor(0x57f287)
      .setTitle("🛡️ Security Trusted Whitelist")
      .addFields({
        name: `The 5 hardcoded owners (${hardcoded.length}) — the ONLY users ever exempt from any security rule`,
        value: hardcodedLines.join("\n")
      })
      .setFooter({
        text: "These 5 bypass every anti-nuke lockdown, the protected-ping mute, and the mass @everyone/@here strip. Nothing else — not staff, not Administrator, not *securitywhitelistadd — grants any bypass, by design."
      })
      .setTimestamp();

    if (legacyExtra.length) {
      embed.addFields({
        name: `Legacy "added" list (${legacyExtra.length}) — display only, grants NO bypass`,
        value:
          legacyExtra.map((id) => `<@${id}> — \`${id}\``).join("\n") +
          "\n\n*This list predates the current policy and is no longer checked by anything. It's shown here purely for transparency.*"
      });
    }

    await message.channel.send({ embeds: [embed] });
    return "";
  }
};
