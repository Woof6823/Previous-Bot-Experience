const db = require("../database");
const ticketManager = require("../handlers/ticketManager");

module.exports = {
  name: "unclaim",
  description: "Unclaims this ticket so anyone can claim it again.",
  ownerOnly: false,
  staffOnly: true,
  silent: true,
  async execute(message) {
    const ticket = db.getTicketByChannel(message.channel.id);
    if (!ticket || ticket.status !== "open") {
      throw new Error("This command only works inside an open ticket channel.");
    }

    const unclaimed = await ticketManager.unclaimTicket(message.guild, message.channel.id);
    if (!unclaimed) {
      throw new Error("This ticket isn't currently claimed.");
    }

    return "↩️ Ticket unclaimed.";
  }
};
