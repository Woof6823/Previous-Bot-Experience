const commandPermsOverride = require("../utils/commandPermsOverride");

module.exports = {
  name: "addcommandperms",
  description:
    "Grants one user permission to use a specific command, even if it's normally owner/staff-only. Usage: *addcommandperms <command> @user",
  ownerOnly: true,
  silent: true,
  async execute(message, args, client) {
    const commandName = (args[0] || "").toLowerCase();
    const user = message.mentions.users.first();

    if (!commandName || !user) {
      throw new Error("Usage: `*addcommandperms <command> @user`");
    }

    const command = client.commands.get(commandName);
    if (!command) {
      throw new Error(`No command called \`${commandName}\` exists.`);
    }





    if (commandPermsOverride.isProtectedCommand(command.name)) {
      throw new Error(
        `🚫 \`*${command.name}\` manages command/security permissions and can never be granted through an override — ` +
        `it will only ever work for an actual owner.`
      );
    }

    const result = commandPermsOverride.addOverride(command.name, user.id);
    if (!result.ok) {
      throw new Error(`🚫 Couldn't grant \`*${command.name}\` — that command isn't eligible for an override.`);
    }

    return `✅ ${user} can now use \`*${command.name}\`, regardless of its normal permission requirement.`;
  }
};
