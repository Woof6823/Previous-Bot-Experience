const { EmbedBuilder } = require("discord.js");
const config = require("../config");





const SUMMARY_URL = "https://status.epicgames.com/api/v2/summary.json";


const STATUS_DOTS = {
  operational: "🟢",
  degraded_performance: "🟡",
  partial_outage: "🟠",
  major_outage: "🔴",
  under_maintenance: "🔵"
};

function dotFor(status) {
  return STATUS_DOTS[status] || "⚪";
}

function labelFor(status) {
  switch (status) {
    case "operational":
      return "Operational";
    case "degraded_performance":
      return "Degraded Performance";
    case "partial_outage":
      return "Partial Outage";
    case "major_outage":
      return "Major Outage";
    case "under_maintenance":
      return "Under Maintenance";
    default:
      return status
        .split("_")
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
        .join(" ");
  }
}

module.exports = {
  name: "fortnitestatus",
  description: "Shows the live status of every Fortnite component from the Epic Games status page.",
  ownerOnly: false,
  silent: false,
  keepMessage: true,
  async execute(message) {
    const loadingEmbed = new EmbedBuilder()
      .setColor(config.brandColor)
      .setTitle("🎮 Fortnite Status")
      .setDescription("Checking status... 0%");
    const sent = await message.channel.send({ embeds: [loadingEmbed] });




    let percent = 0;
    const ticker = setInterval(() => {
      percent = Math.min(percent + 25, 90);
      loadingEmbed.setDescription(`Checking status... ${percent}%`);
      sent.edit({ embeds: [loadingEmbed] }).catch(() => {});
    }, 400);

    let summary;
    try {
      const res = await fetch(SUMMARY_URL, {
        headers: { "User-Agent": "Mozilla/5.0 (compatible; SurgeBot/1.0)" }
      });
      if (!res.ok) throw new Error(`Status page responded with HTTP ${res.status}`);
      summary = await res.json();
    } catch (err) {
      clearInterval(ticker);
      const errorEmbed = new EmbedBuilder()
        .setColor(config.errorColor)
        .setTitle("🎮 Fortnite Status")
        .setDescription(`❌ Couldn't reach the Epic Games status page.\n\`${err.message}\``);
      await sent.edit({ embeds: [errorEmbed] });
      return;
    }
    clearInterval(ticker);

    const components = Array.isArray(summary.components) ? summary.components : [];
    const fortniteGroup = components.find(
      (c) => c.group === true && c.name.trim().toLowerCase() === "fortnite"
    );

    if (!fortniteGroup) {
      const errorEmbed = new EmbedBuilder()
        .setColor(config.errorColor)
        .setTitle("🎮 Fortnite Status")
        .setDescription("❌ Couldn't find a Fortnite section on the status page. It may have been renamed.");
      await sent.edit({ embeds: [errorEmbed] });
      return;
    }


    const childIds = Array.isArray(fortniteGroup.components) ? fortniteGroup.components : [];
    const children = childIds
      .map((id) => components.find((c) => c.id === id))
      .filter(Boolean);

    const lines = [`${dotFor(fortniteGroup.status)} **Fortnite (overall)** — ${labelFor(fortniteGroup.status)}`, ""];

    if (children.length === 0) {
      lines.push("_No sub-components were reported._");
    } else {
      for (const child of children) {
        lines.push(`${dotFor(child.status)} **${child.name}** — ${labelFor(child.status)}`);
      }
    }

    const worst = children.reduce((acc, c) => {
      const order = ["operational", "under_maintenance", "degraded_performance", "partial_outage", "major_outage"];
      return order.indexOf(c.status) > order.indexOf(acc) ? c.status : acc;
    }, fortniteGroup.status);

    const embedColor =
      worst === "operational"
        ? config.successColor
        : worst === "major_outage"
        ? config.errorColor
        : config.brandColor;

    const resultEmbed = new EmbedBuilder()
      .setColor(embedColor)
      .setTitle("🎮 Fortnite Status")
      .setDescription(lines.join("\n"))
      .setFooter({ text: "Source: status.epicgames.com" })
      .setTimestamp(summary.page?.updated_at ? new Date(summary.page.updated_at) : new Date());

    await sent.edit({ embeds: [resultEmbed] });
  }
};
