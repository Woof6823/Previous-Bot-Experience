const { resolveTargetId } = require("../utils/moderation");
const permissionBlockManager = require("../handlers/permissionBlockManager");

module.exports = {
  name: "permissionblock",
  description: "Permanently blocks a user from ever holding a moderation-permission role, and permanently staff-blacklists them. Owner-only.",
  ownerOnly: true,
  staffOnly: false,
  silent: false,
  async execute(message, args) {
    const targetId = resolveTargetId(args[0]);
    if (!targetId) throw new Error("Usage: `*permissionblock <userid or @user>`");

    const reason = args.slice(1).join(" ") || "No reason provided";

    await permissionBlockManager.blockUser(message.guild, targetId, reason, message.author.id);

    return (
      `🔒 <@${targetId}> has been permanently permission-blocked.\n` +
      `Any role with moderation permissions will be stripped from them instantly, forever — this survives them leaving and rejoining. ` +
      `They are also now permanently staff-blacklisted.\n` +
      `This can only be undone with \`*permissionunblock\`.`
    );
  }
};
