const { PermissionsBitField } = require("discord.js");
const db = require("../database");
const rosterConfig = require("../data/rosterConfig");
const socialAccounts = require("../utils/socialAccounts");

module.exports = {
    name: "setuppros",
    description: "Interactively sets up social links for all Pro Roster members. Administrator only.",
    ownerOnly: false,
    staffOnly: false,
    silent: false,
    async execute(message) {
        if (!message.member || !message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.channel.send("🚫 You need full Administrator permissions to use this command.");
        }

        const prosRoleId = rosterConfig.prosRoleId;
        if (!prosRoleId) {
            return message.channel.send("⚠️ Pro role ID is not configured in `rosterConfig.js`.");
        }

        const proRole = await message.guild.roles.fetch(prosRoleId).catch(() => null);
        if (!proRole) {
            return message.channel.send("⚠️ Could not find the Pro role in this server.");
        }


        await message.guild.members.fetch().catch(() => {});
        const pros = proRole.members.sort((a, b) => a.displayName.localeCompare(b.displayName));

        if (pros.size === 0) {
            return message.channel.send("⚠️ No members currently have the Pro role.");
        }

        message.delete().catch(() => {});

        const initialMsg = await message.channel.send(
            `🚀 **Pro Roster Socials Setup**\n` +
            `Found **${pros.size}** pro(s). I will ask for each one's socials sequentially.\n` +
            `Type \`cancel\` at any time to stop, or \`skip\` to leave a player's socials unchanged.`
        );

        const filter = (m) => m.author.id === message.author.id;
        let processed = 0;
        let updated = 0;
        let skipped = 0;
        let cancelled = false;

        for (const [userId, member] of pros) {
            const existing = db.getSocialAccounts(userId);
            const template = socialAccounts.buildTemplate(existing);

            const prompt = await message.channel.send(
                `**${processed + 1}/${pros.size} - ${member.displayName}** (<@${userId}>)\n` +
                `Current socials:\n\`\`\`\n${template}\n\`\`\`\n` +
                `Reply with the updated links (e.g., \`YouTube: https://...\`).\n` +
                `To clear a link, type the platform with no URL (e.g., \`YouTube: \`).\n` +
                `Type \`skip\` to keep current, or \`cancel\` to stop.`
            );

            try {
                const collected = await message.channel.awaitMessages({
                    filter,
                    max: 1,
                    time: 5 * 60 * 1000,
                    errors: ["time"]
                });

                const reply = collected.first();
                const content = reply.content.trim();


                prompt.delete().catch(() => {});
                reply.delete().catch(() => {});

                if (content.toLowerCase() === "cancel") {
                    cancelled = true;
                    break;
                }

                if (content.toLowerCase() === "skip") {
                    skipped++;
                    processed++;
                    continue;
                }

                const parsed = socialAccounts.parseSubmission(content);
                if (Object.keys(parsed).length === 0) {
                    const warn = await message.channel.send(`⚠️ Couldn't read any accounts from that message for **${member.displayName}**. Skipping.`);
                    setTimeout(() => warn.delete().catch(() => {}), 4000);
                    skipped++;
                    processed++;
                    continue;
                }


                const pending = { ...existing, ...parsed };
                const { valid, errors, cleaned } = socialAccounts.validate(pending);

                if (!valid) {
                    const errorLines = errors.map((e) => `• **${e.label}**: ${e.reason}`).join("\n");
                    const warn = await message.channel.send(
                        `⚠️ Invalid links for **${member.displayName}**:\n${errorLines}\nSkipping this player.`
                    );
                    setTimeout(() => warn.delete().catch(() => {}), 6000);
                    skipped++;
                    processed++;
                    continue;
                }

                db.upsertSocialAccounts(userId, cleaned, message.author.id);
                updated++;
                processed++;

            } catch (err) {
                prompt.delete().catch(() => {});
                const timeoutMsg = await message.channel.send(`⏱️ Timed out waiting for response for **${member.displayName}**. Cancelling setup.`);
                setTimeout(() => timeoutMsg.delete().catch(() => {}), 5000);
                cancelled = true;
                break;
            }
        }


        initialMsg.delete().catch(() => {});

        let summary = `✅ **Pro Roster Socials Setup Complete**\n`;
        summary += `• Processed: **${processed}**/${pros.size}\n`;
        summary += `• Updated: **${updated}**\n`;
        summary += `• Skipped: **${skipped}**\n`;
        if (cancelled) summary += `• Status: **Cancelled by user or timeout**\n`;
        else summary += `• Status: **Finished**\n`;

        const doneMsg = await message.channel.send(summary);
        setTimeout(() => doneMsg.delete().catch(() => {}), 15000);
    }
};
