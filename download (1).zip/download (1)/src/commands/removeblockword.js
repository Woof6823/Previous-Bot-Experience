const db = require("../database");

module.exports = {
  name: "removeblockword",
  description: "Removes a word from the blocked words list. Usage: *removeblockword <word>",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const word = args.join(" ").trim();
    if (!word) {
      throw new Error("Usage: `*removeblockword <word>`");
    }
    const removed = db.removeBlockedWord(word);
    if (!removed) {
      throw new Error(`**${word}** wasn't in the blocked words list.`);
    }
    return `✅ Removed **${word}** from the blocked words list.`;
  }
};
