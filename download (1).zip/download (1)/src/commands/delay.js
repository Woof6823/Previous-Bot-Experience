const db = require("../database");
const ticketManager = require("../handlers/ticketManager");

module.exports = {
name: "delay",
description: "Marks this ticket as delayed (⏸️) with an expected wait. Usage: *delay <reason>",
ownerOnly: false,
staffOnly: true,
silent: true,
async execute(message, args) {
const ticket = db.getTicketByChannel(message.channel.id);
if (!ticket || ticket.status !== "open") {
throw new Error("This command only works inside an open ticket channel.");
}
const reason = args.join(" ").trim();
if (!reason) {
throw new Error('Usage: `*delay <reason, e.g. "waiting on Epic name change, 2-3 days">`');
}
db.setTicketDelayed(message.channel.id, true, reason);
const updated = db.getTicketByChannel(message.channel.id);
ticketManager.queueChannelRename(message.channel, message.channel.id);
await ticketManager.refreshTicketMessage(message.guild, updated);
return `⏸️ Ticket marked as delayed: ${reason}`;
}
};
