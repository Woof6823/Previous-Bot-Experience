const db = require("../database");
const xpManager = require("../handlers/xpManager");

module.exports = {
  name: "testlevelup",
  description: "Manually fires a level-up announcement for you, to test the channel setup.",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    const row = db.getLevelRow(message.author.id);
    const level = xpManager.levelFromXp(row.xp);
    await xpManager.announceLevelUp(message.guild, message.author.id, level || 1);
    return "✅ Test level-up announcement sent (check both level-up channels).";
  }
};
