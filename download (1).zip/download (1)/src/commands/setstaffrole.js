const settings = require("../settings");

module.exports = {
  name: "setstaffrole",
  description: "Sets the role allowed to claim/close tickets. Usage: *setstaffrole @role",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    const role = message.mentions.roles.first();
    if (!role) {
      throw new Error("Usage: `*setstaffrole @role`");
    }

    settings.set("staffRoleId", role.id);

    return `✅ Staff role set to ${role}. Members with this role can now claim tickets and start timers.`;
  }
};
