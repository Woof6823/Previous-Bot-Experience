const supporterSweep = require("../handlers/supporterSweep");

const SUPPORTER_ROLE_ID = "1534318801053814825";
const THANK_YOU_TEXT =
  "Thanks for using our code! I have given you the Surge Supporter role for helping us out";

module.exports = {
  name: "supporterrole",
  description:
    "Gives the thread creator the Surge Supporter role and replies with the thank-you message (no pings). Usage: *supporterrole (run inside the thread)",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    const channel = message.channel;
    if (!channel.isThread()) {
      throw new Error("This command only works inside a creator-code thread.");
    }


    let creatorId = channel.ownerId || null;
    const starter = await channel.fetchStarterMessage().catch(() => null);
    if (!creatorId && starter) creatorId = starter.author.id;
    if (!creatorId) {
      throw new Error("Couldn't work out who created this thread.");
    }

    const member = await message.guild.members.fetch(creatorId).catch(() => null);
    if (!member) {
      throw new Error(
        `The thread creator doesn't seem to be in the server anymore — no role given.`
      );
    }


    const alreadyHad = member.roles.cache.has(SUPPORTER_ROLE_ID);
    if (!alreadyHad) {
      await member.roles.add(SUPPORTER_ROLE_ID, "Creator-code supporter (via *supporterrole)");
    }


    await supporterSweep.clearPendingPing(channel.id).catch(() => {});




    const payload = {
      content: THANK_YOU_TEXT,
      allowedMentions: { repliedUser: false, users: [], roles: [] }
    };
    if (starter) {
      await starter.reply(payload).catch(() => channel.send(payload));
    } else {
      await channel.send(payload);
    }



    return alreadyHad
      ? `${member.displayName} already had the Supporter role — thank-you reply posted anyway.`
      : `✅ Gave the Supporter role to ${member.displayName} and posted the thank-you reply (no pings).`;
  }
};
