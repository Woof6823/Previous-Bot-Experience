const tempVoiceManager = require("../handlers/tempVoiceManager");

module.exports = {
  name: "setupvc",
  description: "Creates the Join-to-Create voice channel system.",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    await tempVoiceManager.ensureJoinToCreate(message.guild);
    return "✅ Join-to-Create voice channel is set up.";
  }
};
