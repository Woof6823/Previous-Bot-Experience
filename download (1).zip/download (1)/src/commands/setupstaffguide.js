const settings = require("../settings");
const { buildGuideEmbeds } = require("../handlers/commandsGuideBuilder");

module.exports = {
  name: "setupstaffguide",
  description:
    "Posts a full reference of every staff-usable command to the staff commands guide channel.",
  ownerOnly: true,
  silent: true,
  async execute(message, args, client) {
    const channel = message.guild.channels.cache.get(settings.get("staffCommandsGuideChannelId"));
    if (!channel)
      throw new Error("Staff commands guide channel is not configured. Run *setupbot first.");

    for (const embed of buildGuideEmbeds(client)) {
      await channel.send({ embeds: [embed] });
    }

    return "✅ Staff commands guide posted.";
  }
};
