const { EmbedBuilder } = require("discord.js");
const config = require("../config");
const db = require("../database");

const TICKET_GUIDE_CHANNEL_ID = "1527588748597002270";
const SERVER_COMMANDS_CHANNEL_ID = "1533036492430114886";
const PROMOTIONS_CHANNEL_ID = "1539918129826762782";
const NEED_HELP_CHANNEL_ID = "1491249824824033422";

module.exports = {
  name: "staffaccept",
  description: "Post the staff-welcome message and ping the applicant. Staff-only, staff tickets only.",
  staffOnly: true,
  ownerOnly: false,
  silent: false,
  async execute(message) {
    const ticket = db.getTicketByChannel(message.channel.id);
    if (!ticket || ticket.type !== "staff") {
      throw new Error("🚫 This command can only be used inside a staff application ticket.");
    }

    const embed = new EmbedBuilder()
      .setColor(config.brandColor)
      .setDescription(
        "🎉 **Welcome to the Staff Team!**\n\n" +
          "Congratulations on being accepted onto the team! We're happy to have you with us. Before getting started, please make sure you read through the following channels and rules so you understand how everything works:\n\n" +
          "🟨 **Ticket Guide**\n" +
          `<#${TICKET_GUIDE_CHANNEL_ID}> — This channel explains how to correctly handle and complete tickets.\n\n` +
          "⚠️ **Ticket Rules**\n" +
          "• When a ticket opens, you **must claim it** for it to count as your ticket.\n" +
          "• You **must not type or take over another staff member's ticket unless they have been inactive for more than 30 minutes**.\n" +
          "• If another staff member has already claimed a ticket, leave it to them unless the 30-minute inactivity rule applies.\n" +
          "• Make sure you properly claim tickets so your work can be counted towards your staff activity.\n\n" +
          "💻 **Server Commands**\n" +
          `<#${SERVER_COMMANDS_CHANNEL_ID}> — This channel contains all of the commands available to staff in the server.\n\n` +
          "✅ **Promotions**\n" +
          `<#${PROMOTIONS_CHANNEL_ID}> — This channel explains what is required to earn a promotion within the staff team.\n\n` +
          "❓ **Need Help?**\n" +
          `If you have any questions or are unsure about something, feel free to ask a staff member in <#${NEED_HELP_CHANNEL_ID}>. Don't be afraid to ask — it's always better to ask than to guess!\n\n` +
          "Once again, welcome to the team, and good luck! 💙"
      );

    await message.channel.send({
      content: `<@${ticket.user_id}>`,
      embeds: [embed],
      allowedMentions: { parse: ["users"] }
    });

    return "";
  }
};
