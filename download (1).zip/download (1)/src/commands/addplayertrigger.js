const db = require("../database");

module.exports = {
  name: "addplayertrigger",
  description:
    "Adds one or more trigger words for 'looking for players' redirects. Usage: *addplayertrigger <word>, <word>, <word>",
  ownerOnly: true,
  silent: true,

  async execute(message, args) {
    const input = args.join(" ").trim();

    if (!input) {
      throw new Error("Usage: *addplayertrigger <word>, <word>, <word>");
    }

    const words = input
      .split(",")
      .map((word) => word.trim())
      .filter(Boolean);

    const added = [];
    const skipped = [];

    for (const word of words) {
      const existingTriggers = db.getTriggerWords("lfp");

      const alreadyExists = existingTriggers.some(
        (triggerWord) => String(triggerWord).toLowerCase() === word.toLowerCase()
      );

      if (alreadyExists) {
        skipped.push(word);
        continue;
      }

      db.addTriggerWord("lfp", word);
      added.push(word);
    }

    const response = [];

    if (added.length) {
      response.push(`✅ Added **${added.join("**, **")}** as "looking for players" triggers.`);
    }

    if (skipped.length) {
      response.push(`⏭️ Already triggers, skipped: **${skipped.join("**, **")}**`);
    }

    return response.join("\n");
  }
};
