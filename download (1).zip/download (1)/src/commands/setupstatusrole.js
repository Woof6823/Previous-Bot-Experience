const settings = require("../settings");
const statusRoleManager = require("../handlers/statusRoleManager");

module.exports = {
  name: "setupstatusrole",
  description:
    "Sets this channel as the status-role (Supporter) channel and posts the instructions panel.",
  ownerOnly: true,
  silent: true,
  async execute(message) {
    settings.set("statusRoleChannelId", message.channel.id);
    await statusRoleManager.postInitialPanel(message.channel);
    return "✅ Status-role channel set to this channel and the panel has been posted.";
  }
};
