const db = require("../database");
const ticketManager = require("../handlers/ticketManager");
const guessGameManager = require("../handlers/guessGameManager");

module.exports = {
  name: "close",
  description:
    "Closes the current ticket (or guess-the-number winner ticket). Usage: *close <reason>",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message, args) {
    const guessGame = db.getGuessGameByTicketChannel(message.channel.id);
    if (guessGame) {
      await guessGameManager.closeGuessTicket(message.channel);
      return;
    }

    const ticket = db.getTicketByChannel(message.channel.id);
    if (!ticket || ticket.status !== "open") {
      throw new Error("This command only works inside an open ticket channel.");
    }

    const reason = args.join(" ").trim();
    if (!reason) {
      throw new Error("Usage: `*close <reason>` — a reason is required.");
    }

    await ticketManager.closeTicket(message.guild, message.channel.id, reason, message.author.id);
  }
};
