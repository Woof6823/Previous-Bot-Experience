const db = require("../database");

module.exports = {
  name: "addteamtrigger",
  description:
    "Adds a trigger word for 'joining the team' redirects. Usage: *addteamtrigger <word>",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const word = args.join(" ").trim();
    if (!word) throw new Error("Usage: `*addteamtrigger <word>`");
    db.addTriggerWord("join", word);
    return `✅ Added **${word}** as a "joining the team" trigger.`;
  }
};
