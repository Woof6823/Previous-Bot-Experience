const db = require("../database");

module.exports = {
  name: "addautoreply",
  description: "Interactively adds an auto-reply trigger word and response.",
  ownerOnly: true,
  silent: false,
  async execute(message) {
    const prompt = await message.channel.send(
      `${message.author}, what's the **trigger word**? (type \`cancel\` to stop)`
    );

    const filter = (m) => m.author.id === message.author.id;

    const triggerCollected = await message.channel
      .awaitMessages({ filter, max: 1, time: 60000, errors: ["time"] })
      .catch(() => null);

    if (!triggerCollected) {
      await prompt.edit("⏱️ Timed out waiting for a trigger word.");
      return;
    }

    const triggerMsg = triggerCollected.first();
    const trigger = triggerMsg.content.trim();
    triggerMsg.delete().catch(() => {});

    if (trigger.toLowerCase() === "cancel") {
      await prompt.edit("❌ Cancelled.");
      return;
    }

    await prompt.edit(`Got it — trigger is \`${trigger}\`. Now what should the **response** be?`);

    const responseCollected = await message.channel
      .awaitMessages({ filter, max: 1, time: 60000, errors: ["time"] })
      .catch(() => null);

    if (!responseCollected) {
      await prompt.edit("⏱️ Timed out waiting for a response.");
      return;
    }

    const responseMsg = responseCollected.first();
    const response = responseMsg.content.trim();
    responseMsg.delete().catch(() => {});

    if (response.toLowerCase() === "cancel") {
      await prompt.edit("❌ Cancelled.");
      return;
    }

    db.addAutoReply(trigger, response);
    await prompt.edit(
      `✅ When someone says \`${trigger}\`, I'll now reply: "${response}"\n(If another trigger already uses that exact response, they're now grouped together.)`
    );
  }
};
