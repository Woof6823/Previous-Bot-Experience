const { hasStaffAccess } = require("../utils/staffAccess");




function trackerLinkFor(username) {
  return `https://fortnitetracker.com/profile/search?q=${encodeURIComponent(username)}`;
}

module.exports = {
  name: "searchtracker",
  description: "Sends a Fortnite Tracker search link for a username. Staff-access only.",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message, args) {
    if (!hasStaffAccess(message.member)) {
      throw new Error("🚫 You don't have permission to use this.");
    }

    const username = args.join(" ").trim();
    if (!username) {
      throw new Error("Usage: `*searchtracker <fortnite username>`");
    }

    await message.channel
      .send(`🔗 Tracker link for **${username}**: <${trackerLinkFor(username)}>`)
      .catch(() => {});
  }
};
