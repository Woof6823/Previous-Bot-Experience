const { resolveTargetId } = require("../utils/moderation");
const permissionBlockManager = require("../handlers/permissionBlockManager");

module.exports = {
  name: "permissionunblock",
  description: "Reverses *permissionblock. Owner-only.",
  ownerOnly: true,
  staffOnly: false,
  silent: false,
  async execute(message, args) {
    const targetId = resolveTargetId(args[0]);
    if (!targetId) throw new Error("Usage: `*permissionunblock <userid or @user>`");

    const wasBlocked = await permissionBlockManager.unblockUser(message.guild, targetId);
    if (!wasBlocked) {
      throw new Error("That user isn't permission-blocked.");
    }

    return `🔓 <@${targetId}> has been permission-unblocked and their permanent staff blacklist has been lifted.`;
  }
};
