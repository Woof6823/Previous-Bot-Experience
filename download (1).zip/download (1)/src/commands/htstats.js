const db = require("../database");
const { hasStaffAccess } = require("../utils/staffAccess");
const { sendFileWithProgress } = require("../handlers/fileShareManager");

module.exports = {
  name: "htstats",
  description:
    "Sends the 'How To Make Your Game Stats Public' video. Staff-access only, tickets only.",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message) {
    if (!hasStaffAccess(message.member)) {
      throw new Error("🚫 You don't have permission to use this.");
    }
    const ticket = db.getTicketByChannel(message.channel.id);
    if (!ticket || ticket.status !== "open") {
      throw new Error("This command only works inside an open ticket channel.");
    }

    await sendFileWithProgress(
      message.channel,
      "how-to-gamestats.mp4",
      "This is **How To Make Your Game Stats Public**"
    );
  }
};
