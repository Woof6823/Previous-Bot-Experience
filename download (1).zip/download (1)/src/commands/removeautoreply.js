const db = require("../database");

module.exports = {
  name: "removeautoreply",
  description: "Interactively removes an auto-reply trigger word.",
  ownerOnly: true,
  silent: false,
  async execute(message) {
    const all = db.getAllAutoReplies();
    if (all.length === 0) {
      await message.channel.send("There are no auto-replies set up yet.");
      return;
    }

    const list = all.map((r) => `\`${r.trigger_word}\` → "${r.response}"`).join("\n");
    const prompt = await message.channel.send(
      `${message.author}, current auto-replies:\n${list}\n\nWhich **trigger word** do you want to remove? (type \`cancel\` to stop)`
    );

    const filter = (m) => m.author.id === message.author.id;
    const collected = await message.channel
      .awaitMessages({ filter, max: 1, time: 60000, errors: ["time"] })
      .catch(() => null);

    if (!collected) {
      await prompt.edit("⏱️ Timed out.");
      return;
    }

    const responseMsg = collected.first();
    const trigger = responseMsg.content.trim();
    responseMsg.delete().catch(() => {});

    if (trigger.toLowerCase() === "cancel") {
      await prompt.edit("❌ Cancelled.");
      return;
    }

    const removed = db.removeAutoReplyTrigger(trigger);
    await prompt.edit(
      removed
        ? `✅ Removed trigger \`${trigger}\`.`
        : `❌ Couldn't find a trigger called \`${trigger}\`.`
    );
  }
};
