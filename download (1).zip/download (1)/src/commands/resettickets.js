const db = require("../database");

module.exports = {
  name: "resettickets",
  description:
    "Force-closes all open tickets for a user so they can open a new one. Usage: *resettickets <userid or @user>",
  ownerOnly: true,
  silent: true,
  async execute(message, args, client) {
    const rawArg = args[0];
    if (!rawArg) {
      throw new Error("Usage: `*resettickets <userid or @user>`");
    }

    const targetId = rawArg.replace(/[<@!>]/g, "");
    if (!/^\d{15,25}$/.test(targetId)) {
      throw new Error("That doesn't look like a valid user ID.");
    }

    const allOpen = db.getAllOpenTickets();
    const userTickets = allOpen.filter((t) => t.user_id === targetId);

    if (userTickets.length === 0) {
      return `<@${targetId}> has no open tickets to reset.`;
    }

    let closedCount = 0;
    const deletedChannels = [];

    for (const ticket of userTickets) {
      db.closeTicket(ticket.channel_id);
      db.clearTimer(ticket.channel_id);

      try {
        const channel = await client.channels.fetch(ticket.channel_id);
        if (channel) {
          await channel
            .send("🔒 This ticket has been force-closed by the bot owner (ticket reset).")
            .catch(() => {});
          await channel.delete("Ticket reset by owner via *resettickets").catch(() => {});
          deletedChannels.push(`#${channel.name}`);
        }
      } catch {


      }

      closedCount++;
    }

    return (
      `✅ Force-closed **${closedCount}** open ticket(s) for <@${targetId}>.` +
      (deletedChannels.length > 0
        ? `\nDeleted channels: ${deletedChannels.join(", ")}`
        : "\n*(No channels needed deleting — they were already gone.)*") +
      `\nThey can now open a new ticket.`
    );
  }
};
