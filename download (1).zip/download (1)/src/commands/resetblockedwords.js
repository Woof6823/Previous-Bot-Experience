const db = require("../database");

module.exports = {
  name: "resetblockedwords",
  description: "Removes every word from the blocked words list.",
  ownerOnly: true,
  silent: true,
  async execute() {
    const count = db.clearAllBlockedWords();
    return `✅ Cleared ${count} blocked word(s).`;
  }
};
