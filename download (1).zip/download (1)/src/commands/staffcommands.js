const {
  buildOverviewEmbed,
  buildCategorySelectRow,
  ALL_STAFF_CATEGORIES
} = require("../handlers/commandsGuideBuilder");
const { hasStaffAccess } = require("../utils/staffAccess");

module.exports = {
  name: "staffcommands",
  description:
    "Posts the staff commands guide (dropdown) in this channel — shows only commands every staff member can use.",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message) {
    if (!hasStaffAccess(message.member)) {
      throw new Error("🚫 You don't have permission to use this.");
    }

    await message.channel.send({
      embeds: [buildOverviewEmbed(ALL_STAFF_CATEGORIES)],
      components: [buildCategorySelectRow(ALL_STAFF_CATEGORIES)]
    });
  }
};
