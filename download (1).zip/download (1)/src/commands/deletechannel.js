const pendingDeletes = new Set();

module.exports = {
  name: "deletechannel",
  description: "Deletes the current channel after a 5 second warning. Owner only.",
  ownerOnly: true,
  async execute(message) {
    const channel = message.channel;

    if (pendingDeletes.has(channel.id)) {
      throw new Error("This channel is already scheduled for deletion.");
    }
    pendingDeletes.add(channel.id);

    await channel.send("⚠️ Deleting this channel in 5 seconds...").catch(() => {});

    setTimeout(async () => {
      pendingDeletes.delete(channel.id);
      if (!channel || !channel.deletable) return;
      await channel
        .delete(`Channel deletion requested by <@${message.author.id}> via *deletechannel`)
        .catch((err) => {
          console.error(`[deletechannel] Failed to delete channel ${channel.id}:`, err.message);
        });
    }, 5000);
  }
};
