const { resolveTargetId } = require("../utils/moderation");

module.exports = {
  name: "removerole",
  description: "Removes a role from a user. Usage: *removerole <userid or @user> <roleid or @role>",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const targetId = resolveTargetId(args[0]);
    const roleId = args[1] ? args[1].replace(/[<@&>]/g, "") : null;
    if (!targetId || !roleId) {
      throw new Error("Usage: `*removerole <userid or @user> <roleid or @role>`");
    }

    const member = await message.guild.members.fetch(targetId).catch(() => null);
    if (!member) throw new Error("Couldn't find that member in this server.");

    const role = await message.guild.roles.fetch(roleId).catch(() => null);
    if (!role) throw new Error("Couldn't find that role in this server.");

    if (!member.roles.cache.has(role.id)) {
      throw new Error(`<@${targetId}> doesn't have that role.`);
    }

    try {
      await member.roles.remove(role);
    } catch {
      throw new Error("I couldn't remove that role — check the bot's role is above it.");
    }

    return `✅ Removed <@&${role.id}> from <@${targetId}>.`;
  }
};
