const {
  ActionRowBuilder,
  RoleSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require("discord.js");
const db = require("../database");
const config = require("../config");
const staffUpdateManager = require("../handlers/staffUpdateManager");
const staffRecords = require("../handlers/staffRecords");
const interviewLock = require("../handlers/interviewLock");

async function askText(channel, authorId, question) {
  const prompt = await channel.send(`<@${authorId}> ${question}`);
  const filter = (m) => m.author.id === authorId;
  const collected = await channel
    .awaitMessages({ filter, max: 1, time: 60000, errors: ["time"] })
    .catch(() => null);
  prompt.delete().catch(() => {});
  if (!collected) return null;
  const msg = collected.first();
  const answer = msg.content.trim();
  msg.delete().catch(() => {});
  return answer;
}

async function askRole(channel, authorId, customId, question) {
  const row = new ActionRowBuilder().addComponents(
    new RoleSelectMenuBuilder()
      .setCustomId(customId)
      .setPlaceholder(question)
      .setMinValues(1)
      .setMaxValues(1)
  );
  const prompt = await channel.send({ content: `<@${authorId}> ${question}`, components: [row] });
  const collected = await channel
    .awaitMessageComponent({
      filter: (i) => i.user.id === authorId && i.customId === customId,
      time: 60000
    })
    .catch(() => null);
  if (!collected) {
    prompt.delete().catch(() => {});
    return null;
  }
  await collected.deferUpdate();
  prompt.delete().catch(() => {});
  return collected.values[0];
}

async function askKind(channel, authorId) {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("staffupdate_promo")
      .setLabel("Promotion")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId("staffupdate_demo")
      .setLabel("Demotion")
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId("staffupdate_hire")
      .setLabel("New Hire")
      .setStyle(ButtonStyle.Primary)
  );
  const prompt = await channel.send({
    content: `<@${authorId}> is this a promotion, a demotion, or a new hire?`,
    components: [row]
  });
  const collected = await channel
    .awaitMessageComponent({
      filter: (i) =>
        i.user.id === authorId &&
        ["staffupdate_promo", "staffupdate_demo", "staffupdate_hire"].includes(i.customId),
      time: 60000
    })
    .catch(() => null);
  if (!collected) {
    prompt.delete().catch(() => {});
    return null;
  }
  await collected.deferUpdate();
  prompt.delete().catch(() => {});
  if (collected.customId === "staffupdate_promo") return "promo";
  if (collected.customId === "staffupdate_demo") return "demo";
  return "hire";
}

module.exports = {
  name: "staffupdate",
  description:
    "Interactively logs a hire/promotion/demotion, swaps the role, and saves it to staff history.",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message) {
    const staffUpdateChannelId = db.getSetting("staffupdate_channel_id");
    if (
      staffUpdateChannelId &&
      message.channel.id !== staffUpdateChannelId &&
      message.channel.id !== config.testingChannelId
    ) {
      throw new Error(`This command only works in <#${staffUpdateChannelId}>.`);
    }
    const channel = message.channel;
    const authorId = message.author.id;
    interviewLock.start(channel.id, authorId);
    try {
      const userId = await askText(
        channel,
        authorId,
        "What's the User ID of the person whose role is changing?"
      );
      if (!userId) return void (await channel.send("⏱️ Timed out."));
      if (!/^\d{17,19}$/.test(userId)) {
        return void (await channel.send("❌ That doesn't look like a valid User ID."));
      }

      const kind = await askKind(channel, authorId);
      if (!kind) return void (await channel.send("⏱️ Timed out."));

      let oldRoleId = null;
      if (kind !== "hire") {
        oldRoleId = await askRole(
          channel,
          authorId,
          "staffupdate_oldrole",
          "Select their CURRENT role"
        );
        if (!oldRoleId) return void (await channel.send("⏱️ Timed out."));
      }

      const newRoleId = await askRole(
        channel,
        authorId,
        "staffupdate_newrole",
        kind === "hire" ? "Select the role they were GIVEN" : "Select their NEW role"
      );
      if (!newRoleId) return void (await channel.send("⏱️ Timed out."));

      const targetMember = await message.guild.members.fetch(userId).catch(() => null);
      if (!targetMember) {
        await channel.send(`❌ Couldn't find user ${userId} in this server — no changes made.`);
        return;
      }





      staffRecords.addStaffHistory({ userId, kind, oldRoleId, newRoleId, approvedBy: authorId });

      const titles = { promo: "⬆️ Promotion", demo: "⬇️ Demotion", hire: "🆕 New Hire" };
      const roleLine =
        kind === "hire" ? `Given <@&${newRoleId}>` : `<@&${oldRoleId}> -> <@&${newRoleId}>`;
      await channel.send({
        embeds: [
          new EmbedBuilder()
            .setColor(config.brandColor)
            .setTitle(titles[kind])
            .addFields(
              { name: "User", value: `<@${userId}>`, inline: true },
              { name: "Role", value: roleLine, inline: true },
              { name: "Approved by", value: `<@${authorId}>`, inline: true },
              { name: "Date", value: `<t:${Math.floor(Date.now() / 1000)}:F>` },
              { name: "⚠️ Note", value: "Roles are not auto-applied — please update them manually." }
            )
            .setTimestamp()
        ]
      });
      await staffUpdateManager.refreshPanel(channel);
    } finally {
      interviewLock.end(channel.id, authorId);
    }
  }
};
