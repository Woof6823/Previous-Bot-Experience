const { resolveTargetId } = require("../utils/moderation");
const wordWhitelistManager = require("../handlers/wordWhitelistManager");

module.exports = {
  name: "whitelist",
  description:
    "Exempts a user from the blocked-words/blocked-links filter permanently. Usage: *whitelist <userid or @user>",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      throw new Error("Usage: `*whitelist <userid or @user>`");
    }
    wordWhitelistManager.addWhitelist(targetId, message.author.id);
    return (
      `✅ <@${targetId}> is now whitelisted — blocked words and links will never be ` +
      `actioned against them until removed with \`*unwhitelist\`.`
    );
  }
};
