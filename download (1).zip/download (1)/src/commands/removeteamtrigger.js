const db = require("../database");

module.exports = {
  name: "removeteamtrigger",
  description: "Removes a 'joining the team' trigger word. Usage: *removeteamtrigger <word>",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const word = args.join(" ").trim();
    if (!word) throw new Error("Usage: `*removeteamtrigger <word>`");
    const removed = db.removeTriggerWord("join", word);
    if (!removed) throw new Error(`**${word}** wasn't a trigger word.`);
    return `✅ Removed **${word}**.`;
  }
};
