const db = require("../database");
const config = require("../config");
const { resolveTargetId } = require("../utils/moderation");
const blacklistManager = require("../handlers/blacklistManager");
const settings = require("../settings");

module.exports = {
  name: "staffblacklist",
  description: "Blocks a user from opening Staff tickets. Usage: *staffblacklist <userid> <reason>",
  ownerOnly: false,
  staffOnly: true,
  silent: false,
  async execute(message, args) {
    const blacklistChannelId = settings.get("blacklistChannelId");
    if (
      blacklistChannelId &&
      message.channel.id !== blacklistChannelId &&
      message.channel.id !== config.testingChannelId
    ) {
      throw new Error(`This command only works in <#${blacklistChannelId}>.`);
    }

    const targetId = resolveTargetId(args[0]);
    const reason = args.slice(1).join(" ") || "No reason provided";
    if (!targetId) throw new Error("Usage: `*staffblacklist <userid> <reason>`");

    const targetMember = await message.guild.members.fetch(targetId).catch(() => null);
    const staffBlacklistRoleId = settings.get("staffBlacklistRoleId");
    if (targetMember && staffBlacklistRoleId) {
      await targetMember.roles.add(staffBlacklistRoleId).catch(() => {});
    }

    db.addBlacklist(targetId, "staff", reason, message.author.id);

    await blacklistManager.postConfirmationAndRefreshPanel(
      message.channel,
      {
        title: "Staff Blacklist Approved",
        userId: targetId,
        requestedBy: message.author.id,
        reason,
        approvedBy: message.author.id
      },
      "staff"
    );

    return `✅ <@${targetId}> has been blacklisted from Staff tickets.`;
  }
};
