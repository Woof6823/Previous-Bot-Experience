const ltlManager = require("../handlers/ltlManager");
module.exports = {
  name: "ltlcancel",
  description: "Cancels the current scheduled or active LTL event.",
  ownerOnly: true,
  silent: true,
  async execute(message, args, client) {
    const cancelled = await ltlManager.cancelEvent(client, message.guild.id);
    if (!cancelled) {
      throw new Error("There's no scheduled or active LTL event right now.");
    }
    return "✅ LTL event cancelled.";
  }
};
