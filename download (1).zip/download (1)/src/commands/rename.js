const tempVoiceManager = require("../handlers/tempVoiceManager");

module.exports = {
  name: "rename",
  description: "Renames your voice channel. Usage: *rename <new name>",
  ownerOnly: false,
  silent: true,
  async execute(message, args) {
    tempVoiceManager.requireOwnedVC(message);

    const newName = args.join(" ").trim();
    if (!newName) {
      throw new Error("Usage: `*rename <new name>`");
    }

    await message.channel.setName(newName.slice(0, 100));
    return `✅ Channel renamed to **${newName.slice(0, 100)}**.`;
  }
};
