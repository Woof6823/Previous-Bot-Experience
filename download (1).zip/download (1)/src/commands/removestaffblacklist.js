const db = require("../database");
const config = require("../config");
const { resolveTargetId } = require("../utils/moderation");
const blacklistManager = require("../handlers/blacklistManager");
const settings = require("../settings");

module.exports = {
  name: "removestaffblacklist",
  description: "Removes a staff blacklist. Usage: *removestaffblacklist <userid>",
  ownerOnly: true,
  silent: false,
  async execute(message, args) {
    if (
      message.channel.id !== settings.get("blacklistChannelId") &&
      message.channel.id !== config.testingChannelId
    ) {
      throw new Error(`This command only works in <#${settings.get("blacklistChannelId")}>.`);
    }
    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      throw new Error("Usage: `*removestaffblacklist <userid>`");
    }
    if (!db.getBlacklist(targetId, "staff")) {
      throw new Error("That user isn't on the staff blacklist.");
    }
    await blacklistManager.markRemoved(message.guild, targetId, "staff", `<@${message.author.id}>`);
    db.removeBlacklist(targetId, "staff");
    const targetMember = await message.guild.members.fetch(targetId).catch(() => null);
    if (targetMember) {
      await targetMember.roles.remove(settings.get("staffBlacklistRoleId")).catch(() => {});
    }
    await message.channel.send(`✅ <@${targetId}> has been removed from the staff blacklist.`);
    await blacklistManager.refreshPanel(message.channel);
  }
};
