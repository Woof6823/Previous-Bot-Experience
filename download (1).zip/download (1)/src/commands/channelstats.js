const { EmbedBuilder, AttachmentBuilder } = require("discord.js");
const config = require("../config");
const { STATS_CHANNEL_ID } = require("../handlers/userStatsManager");
const channelStats = require("../handlers/channelStatsManager");
const renderer = require("../handlers/channelStatsRenderer");

const MEDALS = ["🥇", "🥈", ""];
function rankLabel(r) {
  return r <= 3 ? MEDALS[r - 1] : `\`${String(r).padStart(2, "0")}\``;
}
function bar(value, max) {
  const L = 10;
  if (!max || value <= 0) return "▱".repeat(L);
  const filled = Math.min(Math.max(Math.round((value / max) * L), 1), L);
  return "▰".repeat(filled) + "▱".repeat(L - filled);
}
function fmt(n) {
  return Number(n || 0).toLocaleString("en-US");
}
async function nameOf(guild, id) {
  const m = guild.members.cache.get(id);
  if (m) return m.displayName;
  const mem = await guild.members.fetch(id).catch(() => null);
  if (mem) return mem.displayName;
  const u = await guild.client.users.fetch(id).catch(() => null);
  return u ? u.username : `User ${id}`;
}
function chanName(guild, id) {
  const ch = guild.channels.cache.get(id);
  return ch ? `#${ch.name}` : "#deleted-channel";
}

module.exports = {
  name: "channelstats",
  description:
    "Channel activity stats. Usage: *channelstats [#channel or id] — overview, or one channel's full breakdown.",
  ownerOnly: false,
  silent: false,
  keepMessage: true,
  async execute(message, args) {
    if (message.channel.id !== STATS_CHANNEL_ID && message.channel.id !== config.testingChannelId) {
      throw new Error(`Please use this in <#${STATS_CHANNEL_ID}>.`);
    }
    const guild = message.guild;
    const mentioned = message.mentions.channels.first();
    const rawId = args[0] ? args[0].replace(/[<#>]/g, "") : null;
    const target = mentioned || (rawId && guild.channels.cache.get(rawId)) || null;


    if (!target) {
      const textRows = channelStats
        .getTopTextChannels(30, 6)
        .map((r) => ({ name: chanName(guild, r.channel_id), value: r.t }));
      const voiceRows = channelStats
        .getTopVoiceChannels(30, 6)
        .map((r) => ({ name: chanName(guild, r.channel_id), value: r.s }));
      const data = {
        lookbackLabel: "Last 30 days",
        totalMessages: channelStats.getTotalMessages(30),
        activeChannels: channelStats.getActiveChannelCount(30),
        textRows,
        voiceRows
      };
      const card = await renderer.renderChannelOverviewCard(data);
      if (card) {
        await message.channel.send({
          files: [new AttachmentBuilder(card, { name: "channel-stats.png" })]
        });
        return;
      }

      const maxT = textRows.length ? textRows[0].value : 1;
      const maxV = voiceRows.length ? voiceRows[0].value : 1;
      const embed = new EmbedBuilder()
        .setColor(config.brandColor)
        .setAuthor({ name: guild.name, iconURL: guild.iconURL() || null })
        .setTitle("📊 Channel Stats — last 30 days")
        .setDescription(
          `💬 **${fmt(data.totalMessages)}** messages across **${data.activeChannels}** active channel(s)\n\u200b\n` +
            `**💬 Top Text Channels**\n` +
            (textRows
              .map(
                (r, i) =>
                  `${rankLabel(i + 1)} **${r.name}**\n\u200b    ${bar(r.value, maxT)}  ${fmt(r.value)} msgs`
              )
              .join("\n") || "No data yet.") +
            `\n\u200b\n**🔊 Top Voice Channels**\n` +
            (voiceRows
              .map(
                (r, i) =>
                  `${rankLabel(i + 1)} **${r.name}**\n\u200b    ${bar(r.value, maxV)}  ${(r.value / 3600).toFixed(1)}h in VC`
              )
              .join("\n") || "No voice data tracked.")
        )
        .setFooter({ text: "Use *channelstats #channel for a single channel's full breakdown" })
        .setTimestamp();
      await message.channel.send({ embeds: [embed] });
      return;
    }


    const all = channelStats.getChannelMessageCount(target.id, null);
    const d30 = channelStats.getChannelMessageCount(target.id, 30);
    const d7 = channelStats.getChannelMessageCount(target.id, 7);
    const d1 = channelStats.getChannelMessageCount(target.id, 1);
    const unique = channelStats.getChannelUniqueSenders(target.id, null);
    const topSendersRaw = channelStats.getTopSenders(target.id, 30, 5);
    const topSenders = [];
    for (const r of topSendersRaw)
      topSenders.push({ name: await nameOf(guild, r.user_id), value: r.t });
    const voiceAll = channelStats.getChannelVoiceSeconds(target.id, null);
    const voiceText =
      voiceAll > 0 ? `${(voiceAll / 3600).toFixed(1)}h in VC (all time)` : "no voice data tracked";
    const data = {
      channelName: target.name,
      msgRows: [
        { label: "All time", value: all },
        { label: "30d", value: d30 },
        { label: "7d", value: d7 },
        { label: "1d", value: d1 }
      ],
      unique,
      topSenders,
      voiceText
    };
    const card = await renderer.renderChannelDetailCard(data);
    if (card) {
      await message.channel.send({ files: [new AttachmentBuilder(card, { name: "channel.png" })] });
      return;
    }

    const maxS = topSenders.length ? topSenders[0].value : 1;
    const embed = new EmbedBuilder()
      .setColor(config.brandColor)
      .setAuthor({ name: guild.name, iconURL: guild.iconURL() || null })
      .setTitle(`📊 #${target.name}`)
      .setDescription(
        `**💬 Messages**\n` +
          `All time: **${fmt(all)}**  •  30d: **${fmt(d30)}**  •  7d: **${fmt(d7)}**  •  1d: **${fmt(d1)}**\n` +
          `👥 Unique senders (all time): **${fmt(unique)}**  •  🔊 ${voiceText}\n\u200b\n` +
          `**🏆 Top Senders (30d)**\n` +
          (topSenders
            .map(
              (r, i) =>
                `${rankLabel(i + 1)} **${r.name}**\n\u200b    ${bar(r.value, maxS)}  ${fmt(r.value)} msgs`
            )
            .join("\n") || "No sender data yet.")
      )
      .setFooter({ text: "Counts are uncapped and grow forever" })
      .setTimestamp();
    await message.channel.send({ embeds: [embed] });
  }
};
