const db = require("../database");

module.exports = {
  name: "addblockword",
  description:
    "Adds one or more words to the blocked words list. Usage: *addblockword <word>, <word>, <word>",
  ownerOnly: true,
  silent: true,

  async execute(message, args) {
    const input = args.join(" ").trim();

    if (!input) {
      throw new Error("Usage: *addblockword <word>, <word>, <word>");
    }

    const words = input
      .split(",")
      .map((word) => word.trim())
      .filter(Boolean);

    const added = [];
    const skipped = [];

    for (const word of words) {
      const existingWords = db.getBlockedWords();

      const alreadyBlocked = existingWords.some(
        (blockedWord) => String(blockedWord).toLowerCase() === word.toLowerCase()
      );

      if (alreadyBlocked) {
        skipped.push(word);
        continue;
      }

      db.addBlockedWord(word);
      added.push(word);
    }

    const response = [];

    if (added.length) {
      response.push(`✅ Added **${added.join("**, **")}** to the blocked words list.`);
    }

    if (skipped.length) {
      response.push(`⏭️ Already blocked, skipped: **${skipped.join("**, **")}**`);
    }

    return response.join("\n");
  }
};
