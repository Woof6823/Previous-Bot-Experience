const activityCheckManager = require("../handlers/activityCheckManager");

module.exports = {
  name: "activitycheck",
  description: "Post the weekly staff activity check. Owner-only.",
  ownerOnly: true,
  staffOnly: false,
  silent: false,
  async execute(message) {
    const embeds = await activityCheckManager.buildActivityCheckEmbeds(message.guild);
    await message.channel.send({ embeds });
    return "";
  }
};
