const db = require("../database");
const { resolveTargetId, sendModerationDM, announceModAction } = require("../utils/moderation");
const { hasModPermission } = require("../utils/modPermissions");
const logManager = require("../handlers/logManager");

module.exports = {
  name: "unwarn",
  description: "Removes a user's most recent warning. Usage: *unwarn <userid or @user>",
  ownerOnly: false,
  silent: false,
  async execute(message, args, client) {
    if (!hasModPermission(message.member, "warn")) {
      throw new Error("🚫 You don't have permission to unwarn people.");
    }
    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      throw new Error("Usage: `*unwarn <userid or @user>`");
    }

    const removed = db.removeLatestWarning(targetId);
    if (!removed) {
      throw new Error("That user has no warnings to remove.");
    }

    db.addModLog(targetId, message.author.id, "unwarn", "Most recent warning removed.");
    logManager
      .log(message.guild, {
        type: "mod",
        title: "✅ Warning Removed",
        actor: message.author,
        target: `<@${targetId}>`
      })
      .catch(() => {});
    sendModerationDM(client, targetId, {
      action: "un-warned",
      reason: "Your most recent warning was removed.",
      guildName: message.guild.name
    }).catch(() => {});

    await announceModAction(message.channel, targetId, "unwarned");
    return `✅ Removed <@${targetId}>'s most recent warning.`;
  }
};
