const db = require("../database");
const { resolveTargetId, sendModerationDM, announceModAction } = require("../utils/moderation");
const { hasModPermission } = require("../utils/modPermissions");
const logManager = require("../handlers/logManager");

module.exports = {
  name: "unmute",
  description: "Removes a user's timeout. Usage: *unmute <userid or @user>",
  ownerOnly: false,
  silent: false,
  async execute(message, args, client) {
    if (!hasModPermission(message.member, "mute")) {
      throw new Error("🚫 You don't have permission to unmute people.");
    }

    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      throw new Error("Usage: `*unmute <userid or @user>`");
    }

    const member = await message.guild.members.fetch(targetId).catch(() => null);
    if (!member) {
      throw new Error("Couldn't find that member in this server.");
    }
    if (!member.communicationDisabledUntil) {
      throw new Error("That member isn't currently muted.");
    }

    await member.timeout(null, `Unmuted by ${message.author.username}`);
    db.addModLog(targetId, message.author.id, "unmute", "Timeout removed.");
    logManager
      .log(message.guild, {
        type: "mod",
        title: "✅ Member Unmuted",
        actor: message.author,
        target: `<@${targetId}>`
      })
      .catch(() => {});

    sendModerationDM(client, targetId, {
      action: "un-muted",
      reason: "Your timeout was removed early.",
      guildName: message.guild.name
    }).catch(() => {});

    await announceModAction(message.channel, targetId, "unmuted");
    return `✅ <@${targetId}> has been unmuted.`;
  }
};
