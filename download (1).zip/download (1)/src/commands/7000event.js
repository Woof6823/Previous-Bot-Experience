const db = require("../database");

const GOAL = 7000;

function buildEventContent(guild) {
	const remaining = Math.max(0, GOAL - guild.memberCount);
	return `||@everyone||

🎉 **7,000 MEMBER GIVEAWAY!**

When we reach **7,000 members**, we'll be giving away **5,000 V-BUCKS!** 💰

🎁 **To enter:**
• Invite **5 people** to the server
• **All 5 invites must join the server**
• Your invites will be **checked once we reach 7K**

🏆 **1 winner** will be randomly selected from everyone who meets the requirements!

**Invite your friends and help us reach 7K!** ❤️

📊 Members Remaining To 7000 - **${remaining}**`;
}

module.exports = {
	name: "7000event",
	description:
		"Posts the 7,000 member giveaway event message with a live member counter.",
	ownerOnly: true,
	staffOnly: false,
	silent: false,
	async execute(message, args, client) {
		const existingId = db.getSetting("7000event_message_id");
		if (existingId) {
			const old = await message.channel.messages
				.fetch(existingId)
				.catch(() => null);
			if (old) await old.delete().catch(() => {});
		}

		const content = buildEventContent(message.guild);
		const sent = await message.channel.send({
			content,
			allowedMentions: { parse: ["everyone"] }
		});

		db.setSetting("7000event_message_id", sent.id);
		db.setSetting("7000event_channel_id", message.channel.id);
	}
};
