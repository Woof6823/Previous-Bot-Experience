const { PermissionsBitField, ChannelType } = require("discord.js");
const securityManager = require("../handlers/securityManager");

module.exports = {
  name: "setupsecuritychannel",
  description:
    "Creates a security-alerts channel (visible only to Administrators) and points every security alert there instead of DMs, pinging all owners. Owner-only.",
  ownerOnly: true,
  silent: false,
  async execute(message) {
    const guild = message.guild;

    const existingId = securityManager.getSecurityChannelId();
    if (existingId) {
      const existing =
        guild.channels.cache.get(existingId) ||
        (await guild.channels.fetch(existingId).catch(() => null));
      if (existing) {
        return `⚠️ A security channel is already configured: ${existing}. Delete it manually first if you want this command to create a new one.`;
      }


    }

    const channel = await guild.channels.create({
      name: "🛡️│security-alerts",
      type: ChannelType.GuildText,





      permissionOverwrites: [
        {
          id: guild.roles.everyone.id,
          deny: [PermissionsBitField.Flags.ViewChannel]
        },
        {
          id: message.client.user.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.EmbedLinks,
            PermissionsBitField.Flags.AttachFiles
          ]
        }
      ],
      reason: `Security alerts channel created by ${message.author.tag} via *setupsecuritychannel`
    });

    securityManager.setSecurityChannelId(channel.id);

    return (
      `✅ ${channel} created — only members with the real Discord **Administrator** permission can see it.\n` +
      `Every security alert (anti-nuke lockdowns, protected-ping mutes, raid detection, etc.) will be posted there from now on, pinging all 5 owners, ` +
      `instead of being DMed. Lockdowns that stripped roles will include a **Restore Roles** button there that only an owner can use.`
    );
  }
};
