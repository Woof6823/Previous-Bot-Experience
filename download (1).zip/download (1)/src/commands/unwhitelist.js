const { resolveTargetId } = require("../utils/moderation");
const wordWhitelistManager = require("../handlers/wordWhitelistManager");

module.exports = {
  name: "unwhitelist",
  description:
    "Removes a user from the blocked-words whitelist so the filter applies to them again. Usage: *unwhitelist <userid or @user>",
  ownerOnly: true,
  silent: true,
  async execute(message, args) {
    const targetId = resolveTargetId(args[0]);
    if (!targetId) {
      throw new Error("Usage: `*unwhitelist <userid or @user>`");
    }
    const removed = wordWhitelistManager.removeWhitelist(targetId);
    if (!removed) {
      throw new Error("That user isn't on the blocked-words whitelist.");
    }
    return `✅ <@${targetId}> has been removed from the whitelist — the blocked-words filter applies to them again immediately.`;
  }
};
