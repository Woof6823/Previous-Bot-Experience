const tempVoiceManager = require("../handlers/tempVoiceManager");

module.exports = {
  name: "limit",
  description:
    "Caps how many people can join your voice channel. Usage: *limit <number, 0 = no limit>",
  ownerOnly: false,
  silent: true,
  async execute(message, args) {
    tempVoiceManager.requireOwnedVC(message);

    const limit = parseInt(args[0], 10);
    if (Number.isNaN(limit) || limit < 0 || limit > 99) {
      throw new Error("Usage: `*limit <number between 0 and 99>` (0 = no limit)");
    }

    await message.channel.setUserLimit(limit);
    return limit === 0 ? "✅ User limit removed." : `✅ User limit set to ${limit}.`;
  }
};
