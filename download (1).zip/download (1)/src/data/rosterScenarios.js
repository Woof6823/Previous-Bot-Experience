function scenario(id, category, prompt, choices, correctChoices, explanation) {
  return { id, category, prompt, choices, correctChoices, explanation };
}

const ALL_SCENARIOS = [
  scenario(
    "grinder-complete",
    "Grinder",
    "A member opens a Roster ticket. They're 16 and say: \"I want to join as a Grinder. I've got RegionX in my item shop, changed my Epic username to SRG_Kade, my Discord name is 'SRG Kade', and I'm using the server tag.\"",
    ["accept", "deny", "ask-for-screenshot"],
    ["accept"],
    "All four Grinder requirements are proven (creator code, SRG Epic username, SRG Discord name, server tag) and they're 13+ — verify and give the @Grinder role. `*grinder` sends the requirements list."
  ),
  scenario(
    "grinder-incomplete",
    "Grinder",
    'A member opens a Roster ticket, age 15: "I want the Grinder role. I use RegionX in the shop and I have the server tag on, but I haven\'t changed my Epic username yet."',
    ["accept", "deny", "ask-for-screenshot"],
    ["deny"],
    "Grinder requires ALL FOUR steps completed before the role is given. The Epic username change is missing, so this isn't a pass yet — deny for now, send the requirements with `*grinder`, and tell them to come back once everything is done."
  ),
  scenario(
    "under13-competitive",
    "Age limit",
    "A member opens a Roster ticket. They say they're 11 years old and have 12,000 yearly PR, well above the Pro threshold, and want to join the Pro Roster.",
    ["accept-grinder", "accept-pro", "deny", "ask-more-proof"],
    ["accept-grinder", "deny", "ask-more-proof"],
    "Under 13, the highest role that can EVER be given is Grinder+ — no exceptions, no matter how high their PR is. Offering Grinder+, denying, or asking for proof are all fine. The one thing you must NEVER do is give them Pro."
  ),
  scenario(
    "future-academy-pass",
    "Competitive",
    "Member, age 17, applying for Future Academy. They send their fortnitetracker.com link, verify account ownership, and their yearly PR (single region) is 80.",
    ["accept", "deny", "ask-more-proof"],
    ["accept"],
    "Future Academy requires 50+ yearly PR — 80 clears it, and ownership was verified. Accept and complete the Future Academy requirements with them (`*futureacademy`)."
  ),
  scenario(
    "future-academy-fail",
    "Competitive",
    "Member, age 14, applying for Future Academy. Tracker link sent and ownership verified, but their yearly PR is only 30.",
    ["accept", "deny", "ask-more-proof"],
    ["deny"],
    "Future Academy needs 50+ yearly PR — 30 doesn't meet it. Deny this tier and tell them they can choose another position or try again once their PR is higher."
  ),
  scenario(
    "academy-pass",
    "Competitive",
    "Member, age 19, applying for Academy. Tracker and ownership verified, yearly PR is 310.",
    ["accept", "deny", "accept-future-academy", "ask-more-proof"],
    ["accept"],
    "Academy requires 250+ yearly PR — 310 clears it. Accept and walk them through the Academy requirements (`*academy`)."
  ),
  scenario(
    "future2-fail",
    "Competitive",
    "Member, age 16, applying for Future 2.0. Verified ownership, yearly PR is 640.",
    ["accept", "deny", "accept-academy", "deny-offer-academy"],
    ["deny", "accept-academy", "deny-offer-academy"],
    "Future 2.0 requires 1,000+ yearly PR — 640 doesn't clear it, so accepting them into Future 2.0 is the only wrong call. Deny this tier and point them at a tier they DO qualify for: Academy (250+) or Future Academy (50+)."
  ),
  scenario(
    "semipro-pass",
    "Competitive",
    "Member, age 20, applying for Semi Pro. Verified, yearly PR is 6,200.",
    ["accept", "deny", "accept-pro", "ask-more-proof"],
    ["accept"],
    "Semi Pro requires 5,000+ yearly PR — 6,200 clears it. Accept and complete the Semi-Pro requirements (`*semipro`)."
  ),
  scenario(
    "pro-pass",
    "Competitive",
    "Member, age 18, applying for Pro Roster. Verified, yearly PR is 11,500.",
    ["accept-ping", "accept", "deny", "escalate"],
    ["accept-ping", "accept"],
    "Pro requires 10,000+ yearly PR — 11,500 clears it. Both accepting and using `*pro` are acceptable — AS LONG AS @firenzfn is pinged in the ticket afterwards. Pro applications ALWAYS need a higher authority involved; never hand out Pro yourself without that."
  ),
  scenario(
    "creator-strong",
    "Content Creator",
    "Member applying for Content Creator sends their YouTube channel: posting 4-5 times a week, high production quality, 40,000 subscribers, consistent views.",
    ["creator", "juniorcreator", "deny"],
    ["creator"],
    "Strong, frequent output and a solid following supports the full Content Creator role rather than Junior — use `*creator` to send the requirements. (Junior is not an option for a channel this strong.)"
  ),
  scenario(
    "juniorcreator-fit",
    "Content Creator",
    "Member applying for Content Creator sends their channel: posts weekly, decent editing quality, around 3,000 subscribers with steady views.",
    ["creator", "juniorcreator", "deny"],
    ["juniorcreator"],
    "Weekly posting with a few thousand subscribers sits below the full Creator bar but above the Junior minimum — offer Junior Content Creator (`*juniorcreator`). Not a deny, since the channel shows real, regular content."
  ),
  scenario(
    "juniorcreator-small",
    "Content Creator",
    "Member applying for Content Creator sends a channel: posts roughly once a month, decent editing, but only 300 subscribers and inconsistent views.",
    ["creator", "juniorcreator", "deny"],
    ["deny"],
    "300 subscribers is BELOW the minimum for Junior Content Creator, and monthly posting is too infrequent — deny, and tell them what to improve (post more often, grow the channel) before reapplying."
  ),
  scenario(
    "creative-academy",
    "Creative",
    "Member applies for Creative Roster and sends 2-3 VIDEO clips of their gameplay, including 1 freebuild (no replays). You watch them: decent mechanics, some variety in moves, not many mistakes.",
    ["creativeacademy", "maincreative", "procreative", "deny", "ask-new-clips"],
    ["creativeacademy"],
    '"Decent mechanics, some variety, not many mistakes" is exactly the Creative Academy bar — use `*creativeacademy`. (In a real ticket you\'d be watching their video clips yourself — here the description stands in for the video.)'
  ),
  scenario(
    "creative-main",
    "Creative",
    "Member applies for Creative Roster and sends 2-3 VIDEO clips including 1 freebuild (no replays). You watch them: fast mechanics, wide variety of edits and moves, few mistakes at most.",
    ["creativeacademy", "maincreative", "procreative", "deny", "ask-new-clips"],
    ["maincreative"],
    '"Fast mechanics, wide variety, few mistakes at most" matches Main Creative Roster — use `*maincreative`. (In a real ticket you\'d be watching their video clips yourself — here the description stands in for the video.)'
  ),
  scenario(
    "creative-pro",
    "Creative",
    "Member applies for Creative Roster and sends 2-3 VIDEO clips including 1 freebuild (no replays). You watch them: super fast mechanics, very wide variety of edits, barely any to no mistakes.",
    ["creativeacademy", "maincreative", "procreative", "deny", "ask-new-clips"],
    ["procreative"],
    '"Super fast mechs, very wide variety, barely any to no mistakes" is the Pro Creative bar — use `*procreative`. (In a real ticket you\'d be watching their video clips yourself — here the description stands in for the video.)'
  ),
  scenario(
    "creative-no-freebuild",
    "Creative",
    "Member applies for Creative Roster and sends 3 replay clips (no freebuild, no live gameplay clips) claiming great mechanics.",
    ["creativeacademy", "maincreative", "procreative", "deny", "ask-new-clips"],
    ["ask-new-clips", "deny"],
    "Replays are explicitly NOT accepted for Creative applications, and a freebuild is required. Ask them to resend proper video clips (no replays, include a freebuild), or deny — both are fine. Judging a tier from replays is the wrong call."
  ),
  scenario(
    "double-rostering",
    "Special case",
    "A Roster applicant looks strong on paper, but their Discord bio and server tag show they're currently repping another esports org's roster.",
    ["accept", "deny-unless-proof", "ask-more-proof", "escalate"],
    ["deny-unless-proof"],
    "This is double rostering. Check bio, username and server tag, and ask for proof they're not in the other team's roster (e.g. a screenshot of their roles there). Refuse the request unless they show proof they've LEFT the other team's roster — don't just take their word for it."
  ),
  scenario(
    "fake-clips",
    "Special case",
    "A Creative applicant's clips look off — inconsistent framerate suggesting the footage might be a phone recording of a monitor.",
    ["accept", "ask-more-proof", "deny", "escalate"],
    ["ask-more-proof", "deny", "escalate"],
    "Situation dependent — asking for additional proof, denying, or escalating to a higher authority are all acceptable. Accepting without checking is the only wrong call. Deliberately fake/stolen evidence may also mean denial + moderation action."
  )
];

function getAllScenarioIds() {
  return ALL_SCENARIOS.map((s) => s.id);
}

function getScenario(id) {
  return ALL_SCENARIOS.find((s) => s.id === id) || null;
}

module.exports = { ALL_SCENARIOS, getAllScenarioIds, getScenario };
