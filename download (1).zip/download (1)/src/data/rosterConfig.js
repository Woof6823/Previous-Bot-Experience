module.exports = {

  operations: [
    { userId: "783125857178746910", label: "CEO" },
    { userId: "694336403269615666", label: "Brand Ownership" },
    { userId: "1130903450188779651", label: "Brand Ownership" },
    { userId: "1460942049594314772", label: "Vice President" }
  ],



  directors: [
    { userId: "1498455777189433365", label: "Director of Esports" }
  ],


  board: [
    { userId: "549033399495557160", label: "Board of Directors" },
    { userId: "1462632870672597048", label: "Board Member" },
    { userId: "912002279350075472", label: "Board Member" }
  ],


  prosRoleId: "1455008449392939148"
};
